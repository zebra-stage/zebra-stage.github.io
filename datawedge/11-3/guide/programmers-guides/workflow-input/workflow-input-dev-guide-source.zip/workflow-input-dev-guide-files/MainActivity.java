package com.zebra.idscanningapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    TextView txtStringData = null;
    ImageView imgData = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtStringData = findViewById(R.id.txtStringData);
        imgData = findViewById(R.id.imgData);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.zebra.id_scanning.ACTION");
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
        registerReceiver(broadcastReceiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(MainActivity.this, "Data received", Toast.LENGTH_SHORT).show();
            Bundle bundle = intent.getExtras();
            String jsonData = bundle.getString("com.symbol.datawedge.data");
            try {
                JSONArray jsonArray = new JSONArray(jsonData);
                for(int i=0; i<jsonArray.length(); i++)
                {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.has("string_data"))
                    {
                        //String data
                        txtStringData.append(jsonObject.getString("label")  + ": " +
                                jsonObject.getString("string_data") + "\n");
                    }
                    else
                    {
                        String uri = jsonObject.getString("uri");
                        Cursor cursor = getContentResolver().query(Uri.parse(uri),null,null,null);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        if(cursor != null)
                        {
                            cursor.moveToFirst();
                            baos.write(cursor.getBlob(cursor.getColumnIndex("raw_data")));
                            String nextURI = cursor.getString(cursor.getColumnIndex("next_data_uri"));
                            while (nextURI != null && !nextURI.isEmpty())
                            {
                                Cursor cursorNextData = getContentResolver().query(Uri.parse(nextURI),
                                        null,null,null);
                                if(cursorNextData != null)
                                {
                                    cursorNextData.moveToFirst();
                                    baos.write(cursorNextData.getBlob(cursorNextData.
                                            getColumnIndex("raw_data")));
                                    nextURI = cursorNextData.getString(cursorNextData.
                                            getColumnIndex("next_data_uri"));

                                    cursorNextData.close();
                                }

                            }
                            cursor.close();
                        }

                        int width = 0;
                        int height = 0;
                        int stride = 0;
                        int orientation = 0;
                        String imageFormat = "";

                        width = jsonObject.getInt("width");
                        height = jsonObject.getInt("height");
                        stride = jsonObject.getInt("stride");
                        orientation = jsonObject.getInt("orientation");
                        imageFormat = jsonObject.getString("imageformat");

                        Bitmap bitmap = ImageProcessing.getInstance().getBitmap(baos.toByteArray(),imageFormat, orientation,stride,width, height);

                        imgData.setImageBitmap(bitmap);
                        //Image data
                    }

                }
            }
            catch (Exception ex)
            {
                //Check error
            }
        }
    };
}