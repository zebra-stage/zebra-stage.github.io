package com.zebra.flavorpicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView txtStatus = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtStatus = findViewById(R.id.txtStatus);
        registerReceivers();
        registerUnregisterForNotifications(true, "WORKFLOW_STATUS");
        registerUnregisterForNotifications(true, "SCANNER_STATUS");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        registerUnregisterForNotifications(false, "WORKFLOW_STATUS");
        registerUnregisterForNotifications(false, "SCANNER_STATUS");
        unregisterReceivers();
    }

    private void registerReceivers() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.symbol.datawedge.api.NOTIFICATION_ACTION");
        filter.addAction("com.symbol.datawedge.api.RESULT_ACTION");
        filter.addCategory(Intent.CATEGORY_DEFAULT);
        registerReceiver(broadcastReceiver, filter);
    }

    private void unregisterReceivers() {

        unregisterReceiver(broadcastReceiver);
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals("com.symbol.datawedge.api.NOTIFICATION_ACTION")) {

                if (intent.hasExtra("com.symbol.datawedge.api.NOTIFICATION")) {
                    Bundle b = intent.getBundleExtra("com.symbol.datawedge.api.NOTIFICATION");
                    String NOTIFICATION_TYPE = b.getString("NOTIFICATION_TYPE");
                    if (NOTIFICATION_TYPE != null) {
                        switch (NOTIFICATION_TYPE) {
                            case "WORKFLOW_STATUS":
                            case "SCANNER_STATUS":

                                String status = b.getString("STATUS");
                                txtStatus.setText("Status: " + status);
                                break;
                        }
                    }
                }
            }
        }
    };

    void registerUnregisterForNotifications(boolean register, String type) {
        Bundle b = new Bundle();
        b.putString("com.symbol.datawedge.api.APPLICATION_NAME", getPackageName());
        b.putString("com.symbol.datawedge.api.NOTIFICATION_TYPE", type);
        Intent i = new Intent();
        i.putExtra("APPLICATION_PACKAGE", getPackageName());
        i.setAction("com.symbol.datawedge.api.ACTION");
        i.setPackage("com.symbol.datawedge");
        if (register)
            i.putExtra("com.symbol.datawedge.api.REGISTER_FOR_NOTIFICATION", b);
        else
            i.putExtra("com.symbol.datawedge.api.UNREGISTER_FOR_NOTIFICATION", b);
        this.sendBroadcast(i);
    }

    public void onClickHighlight(View view) {

        //Specify the DataWedge action and SWITCH_DATACAPTURE API parameters
        Intent i = new Intent();
        i.setAction("com.symbol.datawedge.api.ACTION");
        i.putExtra("APPLICATION_PACKAGE", getPackageName());
        i.setPackage("com.symbol.datawedge");
        i.putExtra("SEND_RESULT", "LAST_RESULT");
        i.putExtra("com.symbol.datawedge.api.SWITCH_DATACAPTURE", "BARCODE");

        Bundle paramList = new Bundle();
        //Specify the scanner to use (Only internal imager and camera are supported currently)
        paramList.putString("scanner_selection_by_identifier", "INTERNAL_IMAGER");
        //Enable barcode highlighting
        paramList.putString("barcode_highlighting_enabled", "true");

        //Create a barcode highlighting Rule 1 [Start]
        Bundle rule1 = new Bundle();
        rule1.putString("rule_name", "Rule1");
            Bundle rule1Criteria = new Bundle();

        //Set the criteria/condition. Specify the contains parameter.
        Bundle bundleContains1 = new Bundle();
        bundleContains1.putString("criteria_key", "contains");
        bundleContains1.putString("criteria_value", "090986");

        //Container is just one parameter of identifier group.
        // There are other params such as ignore case, min length, max length
        ArrayList<Bundle> identifierParamList = new ArrayList<>();
        identifierParamList.add(bundleContains1);

        //Add the parameters of "identifier" group as a ParcelableArrayList to criteria list
        rule1Criteria.putParcelableArrayList("identifier", identifierParamList);

        //Add the criteria to Rule bundle
        rule1.putBundle("criteria", rule1Criteria);

        //Set up the action bundle by specifying the color to be highlight
        Bundle bundleFillColor = new Bundle();
        bundleFillColor.putString("action_key", "fillcolor");
        bundleFillColor.putString("action_value", "#CEF04E6E");

        ArrayList<Bundle> rule1Actions = new ArrayList<>();
        rule1Actions.add(bundleFillColor);
        rule1.putParcelableArrayList("actions", rule1Actions);
        //Create a barcode highlighting Rule 1 [Finish]

        //Create a barcode highlighting Rule 2 [Start]
        Bundle rule2 = new Bundle();
        rule2.putString("rule_name", "Rule2");
        Bundle rule2Criteria = new Bundle();

        Bundle bundleContains2 = new Bundle();
        bundleContains2.putString("criteria_key", "contains");
        bundleContains2.putString("criteria_value", "7777");

        ArrayList<Bundle> identifierParamList2 = new ArrayList<>();
        identifierParamList2.add(bundleContains2);

        rule2Criteria.putParcelableArrayList("identifier", identifierParamList2);

        rule2.putBundle("criteria", rule2Criteria);
        Bundle rule2BundleStrokeColor = new Bundle();
        rule2BundleStrokeColor.putString("action_key", "fillcolor");
        rule2BundleStrokeColor.putString("action_value", "#CE7F2714");
        ArrayList<Bundle> rule2Actions = new ArrayList<>();
        rule2Actions.add(rule2BundleStrokeColor);
        rule2.putParcelableArrayList("actions", rule2Actions);
        //Create a barcode highlighting Rule 1 [Finish]

        //Add the two created rules to the rule list
        ArrayList<Bundle> ruleList = new ArrayList<>();
        ruleList.add(rule1);
        ruleList.add(rule2);


        //Assign the rule list to barcode_overlay parameter
        Bundle ruleBundlebarcodeOverlay = new Bundle();
        ruleBundlebarcodeOverlay.putString("rule_param_id", "barcode_overlay");
        ruleBundlebarcodeOverlay.putParcelableArrayList("rule_list", ruleList);


        ArrayList<Bundle> ruleParamList = new ArrayList<>();
        ruleParamList.add(ruleBundlebarcodeOverlay);

        paramList.putParcelableArrayList("rules", ruleParamList);

        i.putExtra("PARAM_LIST", paramList);

        sendBroadcast(i);
    }


    public void onClickRegular(View view) {

        //Specify the DataWedge action and SWITCH_DATACAPTURE API parameters
        Intent i = new Intent();
        i.setAction("com.symbol.datawedge.api.ACTION");
        i.putExtra("APPLICATION_PACKAGE", getPackageName());
        i.setPackage("com.symbol.datawedge");
        i.putExtra("SEND_RESULT", "LAST_RESULT");
        i.putExtra("com.symbol.datawedge.api.SWITCH_DATACAPTURE", "BARCODE");

        Bundle paramList = new Bundle();
        //Specify the scanner to use (Only internal imager and camera are supported currently)
        paramList.putString("scanner_selection_by_identifier", "INTERNAL_IMAGER");
        //Disable barcode highlighting
        paramList.putString("barcode_highlighting_enabled", "false");

        i.putExtra("PARAM_LIST", paramList);

        sendBroadcast(i);
    }
}