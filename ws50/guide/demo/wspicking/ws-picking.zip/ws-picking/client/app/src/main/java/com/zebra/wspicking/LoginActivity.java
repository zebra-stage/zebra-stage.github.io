// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityLoginBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;

/**
 * App entrance point. Activity for starting the login process in by scanning a barcode or selecting
 * the manual login button.
 */
public class LoginActivity extends AppCompatActivity implements ScanReceiver.OnScanListener {
    private static final String TAG = "LoginActivity";
    private static final String PREFS_NAME = "preferences";
    private static final String PREFS_KEY_BARCODE = "latestLoginStationBarcode";
    private ActivityLoginBinding ui;
    private JSONObject latestBarcode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize the ScanReceiver object for the whole application.
        ScanReceiver.Initialize(getApplicationContext());

        String latestBarcodeText = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(PREFS_KEY_BARCODE, null);
        if (latestBarcodeText != null) {
            try { latestBarcode = new JSONObject(latestBarcodeText); }
            catch (JSONException ignored) { /* ignore malformed data */ }
        }
        adjustManualLoginButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ScanReceiver.mInstance.setOnScanListener(this);
    }

    /**
     * Set up the manual login button based on whether a valid barcode has been scanned before.
     */
    private void adjustManualLoginButton() {
        ui.manual.setVisibility(latestBarcode == null ? View.GONE : View.VISIBLE);
        ui.manual.setOnClickListener(view -> {
            try { ServerSession.Initialize(latestBarcode.getString("baseUrl")); }
            catch (JSONException|URISyntaxException e) {
                // Shouldn't happen, but if the saved barcode is malformed, clear it.
                latestBarcode = null;
                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().remove(PREFS_KEY_BARCODE).apply();
                adjustManualLoginButton();
                showError(getString(R.string.invalid_barcode_scanned));
                return;
            }
            installPinnedCertificate();
            ServerSession.mInstance.registerUrls(latestBarcode);
            startActivity(new Intent(this, ManualLoginActivity.class));
        });
    }

    @Override
    protected void onPause() {
        ScanReceiver.mInstance.setOnScanListener(null);
        super.onPause();
    }

    @Override
    public void onScan(String data) {
        JSONObject barcode;
        try {
            barcode = new JSONObject(data);
            String application = barcode.getString("application");
            if (!application.equals("WS Picking")) throw new JSONException("");
            ServerSession.Initialize(barcode.getString("baseUrl"));
            installPinnedCertificate();
            ServerSession.mInstance.registerUrls(barcode);
            ServerSession.mInstance.get("remoteLogin", new ServerSession.HttpCallback() {
                @Override
                public void onSuccess(String response, int statusCode) {
                    try {
                        // Continue the login process in the StationLoginActivity, which will show
                        // the status of the remote login.
                        ServerSession.mInstance.registerUrls(new JSONObject(response));
                        startActivity(new Intent(LoginActivity.this, StationLoginActivity.class));
                        // Save the barcode information so it can be used for manual login another
                        // time.
                        latestBarcode = barcode;
                        adjustManualLoginButton();
                        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                                .edit()
                                .putString(PREFS_KEY_BARCODE, data)
                                .apply();
                    } catch (JSONException e) {
                        showError(getString(R.string.internal_communication_error));
                    }
                }

                @Override
                public void onError(String error) {
                    showError(error);
                }
            });
        } catch (URISyntaxException|JSONException e) {
            showError(getString(R.string.invalid_barcode_scanned));
        }
    }

    /**
     * In debug builds, install the bundled self-signed certificate as the sole trusted anchor for
     * all ServerSession HTTPS connections.  Allows testing against a local server that uses a
     * self-signed certificate without disabling SSL validation entirely.  No-op in release builds.
     */
    private void installPinnedCertificate() {
        if (!BuildConfig.DEBUG) return;
        try (java.io.InputStream cert = getResources().openRawResource(R.raw.wspicking)) {
            ServerSession.mInstance.setPinnedCertificate(cert);
        } catch (Exception e) {
            Log.e(TAG, "Failed to install pinned certificate", e);
        }
    }

    /**
     * Show an error message with sound and vibration feedback. This feedback is important, so the
     * user knows when their scan was unsuccessful, for example if someone else scanned the same
     * barcode on another device just before (race condition).
     *
     * @param error The error message to show.
     */
    public void showError(String error) {
        ui.message.setText(error);
        ui.main.setBackgroundColor(Color.RED);

        // Beep.
        try {
            MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.errorbuzz);
            if (mediaPlayer != null) {
                mediaPlayer.start();
                mediaPlayer.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception ignored) {}

        // Vibrate.
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        }

        // Change back after 2 seconds.
        ui.main.postDelayed(() -> {
            ui.message.setText(getText(R.string.scan_to_login));
            ui.main.setBackgroundColor(Color.BLACK);
        }, 2000);
    }

}