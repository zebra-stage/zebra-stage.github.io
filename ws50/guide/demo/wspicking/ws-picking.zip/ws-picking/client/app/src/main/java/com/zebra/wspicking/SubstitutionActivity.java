// Copyright (c) 2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityPickItemBinding;
import com.zebra.wspicking.databinding.ActivitySubstitutionBinding;
import com.zebra.wspicking.databinding.DialogEditNoteBinding;
import com.zebra.wspicking.databinding.DialogEditQuantityBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity for capturing details of a picking substitution.
 */
public class SubstitutionActivity extends AppCompatActivity implements ScanReceiver.OnScanListener {
    private static final String TAG = "SubstitutionActivity";

    public static final String EXTRA_RESPONSE = "response";

    private ActivitySubstitutionBinding ui;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivitySubstitutionBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ui.minus.setOnClickListener(v -> {
            int newQuantity;
            try { newQuantity = Integer.parseInt(ui.quantity.getText().toString()) - 1; }
            catch (NumberFormatException ignored) { return; }
            if (newQuantity >= 0) ui.quantity.setText(String.valueOf(newQuantity));
        });
        ui.plus.setOnClickListener(v -> {
            int newQuantity;
            try { newQuantity = Integer.parseInt(ui.quantity.getText().toString()) + 1; }
            catch (NumberFormatException ignored) { return; }
            ui.quantity.setText(String.valueOf(newQuantity));
        });

        ui.cancel.setOnClickListener(v -> finish());
        ui.ok.setOnClickListener(v -> {
            // Save the substitution details.
            String upc = ui.upc.getText().toString();
            String description = ui.description.getText().toString();
            int quantity;
            try { quantity = Integer.parseInt(ui.quantity.getText().toString()); }
            catch (NumberFormatException e) {
                Toast.makeText(SubstitutionActivity.this, R.string.invalid_quantity_entered, Toast.LENGTH_SHORT).show();
                return;
            }
            if (quantity < 0) {
                Toast.makeText(SubstitutionActivity.this, R.string.picked_quantity_cannot_be_negative, Toast.LENGTH_SHORT).show();
                return;
            }
            // Return the substitution note.
            Intent result = new Intent();
            result.putExtra(EXTRA_RESPONSE, getString(R.string.substitution_note, quantity, upc, description));
            setResult(RESULT_OK, result);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ScanReceiver.mInstance.setOnScanListener(this);
    }

    @Override
    protected void onPause() {
        ScanReceiver.mInstance.setOnScanListener(null);
        super.onPause();
    }

    @Override
    public void onScan(String data) {
        ServerSession.mInstance.get("productLookupUpc", data, new ServerSession.HttpCallback() {
            @Override
            public void onSuccess(String response, int statusCode) {
                try {
                    JSONObject product = new JSONObject(response);
                    String description = product.getString("name");
                    runOnUiThread(() -> {
                        ui.description.setText(description);
                        ui.upc.setText(data);
                        ui.ok.setEnabled(true);
                    });
                } catch (JSONException e) {
                    Log.e(TAG, "Invalid JSON response", e);
                    runOnUiThread(() -> Toast.makeText(SubstitutionActivity.this, R.string.internal_communication_error, Toast.LENGTH_SHORT).show());
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Product lookup failed: " + error);
                runOnUiThread(() -> Toast.makeText(SubstitutionActivity.this, R.string.product_lookup_failed, Toast.LENGTH_SHORT).show());
            }
        });
    }
}
