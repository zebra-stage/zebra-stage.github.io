// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityModalServerOpBinding;


/**
 * Activity that performs a modal server operation (HTTP GET) and shows a message while waiting.
 */
public class ModalServerOpActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_URL_SUFFIX = "url_suffix";
    public static final String EXTRA_METHOD = "method";
    public static final String EXTRA_DATA = "data";
    public static final String EXTRA_CONTENT_TYPE = "content_type";
    public static final String EXTRA_RESPONSE = "response";
    public static final String EXTRA_ERROR = "error";

    private ActivityModalServerOpBinding ui;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityModalServerOpBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent i = getIntent();
        ui.message.setText(i.getStringExtra(EXTRA_MESSAGE));
        ServerSession.mInstance.executeHttpRequest(i.getStringExtra(EXTRA_METHOD),
                i.getStringExtra(EXTRA_URL), i.getStringExtra(EXTRA_URL_SUFFIX),
                i.getStringExtra(EXTRA_DATA), i.getStringExtra(EXTRA_CONTENT_TYPE),
                new ServerSession.HttpCallback() {
            @Override
            public void onSuccess(String response, int statusCode) {
                Intent result = new Intent();
                result.putExtra(EXTRA_RESPONSE, response);
                setResult(RESULT_OK, result);
                finish();
            }

            @Override
            public void onError(String errorMessage) {
                synchronized (ModalServerOpActivity.this) {
                    if (ui == null) return;     // activity was destroyed
                    ui.message.setText(errorMessage);
                    ui.main.postDelayed(() -> {
                        Intent result = new Intent();
                        result.putExtra(EXTRA_ERROR, errorMessage);
                        setResult(RESULT_CANCELED, result);
                        finish();
                    }, 2000);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        // It is very unlikely that onDestroy will be called while a request is in progress, but if
        // it does happen we want to avoid attempting to update the UI.
        synchronized (this) { ui = null; }
        super.onDestroy();
    }
}
