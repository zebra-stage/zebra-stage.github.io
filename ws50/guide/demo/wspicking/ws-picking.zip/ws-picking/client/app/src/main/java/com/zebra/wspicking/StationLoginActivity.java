// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityStationLoginBinding;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Activity for station login.  Connects to the server via SSE to receive login status updates and
 * shows these to the user.  Allows cancellation of the login process.
 */
public class StationLoginActivity extends AppCompatActivity {
    private static final String TAG = "StationLoginActivity";
    private static final boolean DEBUG = false;

    private ActivityStationLoginBinding ui;
    private ServerSession.SSEConnection sseConnection;
    private boolean completed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityStationLoginBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        connectSSE();

        ui.back.setOnClickListener(view -> finish());
    }

    @Override
    protected void onDestroy() {
        // Close SSE connection
        if (sseConnection != null) {
            sseConnection.close();
            sseConnection = null;
        }

        // Clean up session on exit if login was not successful.
        if (!completed) {
            ServerSession.mInstance.post("remoteLoginCancel", null, null, null);
        }
        super.onDestroy();
    }

    /**
     * Connect to the server via SSE to receive login status updates.
     */
    private void connectSSE() {
        sseConnection = ServerSession.mInstance.openSSE("remoteLoginStatus", new ServerSession.SSECallback() {
            @Override
            public void onOpen() {
                if (DEBUG) Log.d(TAG, "SSE connection opened");
            }

            @Override
            public void onEvent(String eventType, String data) {
                if (DEBUG) Log.d(TAG, "SSE event received [" + eventType + "]: " + data);
                try {
                    JSONObject result = new JSONObject(data);
                    String status = result.getString("status");
                    if (DEBUG) Log.d(TAG, "Session status: " + status);

                    switch (status) {
                        case "cancelled":
                        case "error":
                            ui.main.setBackgroundColor(Color.RED);
                            ui.message.setText(R.string.cancelled);
                            completed = true;
                            ui.main.postDelayed(() -> finish(), 2000);
                            break;
                        case "done":
                            ui.message.setText(getString(R.string.logged_in_as, result.getString("fullName")));
                            Long userId = result.getLong("id");
                            completed = true;
                            ServerSession.mInstance.registerUrls(result);
                            ui.main.postDelayed(() -> {
                                Intent i = new Intent(StationLoginActivity.this, OrderListActivity.class);
                                i.putExtra("userId", userId);
                                startActivity(i);
                                finish();
                            }, 1000);
                            break;
                    }
                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing SSE event data", e);
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "SSE error: " + error);
                ui.message.setText(getString(R.string.error, error));
            }

            @Override
            public void onClose() {
                if (DEBUG) Log.d(TAG, "SSE connection closed");
                if (!completed) {
                    ui.main.setBackgroundColor(Color.RED);
                    ui.message.setText(R.string.connection_closed);
                    ui.main.postDelayed(() -> finish(), 2000);
                }
            }
        });
    }
}
