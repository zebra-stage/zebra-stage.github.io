// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

/**
 * Singleton class for managing a server session, including HTTP requests and SSE connections.
 */
public class ServerSession {

    private static final String TAG = "ServerSession";
    private static final boolean DEBUG = false;
    private static final int CONNECT_TIMEOUT = 30000; // 30 seconds
    private static final int READ_TIMEOUT = 30000; // 30 seconds

    public static ServerSession mInstance = null;

    private final URI baseUri;
    private final Handler mainHandler;
    private final ExecutorService executorService;
    private final CookieManager cookieManager;

    private final Map<String, String> urls = new HashMap<>();

    // Non-null when a pinned certificate has been installed via setPinnedCertificate().
    private javax.net.ssl.SSLSocketFactory pinnedSocketFactory = null;
    // Accepts any hostname when pinning is active (the cert itself is the trust anchor).
    private static final HostnameVerifier ACCEPT_ANY_HOSTNAME = (hostname, session) -> true;

    /**
     * Initialize the singleton ServerSession instance.  Call once at startup, then access the
     * instance via the static mInstance member.
     *
     * @param url Base URL for the server session
     * @throws URISyntaxException if the URL is invalid
     */
    public static void Initialize(String url) throws URISyntaxException {
        if (DEBUG) Log.i(TAG, "Initializing ServerSession with base URL: " + url);
        mInstance = new ServerSession(url);
    }

    /**
     * Private constructor.
     * @param uri Base URI for the server session
     * @throws URISyntaxException if the URI is invalid
     */
    private ServerSession(String uri) throws URISyntaxException {
        baseUri = new URI(uri);
        if (!baseUri.isAbsolute()) throw new URISyntaxException(uri, "URI must be absolute");
        mainHandler = new Handler(Looper.getMainLooper());
        executorService = Executors.newCachedThreadPool();

        // Set up cookie management for session persistence.
        cookieManager = new CookieManager();
        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
        CookieHandler.setDefault(cookieManager);
    }

    /**
     * Clear all cookies in this session
     */
    public void clearCookies() {
        cookieManager.getCookieStore().removeAll();
    }

    /**
     * Install a pinned certificate so that HTTPS connections are only trusted when the server
     * presents this exact certificate.  Intended for development/testing with a local server that
     * uses a self-signed certificate.
     *
     * @param certDerStream InputStream for the DER- or PEM-encoded X.509 certificate to pin.
     *                      The stream is consumed but not closed by this method.
     * @throws CertificateException     if the certificate cannot be parsed
     * @throws KeyStoreException        if the key store cannot be initialized
     * @throws NoSuchAlgorithmException if the TLS algorithm is unavailable
     * @throws KeyManagementException   if the SSLContext cannot be initialised
     * @throws IOException              if the key store load fails
     */
    public void setPinnedCertificate(InputStream certDerStream)
            throws CertificateException, KeyStoreException, NoSuchAlgorithmException,
                   KeyManagementException, IOException {
        // Parse the DER/PEM certificate.
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate pinnedCert = cf.generateCertificate(certDerStream);

        // Build a KeyStore that trusts only this certificate.
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, null);
        ks.setCertificateEntry("pinned", pinnedCert);

        // Build a TrustManagerFactory from that KeyStore.
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);

        // Build the SSLContext.
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);

        pinnedSocketFactory = sslContext.getSocketFactory();
        if (DEBUG) Log.d(TAG, "Pinned certificate installed: " + pinnedCert);
    }

    /**
     * If a pinned certificate has been installed, configure the given connection to use it.
     * This replaces the system default SSL trust chain with one that only trusts the pinned cert,
     * and disables hostname verification (since a dev self-signed cert typically won't have a
     * matching CN / SAN for the test host's IP address or hostname).
     * No-op for plain HTTP connections.
     */
    private void configureSslIfNeeded(HttpURLConnection connection) {
        if (pinnedSocketFactory == null || !(connection instanceof HttpsURLConnection)) return;
        HttpsURLConnection https = (HttpsURLConnection) connection;
        https.setSSLSocketFactory(pinnedSocketFactory);
        https.setHostnameVerifier(ACCEPT_ANY_HOSTNAME);
    }

    /**
     * Register URLs from a JSON object. The object should contain key-value pairs where keys end
     * with "Url" and values are the corresponding URL paths. Other keys are ignored.
     *
     * @param jsonList JSON object containing URL mappings
     */
    public void registerUrls(JSONObject jsonList) {
        jsonList.keys().forEachRemaining(key -> {
            if (!key.endsWith("Url")) return;
            try {
                urls.put(key.substring(0, key.length() - 3), jsonList.getString(key));
            } catch (JSONException ignored) {}
        });
    }

    /**
     * Build a full URL from a path. Relative paths are resolved against the base URL.
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @return Full URL
     * @throws URISyntaxException if the URL is invalid
     * @throws MalformedURLException if the URL is malformed
     */
    public URL buildUrl(String path) throws URISyntaxException, MalformedURLException {
        if (path.startsWith("http://") || path.startsWith("https://")) {
            return new URI(path).toURL();
        }
        if (!urls.containsKey(path)) throw new MalformedURLException("Unknown path: " + path);
        return baseUri.resolve(urls.get(path)).toURL();
    }

    /**
     * Read all bytes from an InputStream. Compatible with API levels below 33.
     *
     * @param inputStream InputStream to read from
     * @return byte array containing all data from the stream
     * @throws IOException if an I/O error occurs
     */
    private byte[] readAllBytes(java.io.InputStream inputStream) throws IOException {
        try (java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream()) {
            byte[] data = new byte[8192];
            int bytesRead;
            while ((bytesRead = inputStream.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, bytesRead);
            }
            return buffer.toByteArray();
        }
    }

    /**
     * Perform a GET request.
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param callback Callback to handle response or error
     */
    public void get(String path, final HttpCallback callback) {
        executeHttpRequest("GET", path, null, null, null, callback);
    }

    /**
     * Perform a GET request with a path suffix (e.g., for dynamic parameters).
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param pathSuffix Suffix to append to the path (e.g., an ID or query parameter)
     * @param callback Callback to handle response or error
     */
    public void get(String path, String pathSuffix, final HttpCallback callback) {
        executeHttpRequest("GET", path, pathSuffix, null, null, callback);
    }

    /**
     * Perform a GET request and retrieve raw binary data (e.g., for images).
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param callback Callback to handle raw byte array response or error
     */
    public void getRaw(String path, final HttpRawCallback callback) {
        executorService.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = buildUrl(path);
                if (DEBUG) Log.d(TAG, "GET Raw Request: " + url);
                connection = (HttpURLConnection) url.openConnection();
                configureSslIfNeeded(connection);
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(CONNECT_TIMEOUT);
                connection.setReadTimeout(READ_TIMEOUT);

                int statusCode = connection.getResponseCode();
                boolean isSuccessful = statusCode >= 200 && statusCode < 300;
                if (DEBUG) {
                    Log.d(TAG, "Response Status: " + statusCode + " " + connection.getResponseMessage());
                }

                if (isSuccessful) {
                    // Read raw bytes from response
                    byte[] responseData = readAllBytes(connection.getInputStream());
                    if (DEBUG) Log.d(TAG, "Response Body (SUCCESS): " + responseData.length + " bytes");
                    if (callback != null) mainHandler.post(() -> callback.onSuccess(responseData, statusCode));
                } else {
                    // Read error message as string
                    StringBuilder response = new StringBuilder();
                    InputStream errorStream = connection.getErrorStream();
                    if (errorStream != null) try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) response.append(line).append('\n');
                    }
                    String errorBody = response.toString().trim();
                    if (DEBUG) Log.e(TAG, "Response Body (ERROR): " + errorBody);
                    if (callback != null) mainHandler.post(() -> callback.onError("HTTP " + statusCode + ": " + errorBody));
                }
            } catch (Exception e) {
                if (DEBUG) Log.e(TAG, "GET Raw Request Failed: " + path, e);
                if (callback != null) mainHandler.post(() -> callback.onError(e.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    /**
     * Perform a POST request with custom content type.
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param body Request body as string
     * @param contentType Content-Type header value
     * @param callback Callback to handle response or error
     */
    public void post(String path, String body, String contentType, final HttpCallback callback) {
        executeHttpRequest("POST", path, null, body, contentType, callback);
    }

    /**
     * Perform a PATCH request with custom content type.
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param body Request body as string
     * @param contentType Content-Type header value
     * @param callback Callback to handle response or error
     */
    public void patch(String path, String body, String contentType, final HttpCallback callback) {
        executeHttpRequest("PATCH", path, null, body, contentType, callback);
    }

    /**
     * Generic method to handle HTTP requests (GET, PATCH, POST, etc.).
     *
     * @param method      The HTTP method (e.g., "GET", "PATCH", "POST").
     * @param path        The endpoint path for the request.
     * @param pathSuffix  Optional suffix to append to the path (e.g., for dynamic parameters).
     * @param body        The request body (can be null or empty).
     * @param contentType The content type of the request.
     * @param callback    The callback to handle success or error responses.
     */
    public void executeHttpRequest(String method, String path, String pathSuffix, String body, String contentType, final HttpCallback callback) {
        executorService.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = buildUrl(path);
                if (pathSuffix != null) url = new URL(url.toString() + Uri.encode(pathSuffix));
                if (DEBUG) {
                    Log.d(TAG, method + " Request: " + url);
                    if (contentType != null) Log.d(TAG, method + " Content-Type: " + contentType);
                    if (body != null) Log.d(TAG, method + " Body: " + body);
                }
                connection = (HttpURLConnection) url.openConnection();
                configureSslIfNeeded(connection);
                connection.setRequestMethod(method);
                connection.setConnectTimeout(CONNECT_TIMEOUT);
                connection.setReadTimeout(READ_TIMEOUT);
                if (contentType != null) connection.setRequestProperty("Content-Type", contentType);

                // Write request body if provided.
                if (body != null && !body.isEmpty()) {
                    connection.setDoOutput(true);
                    byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
                    connection.setFixedLengthStreamingMode(bodyBytes.length);
                    try (OutputStream os = connection.getOutputStream()) {
                        os.write(bodyBytes);
                        os.flush();
                    }
                }

                // Get response status.
                int statusCode = connection.getResponseCode();
                boolean isSuccessful = statusCode >= 200 && statusCode < 300;
                if (DEBUG) {
                    Log.d(TAG, "Response Status: " + statusCode + " " + connection.getResponseMessage());
                    connection.getHeaderFields().forEach((key, values) -> {
                        if (key != null) {
                            Log.d(TAG, "Response Header: " + key + " = " + String.join(", ", values));
                        }
                    });
                }

                // Read response data.
                StringBuilder response = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                isSuccessful ? connection.getInputStream() : connection.getErrorStream(),
                                StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) response.append(line).append('\n');
                }
                String responseBody = response.toString().trim();

                if (DEBUG) {
                    if (isSuccessful) Log.d(TAG, "Response Body (SUCCESS): " + responseBody);
                    else Log.e(TAG, "Response Body (ERROR): " + responseBody);
                }

                if (callback != null) mainHandler.post(() -> {
                    if (isSuccessful) callback.onSuccess(responseBody, statusCode);
                    else callback.onError("HTTP " + statusCode + ": " + responseBody);
                });

            } catch (Exception e) {
                if (DEBUG) Log.e(TAG, method + " Request Failed: " + path, e);
                if (callback != null) mainHandler.post(() -> callback.onError(e.getMessage()));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    /**
     * Cancel any outstanding network requests.
     */
    public void cancel() {
        if (executorService != null && !executorService.isShutdown()) executorService.shutdown();
    }

    /**
     * Open and execute an SSE (Server-Sent Events) connection.
     *
     * @param path Relative path name (previously registered in registerUrls) or full URL
     * @param callback Callback to handle SSE events or errors
     * @return SSEConnection object that can be used to close the connection
     */
    public SSEConnection openSSE(String path, final SSECallback callback) {
        SSEConnection sseConnection = new SSEConnection();

        executorService.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = buildUrl(path);
                if (DEBUG) Log.d(TAG, "SSE Request: " + url);

                connection = (HttpURLConnection) url.openConnection();
                configureSslIfNeeded(connection);
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(CONNECT_TIMEOUT);
                connection.setReadTimeout(0); // No timeout for SSE streaming
                connection.setRequestProperty("Accept", "text/event-stream");
                connection.setRequestProperty("Cache-Control", "no-cache");

                int statusCode = connection.getResponseCode();
                if (DEBUG) Log.d(TAG, "SSE Response Status: " + statusCode);

                if (statusCode != 200) {
                    String error = "HTTP " + statusCode + ": " + connection.getResponseMessage();
                    if (DEBUG) Log.e(TAG, "SSE Connection Failed: " + error);
                    mainHandler.post(() -> callback.onError(error));
                    return;
                }

                sseConnection.connection = connection;

                // Notify connection opened.
                mainHandler.post(callback::onOpen);

                // Read SSE stream.
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {

                    String line;
                    StringBuilder eventData = new StringBuilder();
                    String eventType = "message"; // default event type

                    while (!sseConnection.isClosed && (line = reader.readLine()) != null) {
                        if (line.isEmpty()) {
                            // Empty line indicates end of event.
                            if (eventData.length() > 0) {
                                String data = eventData.toString();
                                if (DEBUG) Log.d(TAG, "SSE Event [" + eventType + "]: " + data);

                                String finalEventType = eventType;
                                mainHandler.post(() -> callback.onEvent(finalEventType, data));

                                // Reset for next event.
                                eventData.setLength(0);
                                eventType = "message";
                            }
                        } else if (line.startsWith("data:")) {
                            // Extract data field.
                            String data = line.substring(5).trim();
                            if (eventData.length() > 0) eventData.append('\n');
                            eventData.append(data);
                        } else if (line.startsWith("event:")) {
                            // Extract event type.
                            eventType = line.substring(6).trim();
                        } else if (line.startsWith(":")) {
                            // Comment line, ignore.
                            if (DEBUG) Log.d(TAG, "SSE Comment: " + line);
                        } else if (line.startsWith("id:")) {
                            // Event ID, we can ignore for now.
                            if (DEBUG) Log.d(TAG, "SSE Event ID: " + line.substring(3).trim());
                        } else if (line.startsWith("retry:")) {
                            // Retry timeout, we can ignore for now.
                            if (DEBUG) Log.d(TAG, "SSE Retry: " + line.substring(6).trim());
                        }
                    }
                }

                if (DEBUG) Log.d(TAG, "SSE Connection closed");
                mainHandler.post(callback::onClose);

            } catch (Exception e) {
                if (!sseConnection.isClosed) {
                    if (DEBUG) Log.e(TAG, "SSE Error: " + path, e);
                    mainHandler.post(() -> callback.onError(e.getMessage()));
                }
            } finally {
                if (connection != null) connection.disconnect();
            }
        });

        return sseConnection;
    }

    /**
     * SSE Connection wrapper.
     */
    public static class SSEConnection {
        private HttpURLConnection connection;
        private volatile boolean isClosed = false;

        /**
         * Close the SSE connection.
         */
        public void close() {
            isClosed = true;
            if (connection != null) connection.disconnect();
        }
    }

    /**
     * Callback interface for textual network requests (e.g., json text).
     */
    public interface HttpCallback {
        /**
         * Callback for successful response.
         * @param response Response body as string
         * @param statusCode HTTP status code
         */
        void onSuccess(String response, int statusCode);
        /**
         * Callback for error response.
         * @param error Error message
         */
        void onError(String error);
    }

    /**
     * Callback interface for raw binary data requests (e.g., images).
     */
    public interface HttpRawCallback {
        /**
         * Callback for successful response.
         * @param response Response body as byte array
         * @param statusCode HTTP status code
         */
        void onSuccess(byte[] response, int statusCode);
        /**
         * Callback for error response.
         * @param error Error message
         */
        void onError(String error);
    }

    /**
     * Callback interface for SSE connections.
     */
    public interface SSECallback {
        /**
         * Callback when the SSE connection is opened.
         */
        void onOpen();
        /**
         * Callback for each SSE event received.
         * @param eventType Type of the event
         * @param data Data associated with the event
         */
        void onEvent(String eventType, String data);
        /**
         * Callback when an error occurs.
         * @param error Error message
         */
        void onError(String error);
        /**
         * Callback when the SSE connection is closed.
         */
        void onClose();
    }
}
