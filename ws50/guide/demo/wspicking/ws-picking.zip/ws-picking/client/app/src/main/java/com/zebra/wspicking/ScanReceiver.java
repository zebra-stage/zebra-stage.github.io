// Copyright (c) 2020-2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.util.ArrayList;

/**
 * Singleton class for receiving barcode scans from DataWedge via broadcast intents.
 */
public class ScanReceiver {
    private final static String TAG = "ScanReceiver";
    private final static boolean DEBUG = false;
    private final static String INTENT_ACTION_BARCODE = "com.zebra.wspicking.BARCODE";

    public static ScanReceiver mInstance = null;

    private OnScanListener mListener;


    /**
     * Initialize the singleton ScanReceiver instance.  Call once at startup, then access the
     * instance via the static mInstance member.
     *
     * @param context Application context
     */
    public static void Initialize(Context context) {
        mInstance = new ScanReceiver(context);
    }

    /**
     * Private constructor.
     *
     * @param context Application context
     */
    private ScanReceiver(Context context) {
        ConfigureDataWedge(context);

        IntentFilter filter = new IntentFilter();
        filter.addCategory(Intent.CATEGORY_DEFAULT);
        filter.addAction(INTENT_ACTION_BARCODE);
        ContextCompat.registerReceiver(context, myBroadcastReceiver, filter, ContextCompat.RECEIVER_EXPORTED);
    }

    /**
     * Configure DataWedge to send barcode scans via broadcast intents to this app.
     *
     * @param context Application context
     */
    private void ConfigureDataWedge(Context context) {
        // Scanner input.
        Bundle paramsBarcode = new Bundle();
        paramsBarcode.putString("scanner_input_enabled", "true");
        paramsBarcode.putString("scanner_selection", "auto");
        Bundle configBarcode = new Bundle();
        configBarcode.putString("PLUGIN_NAME", "BARCODE");
        configBarcode.putBundle("PARAM_LIST", paramsBarcode);

        // Disable keystroke output.
        Bundle paramsKeystroke = new Bundle();
        paramsKeystroke.putString("keystroke_output_enabled", "false");
        Bundle configKeystroke = new Bundle();
        configKeystroke.putString("PLUGIN_NAME", "KEYSTROKE");
        configKeystroke.putBundle("PARAM_LIST", paramsKeystroke);

        // Intent output.
        Bundle paramsIntentOutput = new Bundle();
        paramsIntentOutput.putString("intent_output_enabled", "true");
        paramsIntentOutput.putString("intent_action", INTENT_ACTION_BARCODE);
        paramsIntentOutput.putInt("intent_delivery", 2);    // 2 = broadcast
        Bundle configIntentOutput = new Bundle();
        configIntentOutput.putString("PLUGIN_NAME", "INTENT");
        configIntentOutput.putString("RESET_CONFIG", "true");
        configIntentOutput.putBundle("PARAM_LIST", paramsIntentOutput);

        // Combine plugin configurations.
        ArrayList<Bundle> bundlePluginConfig = new ArrayList<>();
        bundlePluginConfig.add(configBarcode);
        bundlePluginConfig.add(configKeystroke);
        bundlePluginConfig.add(configIntentOutput);

        // Associate the profile with this app.
        Bundle myApp = new Bundle();
        myApp.putString("PACKAGE_NAME", context.getPackageName());
        myApp.putStringArray("ACTIVITY_LIST", new String[]{"*"});

        // Main bundle.
        Bundle main = new Bundle();
        main.putString("PROFILE_NAME", "WS Picking");
        main.putString("PROFILE_ENABLED", "true");
        main.putString("CONFIG_MODE", "CREATE_IF_NOT_EXIST");
        main.putParcelableArrayList("PLUGIN_CONFIG", bundlePluginConfig);
        main.putParcelableArray("APP_LIST", new Bundle[] {myApp});
        Intent i = new Intent();
        i.setAction("com.symbol.datawedge.api.ACTION");
        i.putExtra("com.symbol.datawedge.api.SET_CONFIG", main);
        context.sendBroadcast(i);
    }

    /**
     * Receives the broadcasted intent from DataWedge upon a scan.
     */
    private final BroadcastReceiver myBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (INTENT_ACTION_BARCODE.equals(action)) {
                //  Received a barcode scan
                final String decodedData = intent.getStringExtra("com.symbol.datawedge.data_string");
                synchronized (this) {
                    if (mListener != null) {
                        if (DEBUG) Log.e(TAG, "Received Message: " + decodedData);
                        mListener.onScan(decodedData);
                    }
                }
            }
        }
    };

    /**
     * Set a listener for new scan data.
     * @param listener {@link OnScanListener} to receive a callback for new scan data
     */
    public void setOnScanListener(OnScanListener listener) {
        synchronized (this) {
            mListener = listener;
        }
    }

    /**
     * Interface for handling when new scan data has been received.
     */
    public interface OnScanListener {
        /**
         * Callback to handle a scanned barcode.
         * @param data String of the barcode content
         */
        void onScan(String data);
    }
}
