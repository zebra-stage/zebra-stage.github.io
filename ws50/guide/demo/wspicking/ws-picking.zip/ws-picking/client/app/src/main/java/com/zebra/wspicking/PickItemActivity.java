// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityPickItemBinding;
import com.zebra.wspicking.databinding.DialogEditNoteBinding;
import com.zebra.wspicking.databinding.DialogEditQuantityBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity for picking an item.
 */
public class PickItemActivity extends AppCompatActivity implements ScanReceiver.OnScanListener {
    private static final String TAG = "PickItemActivity";

    private static class Product {
        private final JSONObject json;
        private final String productName;
        private final String productUpcCode;
        private final String productLocation;
        private final Integer quantity;
        private Integer pickedQuantity;
        private String pickingNote;
        private byte[] image = null;

        Product(JSONObject json) throws JSONException {
            this.json = json;
            productName = json.getString("productName");
            productUpcCode = json.getString("productUpcCode");
            productLocation = json.getString("productLocation");
            quantity = json.getInt("quantity");
            pickedQuantity = json.getInt("pickedQuantity");
            pickingNote = json.isNull("pickingNote") ? null : json.getString("pickingNote");
        }
    }

    private ActivityPickItemBinding ui;
    private final List<Product> products = new ArrayList<>();
    private int currentProductIndex = 0;
    private ActivityResultLauncher<Intent> updateOrderLauncher;
    private ActivityResultLauncher<Intent> substitutionLauncher;
    private DialogEditNoteBinding activeNoteDialogUi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityPickItemBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ui.back.setOnClickListener((view) -> exitConfirmation());
        ui.previous.setOnClickListener((view) -> {
            if (currentProductIndex == 0) return;
            --currentProductIndex;
            showProduct();
        });
        ui.next.setOnClickListener((view) -> {
            if (currentProductIndex >= products.size() - 1) return;
            ++currentProductIndex;
            showProduct();
        });

        ui.quantity.setOnClickListener((view) -> showEditQuantityDialog());
        ui.addNote.setOnClickListener((view) -> showEditNoteDialog());

        // Handle back button/gesture.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                exitConfirmation();
            }
        });

        // Register for the result of loading the order, in order to update the UI.
        ActivityResultLauncher<Intent> orderLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                        Log.e(TAG, "Failed to load order");
                        error(R.string.error_loading_orders);
                        finish();
                        return;
                    }
                    String json = result.getData().getStringExtra(ModalServerOpActivity.EXTRA_RESPONSE);
                    JSONArray jsonProducts;
                    try {
                        if (json == null) throw new NullPointerException("Order JSON is null");
                        JSONObject jsonOrder = new JSONObject(json);
                        jsonProducts = jsonOrder.getJSONArray("orderProducts");
                    } catch (NullPointerException|JSONException e) {
                        Log.e(TAG, "Failed to parse order JSON: " + json, e);
                        error(R.string.error_loading_orders);
                        finish();
                        return;
                    }
                    products.clear();
                    for (int i = 0; i < jsonProducts.length(); i++) {
                        JSONObject jsonProduct = null;
                        try {
                            jsonProduct = jsonProducts.getJSONObject(i);
                            products.add(new Product(jsonProduct));
                        } catch (JSONException e) {
                            Log.e(TAG, "Failed to parse product JSON object " + jsonProduct, e);
                        }
                    }
                    if (products.isEmpty()) {
                        Log.e(TAG, "No products in order");
                        error(R.string.no_products_in_order);
                        finish();
                        return;
                    }
                    // Update the UI.
                    showNextUnfulfilledProduct(0);
                }
        );

        // Register for the result of updating the order, for finishing this activity.
        updateOrderLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        finish();
                    } else {
                        Log.e(TAG, "Failed to update order status");
                    }
                }
        );

        // Register for the result of the substitution activity.
        substitutionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                    String substitutionNote = result.getData().getStringExtra(SubstitutionActivity.EXTRA_RESPONSE);
                    if (substitutionNote == null || activeNoteDialogUi == null) return;
                    StringBuilder note = new StringBuilder(activeNoteDialogUi.note.getText().toString());
                    if (note.length() != 0) note.append('\n');
                    note.append(substitutionNote);
                    activeNoteDialogUi.note.setText(note);
                    activeNoteDialogUi = null;
                }
        );

        // Load the full order detail including products.
        Intent i = new Intent(this, ModalServerOpActivity.class);
        i.putExtra(ModalServerOpActivity.EXTRA_MESSAGE, getString(R.string.loading_order));
        i.putExtra(ModalServerOpActivity.EXTRA_URL, "order");
        i.putExtra(ModalServerOpActivity.EXTRA_METHOD, "GET");
        orderLauncher.launch(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ScanReceiver.mInstance.setOnScanListener(this);
    }

    @Override
    protected void onPause() {
        ScanReceiver.mInstance.setOnScanListener(null);
        super.onPause();
    }

    /**
     * Show exit confirmation dialog.
     */
    private void exitConfirmation() {
        // Check if there are unpicked items.
        boolean allPicked = true;
        boolean allPickedOrNoted = true;
        for (Product product : products) {
            if (product.pickedQuantity >= product.quantity) continue;
            allPicked = false;
            if (product.pickingNote == null || product.pickingNote.isEmpty()) allPickedOrNoted = false;
            if (!allPicked && !allPickedOrNoted) break;
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this, R.style.DarkAlertDialog)
                .setTitle(R.string.stop_picking_confirmation);
        boolean canComplete = allPicked || allPickedOrNoted;
        List<Integer> optionResources = new ArrayList<>();
        if (canComplete) optionResources.add(allPicked ? R.string.complete : R.string.exceptions);
        optionResources.add(R.string.pause);
        optionResources.add(android.R.string.cancel);
        CharSequence[] options = new CharSequence[optionResources.size()];
        for (int i = 0; i < optionResources.size(); i++) options[i] = getString(optionResources.get(i));
        dialog.setItems(options, (dlg, which) -> {
                int resource = optionResources.get(which);
                String newStatus = resource == R.string.complete ? "COMPLETED"
                        : resource == R.string.exceptions ? "PICKED_WITH_EXCEPTIONS"
                        : resource == R.string.pause ? "PICKING_PAUSED"
                        : null;
                if (newStatus == null) return;
                try {
                    JSONObject payload = new JSONObject();
                    payload.put("status", newStatus);

                    Intent i = new Intent(this, ModalServerOpActivity.class);
                    i.putExtra(ModalServerOpActivity.EXTRA_MESSAGE, getString(R.string.updating_order));
                    i.putExtra(ModalServerOpActivity.EXTRA_URL, "updateOrderStatus");
                    i.putExtra(ModalServerOpActivity.EXTRA_METHOD, "PATCH");
                    i.putExtra(ModalServerOpActivity.EXTRA_DATA, payload.toString());
                    i.putExtra(ModalServerOpActivity.EXTRA_CONTENT_TYPE, "application/json; charset=utf-8");
                    updateOrderLauncher.launch(i);
                } catch (JSONException e) {
                    Log.e(TAG, "Failed to create JSON payload for order status", e);
                    error(R.string.error);
                }
        });
        dialog.show();
    }

    /**
     * Show the current product details on screen.
     */
    private void showProduct() {
        Product product = products.get(currentProductIndex);
        ServerSession.mInstance.registerUrls(product.json);
        ui.name.setText(product.productName);
        ui.location.setText(product.productLocation);
        ui.quantity.setText(getString(R.string.pick_quantities, product.pickedQuantity, product.quantity));
        ui.note.setText(product.pickingNote != null ? product.pickingNote : "");
        if (product.image != null) {
            ui.image.setImageBitmap(BitmapFactory.decodeByteArray(product.image, 0, product.image.length));
        } else {
            ui.image.setImageResource(R.drawable.outline_no_photography_24);
            // Load the product image.
            ServerSession.mInstance.getRaw("image", new ServerSession.HttpRawCallback() {
                @Override
                public void onSuccess(byte[] response, int statusCode) {
                    runOnUiThread(() -> {
                        product.image = response;
                        // Update screen only if still viewing the same product.
                        if (product == products.get(currentProductIndex)) ui.image.setImageBitmap(
                                BitmapFactory.decodeByteArray(response, 0, response.length));
                    });
                }

                @Override
                public void onError(String error) {
                    Log.e(TAG, "Failed to get product image: " + error);
                }
            });
        }
        boolean nextEnabled = currentProductIndex < products.size() - 1;
        ui.next.setEnabled(nextEnabled);
        ui.next.setAlpha(nextEnabled ? 1.0f : 0.5f);
        boolean previousEnabled = currentProductIndex > 0;
        ui.previous.setEnabled(previousEnabled);
        ui.previous.setAlpha(previousEnabled ? 1.0f : 0.5f);
    }

    @Override
    public void onScan(String data) {
        if (products.isEmpty()) return;     // not initialized yet
        // Find the product with the scanned UPC code. Likely the current index will match, so
        // optimize for that case.
        int index = currentProductIndex;
        if (!products.get(index).productUpcCode.equals(data)) {
            index = -1;
            for (int i = 0; i < products.size(); ++i) {
                if (!products.get(i).productUpcCode.equals(data)) continue;
                index = i;
                break;
            }
        }
        if (index == -1) {
            error(R.string.incorrect_product_scanned);
            return;
        }
        Product product = products.get(index);
        if (product.pickedQuantity >= product.quantity) {
            error(R.string.too_many_items_scanned);
            return;
        }
        adjustPickedQuantity(index, product.pickedQuantity + 1);
    }

    /**
     * Adjust the picked quantity for a product, updating the server and the UI.
     *
     * @param index The index of the product to adjust.
     * @param pickedQuantity The new picked quantity.
     */
    private void adjustPickedQuantity(int index, int pickedQuantity) {
        // Update picked quantity.
        Product product = products.get(index);
        product.pickedQuantity = pickedQuantity;

        // Update server.
        updateServerQuantity(product);

        // Update UI.
        runOnUiThread(() -> {
            if (index == currentProductIndex) {
                ui.quantity.setText(getString(R.string.pick_quantities, pickedQuantity, product.quantity));
            } else {
                currentProductIndex = index;
                showProduct();
            }

            // If more of this product needs picking, that's all for now.
            if (pickedQuantity < product.quantity) return;

            showNextUnfulfilledProduct(index + 1);
        });
    }

    /**
     * Updates the picked quantity on the server.
     * @param product The product to update.
     */
    private void updateServerQuantity(Product product) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("pickedQuantity", product.pickedQuantity);
        } catch (JSONException e) {
            Log.e(TAG, "Failed to create JSON payload", e);
            return;
        }

        // Call the API to update the picked Quantity
        ServerSession.mInstance.registerUrls(product.json);
        ServerSession.mInstance.patch("updatePickedDetails", payload.toString(), "application/json; charset=utf-8", new ServerSession.HttpCallback() {
            @Override
            public void onSuccess(String response, int statusCode) {
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to update picked quantity: " + error);
            }
        });
    }

    /**
     * Move to the next unfulfilled product, or finish if all done.
     * @param fromIndex first candidate index to check
     */
    private void showNextUnfulfilledProduct(int fromIndex) {
        for (int offset = 0; offset < products.size(); ++offset) {
            int i = (fromIndex + offset) % products.size();
            if (products.get(i).pickedQuantity < products.get(i).quantity) {
                currentProductIndex = i;
                showProduct();
                return;
            }
        }
        // Everything is picked, exit.
        exitConfirmation();
    }

    /**
     * Show an error message.
     *
     * @param message The resource id of the message to show.
     */
    private void error(int message) {
        runOnUiThread(() -> {
            ui.error.setText(message);
            ui.error.setVisibility(View.VISIBLE);

            // Beep.
            try {
                MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.errorbuzz);
                if (mediaPlayer != null) {
                    mediaPlayer.start();
                    mediaPlayer.setOnCompletionListener(MediaPlayer::release);
                }
            } catch (Exception ignored) {}

            // Vibrate.
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            }

            // Restore view after giving time to read the message.
            ui.main.postDelayed(() -> ui.error.setVisibility(View.GONE), 2000);
        });
    }

    /**
     * Show a dialog to edit the picked quantity.
     */
    private void showEditQuantityDialog() {
        Product product = products.get(currentProductIndex);

        DialogEditQuantityBinding dialogUi = DialogEditQuantityBinding.inflate(getLayoutInflater());
        dialogUi.quantity.setText(String.valueOf(product.pickedQuantity));
        // Handle plus/minus buttons. Note edit field may be blank or invalid, in which case reset
        // to the original number.
        dialogUi.minus.setOnClickListener(v -> {
            int newQuantity;
            try { newQuantity = Integer.parseInt(dialogUi.quantity.getText().toString()) - 1; }
            catch (NumberFormatException ignored) { newQuantity = product.pickedQuantity; }
            if (newQuantity >= 0) dialogUi.quantity.setText(String.valueOf(newQuantity));
        });
        dialogUi.plus.setOnClickListener(v -> {
            int newQuantity;
            try { newQuantity = Integer.parseInt(dialogUi.quantity.getText().toString()) + 1; }
            catch (NumberFormatException ignored) { newQuantity = product.pickedQuantity; }
            if (newQuantity <= product.quantity) dialogUi.quantity.setText(String.valueOf(newQuantity));
        });

        new AlertDialog.Builder(this, R.style.DarkAlertDialog)
                .setTitle(R.string.edit_picked_quantity)
                .setView(dialogUi.getRoot())
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    try {
                        int newPickedQuantity = Integer.parseInt(dialogUi.quantity.getText().toString());
                        if (newPickedQuantity < 0) {
                            error(R.string.picked_quantity_cannot_be_negative);
                        } else if (newPickedQuantity > product.quantity) {
                            error(R.string.picked_quantity_cannot_exceed_total_quantity);
                        } else {
                            adjustPickedQuantity(currentProductIndex, newPickedQuantity);
                        }
                    } catch (NumberFormatException e) {
                        error(R.string.invalid_quantity_entered);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /**
     * Show a dialog to edit the note.
     */
    private void showEditNoteDialog() {
        Product product = products.get(currentProductIndex);
        DialogEditNoteBinding dialogUi = DialogEditNoteBinding.inflate(getLayoutInflater());
        dialogUi.note.setText(product.pickingNote != null ? product.pickingNote : "");
        dialogUi.outOfStock.setOnClickListener(v -> {
            String note = dialogUi.note.getText().toString();
            String oos = getString(R.string.out_of_stock);
            if (note.endsWith(oos)) return;
            if (!note.isEmpty()) dialogUi.note.append("\n");
            dialogUi.note.append(oos);
        });
        dialogUi.substitute.setOnClickListener(v -> {
            // Get details from the Substitution activity.
            activeNoteDialogUi = dialogUi;
            substitutionLauncher.launch(new Intent(this, SubstitutionActivity.class));
        });
        new AlertDialog.Builder(this, R.style.DarkAlertDialog)
                .setTitle(R.string.edit_note)
                .setView(dialogUi.getRoot())
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String newNote = dialogUi.note.getText().toString();
                    product.pickingNote = newNote.isEmpty() ? null : newNote;

                    // Update server.
                    JSONObject payload = new JSONObject();
                    try {
                        payload.put("pickingNote", product.pickingNote != null ? product.pickingNote
                                : JSONObject.NULL);
                    } catch (JSONException e) {
                        Log.e(TAG, "Failed to create JSON payload", e);
                        return;
                    }
                    ServerSession.mInstance.registerUrls(product.json);
                    ServerSession.mInstance.patch("updatePickedDetails", payload.toString(), "application/json; charset=utf-8", new ServerSession.HttpCallback() {
                        @Override
                        public void onSuccess(String response, int statusCode) {
                        }

                        @Override
                        public void onError(String error) {
                            Log.e(TAG, "Failed to update picking note: " + error);
                        }
                    });

                    // Update UI.
                    ui.note.setText(product.pickingNote != null ? product.pickingNote : "");
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
