// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityOrderListBinding;
import com.zebra.wspicking.databinding.ListitemOrderBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity displaying the list of picking orders.
 */
public class OrderListActivity extends AppCompatActivity {
    private static final String TAG = "OrderListActivity";

    /**
     * Data class representing an order summary, for choosing what order to pick.
     */
    static class Order {
        JSONObject json;
        Long id;
        String customerName;
        String status;
        boolean hasPicker;
        boolean hasTargetedPickers;
        boolean highPriority;
        String note;
        Long productCount;

        Order(JSONObject jsonOrder) throws JSONException {
            json = jsonOrder;
            id = jsonOrder.getLong("id");
            customerName = jsonOrder.getString("customerName");
            status = jsonOrder.getString("status");
            JSONObject picker = jsonOrder.optJSONObject("picker");
            hasPicker = picker != null;
            JSONArray targetedPickers = jsonOrder.getJSONArray("targetedPickers");
            hasTargetedPickers = targetedPickers.length() > 0;
            highPriority = jsonOrder.getBoolean("highPriority");
            note = jsonOrder.isNull("note") ? null : jsonOrder.getString("note");
            productCount = jsonOrder.getLong("productCount");
        }
    }
    private final List<Order> orders = new ArrayList<>();

    private ActivityOrderListBinding ui;
    private ActivityResultLauncher<Intent> orderListLauncher;
    private ActivityResultLauncher<Intent> pickerStatusUpdateLauncher;
    private ActivityResultLauncher<Intent> pickItemLauncher;
    private Long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityOrderListBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        userId = intent.getLongExtra("userId", -1);
        if (userId == -1) {
            Log.e(TAG, "Invalid or missing userId in intent extras");
            new AlertDialog.Builder(this, R.style.DarkAlertDialog)
                    .setTitle(R.string.error_title)
                    .setMessage(R.string.error_invalid_userid)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> finish())
                    .show();
            return;
        }

        ui.back.setOnClickListener(view -> showLogoutConfirmation());
        ui.refresh.setOnClickListener(view -> loadOrders());
        ui.orders.setAdapter(new DisplayAdapter(this, orders));

        // Handle back button/gesture
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showLogoutConfirmation();
            }
        });

        // Register for order list results, so we can display the loaded order list.
        orderListLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                        ui.message.setText(R.string.error_loading_orders);
                        ui.message.setVisibility(View.VISIBLE);
                        return;
                    }
                    String json = result.getData().getStringExtra(ModalServerOpActivity.EXTRA_RESPONSE);
                    if (json == null) return;
                    JSONArray jsonArray;
                    try {
                        jsonArray = new JSONArray(json);
                    } catch (JSONException e) {
                        Log.e(TAG, "Failed to parse orders JSON " + json, e);
                        ui.message.setText(R.string.error_loading_orders);
                        ui.message.setVisibility(View.VISIBLE);
                        return;
                    }
                    orders.clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonOrder = null;
                        try {
                            jsonOrder = jsonArray.getJSONObject(i);
                            orders.add(new Order(jsonOrder));
                        } catch (JSONException e) {
                            Log.e(TAG, "Failed to parse order JSON object " + jsonOrder, e);
                        }
                    }
                    // Update the UI.
                    ((DisplayAdapter) ui.orders.getAdapter()).notifyDataSetChanged();
                    ui.message.setText(R.string.no_orders);
                    ui.message.setVisibility(orders.isEmpty() ? View.VISIBLE : View.GONE);
                }
        );

        // Register for order picker/status update results, so we can launch the picking activity.
        pickerStatusUpdateLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != AppCompatActivity.RESULT_OK) {
                        Log.e(TAG, "Failed to update picker and order status");
                        ui.message.setText(R.string.error_updating_order);
                        ui.message.setVisibility(View.VISIBLE);
                        return;
                    }
                    Intent i = new Intent(this, PickItemActivity.class);
                    pickItemLauncher.launch(i);
                }
        );

        // Register for pick item activity results, so we can reload the order list upon return.
        pickItemLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> loadOrders()
        );

        loadOrders();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) ServerSession.mInstance.post("logout", null, null, null);
        super.onDestroy();
    }

    /**
     * Show logout confirmation dialog.
     */
    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this, R.style.DarkAlertDialog)
                .setTitle(R.string.logout_confirmation_title)
                .setPositiveButton(R.string.yes, (dialog, which) -> finish())
                .setNegativeButton(R.string.no, null)
                .show();
    }

    /**
     * Load orders from the server.
     */
    private void loadOrders() {
        Intent i = new Intent(this, ModalServerOpActivity.class);
        i.putExtra(ModalServerOpActivity.EXTRA_MESSAGE, getString(R.string.loading_orders));
        i.putExtra(ModalServerOpActivity.EXTRA_URL, "pickableSummaries");
        i.putExtra(ModalServerOpActivity.EXTRA_METHOD, "GET");
        orderListLauncher.launch(i);
    }

    /**
     * Adapter for displaying orders in the list.
     */
    private static class DisplayAdapter extends ArrayAdapter<Order> {
        private final OrderListActivity activity;

        /**
         * Constructor.
         * @param context Android context to pass to the superclass
         * @param objects list of orders to display
         */
        DisplayAdapter(OrderListActivity context, List<Order> objects) {
            super(context, -1, objects);
            activity = context;
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            ListitemOrderBinding ui;
            if (convertView != null) ui = (ListitemOrderBinding) convertView.getTag();
            else {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                ui = ListitemOrderBinding.inflate(inflater, parent, false);
                convertView = ui.getRoot();
                convertView.setTag(ui);
            }
            final Order order = getItem(position);
            if (order == null) return convertView;

            ui.inProgress.setVisibility(order.status.equals("READY_TO_PICK") ? View.GONE : View.VISIBLE);
            ui.assigned.setImageResource(order.hasPicker ? R.drawable.baseline_star_24 : R.drawable.outline_star_24);
            ui.assigned.setVisibility(order.hasPicker || order.hasTargetedPickers ? View.VISIBLE : View.GONE);
            ui.highPriority.setVisibility(order.highPriority ? View.VISIBLE : View.GONE);
            ui.summary.setText(getContext().getString(R.string.order_id, order.id));
            ui.detail.setText(getContext().getResources().getQuantityString(R.plurals.order_detail, order.productCount.intValue(), order.productCount, order.customerName));
            ui.note.setText(order.note);
            ui.note.setVisibility(order.note != null ? View.VISIBLE : View.GONE);

            ui.item.setOnClickListener(view -> {
                ServerSession.mInstance.registerUrls(order.json);

                // Update the picker and order status on the server, and redirect
                // to the picking activity upon success.
                JSONObject payload = new JSONObject();
                try {
                    payload.put("pickerUserId", activity.userId);
                    payload.put("status", "PICKING_IN_PROGRESS");
                } catch (JSONException e) {
                    Log.e(TAG, "Failed to create JSON payload", e);
                    return;
                }

                Intent i = new Intent(activity, ModalServerOpActivity.class);
                i.putExtra(ModalServerOpActivity.EXTRA_MESSAGE, activity.getString(R.string.updating_order));
                i.putExtra(ModalServerOpActivity.EXTRA_URL, "updateOrderStatusAndPicker");
                i.putExtra(ModalServerOpActivity.EXTRA_METHOD, "PATCH");
                i.putExtra(ModalServerOpActivity.EXTRA_DATA, payload.toString());
                i.putExtra(ModalServerOpActivity.EXTRA_CONTENT_TYPE, "application/json; charset=utf-8");
                activity.pickerStatusUpdateLauncher.launch(i);
            });
            return convertView;
        }
    }
}
