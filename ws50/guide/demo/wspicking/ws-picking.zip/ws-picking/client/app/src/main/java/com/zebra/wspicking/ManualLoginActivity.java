// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zebra.wspicking.databinding.ActivityManualLoginBinding;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Activity for manual login.
 */
public class ManualLoginActivity extends AppCompatActivity {

    private ActivityManualLoginBinding ui;
    private boolean loginInProgress = false;
    private ActivityResultLauncher<Intent> loginLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ui = ActivityManualLoginBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(ui.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ui.username.requestFocus();
        ui.back.setOnClickListener(view -> finish());
        ui.password.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                // Warning: This event gets called twice when Enter is pressed! Hence the debouncing
                // logic in the logIn routine.
                logIn();
                return true;
            }
            return false;
        });
        ui.login.setOnClickListener(view -> logIn());

        // Handle the result of the login request performed in ModalServerOpActivity.
        loginLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK) {
                        finish();   // error already shown in ModalServerOpActivity so just exit
                        return;
                    }
                    try {
                        String json = result.getData().getStringExtra(ModalServerOpActivity.EXTRA_RESPONSE);
                        JSONObject response = new JSONObject(json);
                        showMessage(true, getString(R.string.logged_in_as,
                                response.getString("fullName")));
                        Long userId = response.getLong("id");
                        ServerSession.mInstance.registerUrls(response);
                        ui.main.postDelayed(() -> {
                            Intent i = new Intent(ManualLoginActivity.this, OrderListActivity.class);
                            i.putExtra("userId", userId);
                            startActivity(i);
                            finish();
                        }, 1000);
                    } catch (JSONException|NullPointerException error) {
                        showMessage(false, getString(R.string.internal_communication_error));
                        ui.main.postDelayed(this::finish, 1000);
                    }
                }
        );
    }

    /**
     * Sends the login request to the server and handles the response. On success, navigates to the
     * OrderListActivity. On failure, shows an error message and returns to the LoginActivity after
     * a delay.
     */
    private void logIn() {
        // Debounce so only one login attempt can be in progress at a time.
        if (loginInProgress) return;
        loginInProgress = true;

        // Hide the keyboard.
        View view = getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        // Perform the login request in the ModalServerOpActivity, to show a message while waiting.
        JSONObject data = new JSONObject();
        try {
            data.put("username", ui.username.getText().toString());
            data.put("password", ui.password.getText().toString());
        }
        catch (JSONException ignored) {}    // will never happen since we're putting simple strings

        Intent i = new Intent(this, ModalServerOpActivity.class);
        i.putExtra(ModalServerOpActivity.EXTRA_MESSAGE, getString(R.string.logging_in));
        i.putExtra(ModalServerOpActivity.EXTRA_URL, "login");
        i.putExtra(ModalServerOpActivity.EXTRA_METHOD, "POST");
        i.putExtra(ModalServerOpActivity.EXTRA_DATA, data.toString());
        i.putExtra(ModalServerOpActivity.EXTRA_CONTENT_TYPE, "application/json; charset=utf-8");
        loginLauncher.launch(i);
    }

    /**
     * Shows a message to the user. If the login was unsuccessful, also changes the background color
     * to red to make it more visible.
     * @param success true if the login was successful, false otherwise
     * @param message the message to show to the user
     */
    private void showMessage(boolean success, String message) {
        ui.main.setBackgroundColor(success ? Color.GREEN : Color.RED);
        ui.message.setText(message);
        ui.message.setVisibility(View.VISIBLE);
        ui.controls.setVisibility(View.GONE);
    }
}
