# emc-wbu-ws-picking
WS Picking app, an MVP sample application featuring BOPIS picking on a WS device with a real server back end
