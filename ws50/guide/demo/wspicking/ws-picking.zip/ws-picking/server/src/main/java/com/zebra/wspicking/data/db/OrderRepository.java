// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.db;

import com.zebra.wspicking.data.Order;
import com.zebra.wspicking.data.OrderStatus;
import com.zebra.wspicking.data.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for Order entity.
 */
@SuppressWarnings("unused")
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    // Find all orders sorted by order ID
    List<Order> findAllByOrderByIdAsc();

    // Find orders by status
    List<Order> findByStatus(OrderStatus status);

    // Find orders by customer name containing a string (case-insensitive)
    List<Order> findByCustomerNameContainingIgnoreCase(String customerName);

    // Find orders by picker user ID
    List<Order> findByPicker(User picker);

    // Find orders by high priority flag
    List<Order> findByHighPriority(Boolean highPriority);

    // Find orders by status and high priority
    List<Order> findByStatusAndHighPriority(OrderStatus status, Boolean highPriority);

    // Find orders assigned to a specific targeted picker
    @Query("SELECT o FROM Order o JOIN o.targetedPickers t WHERE t = :user")
    List<Order> findByTargetedPicker(@Param("user") User user);

    // Custom query to find orders for a specific potential picker based on complex criteria
    @Query("SELECT o FROM Order o " +
            "WHERE o.status <> com.zebra.wspicking.data.OrderStatus.COMPLETED " +
            "AND o.status <> com.zebra.wspicking.data.OrderStatus.PICKED_WITH_EXCEPTIONS " +
            "AND (o.picker IS NULL OR o.picker.id = :pickerId) " +
            "AND ((o.picker IS NOT NULL AND o.picker.id = :pickerId) OR SIZE(o.targetedPickers) = 0 OR " +
            "     EXISTS (SELECT tp FROM o.targetedPickers tp WHERE tp.id = :pickerId)) " +
            "ORDER BY o.id ASC")
    List<Order> findOrdersForPicker(@Param("pickerId") Long pickerId);
}
