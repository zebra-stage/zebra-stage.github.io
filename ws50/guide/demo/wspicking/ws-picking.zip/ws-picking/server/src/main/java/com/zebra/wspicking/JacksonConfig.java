// Copyright (c) 2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.openapitools.jackson.nullable.JsonNullableModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

/**
 * Application-wide Jackson configuration.
 * Registers {@link JsonNullableModule} so that {@code JsonNullable} fields in DTOs
 * are correctly serialised / deserialised:
 * <ul>
 *   <li>Absent JSON field  → {@code JsonNullable.undefined()}</li>
 *   <li>JSON {@code null}  → {@code JsonNullable.of(null)}</li>
 *   <li>JSON value         → {@code JsonNullable.of(value)}</li>
 * </ul>
 */
@Configuration
public class JacksonConfig {
    @Bean
    public ObjectMapper objectMapper(Jackson2ObjectMapperBuilder builder) {
        ObjectMapper mapper = builder.build();
        mapper.registerModule(new JsonNullableModule());
        return mapper;
    }
}
