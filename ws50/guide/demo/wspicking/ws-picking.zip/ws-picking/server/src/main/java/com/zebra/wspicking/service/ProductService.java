// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.service;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Product;
import com.zebra.wspicking.data.db.ProductRepository;
import com.zebra.wspicking.data.dto.ProductDTO;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

/**
 * Service layer for product business logic.
 * Handles permission checks and product operations.
 */
@SuppressWarnings("unused")
@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderProductService orderProductService;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Get all products.
     */
    public List<ProductDTO> getAllProducts(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_PRODUCTS);
        return productRepository.findAll().stream()
                .map(product -> new ProductDTO(product, session))
                .toList();
    }

    /**
     * Get all product entities.
     */
    public List<Product> getAllProductsEntities() {
        return productRepository.findAll();
    }

    /**
     * Get product by ID.
     */
    public Optional<ProductDTO> getProductById(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_PRODUCTS);
        return productRepository.findById(id)
                .map(product -> new ProductDTO(product, session));
    }

    /**
     * Get product by UPC code.
     */
    public Optional<ProductDTO> getProductByUpc(String upcCode, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_PRODUCTS);
        return productRepository.findByUpcCode(upcCode)
                .map(product -> new ProductDTO(product, session));
    }

    /**
     * Search products by name.
     */
    public List<Product> searchProducts(String query, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_PRODUCTS);
        return productRepository.findByNameContainingIgnoreCase(query);
    }

    /**
     * Create a new product.
     */
    public Product createProduct(ProductDTO productDTO, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_PRODUCTS);

        if (productRepository.findByUpcCode(productDTO.getUpcCode()).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Product with this upc code already exists.");
        }

        // Scale the image using the loadAndScaleImage method
        byte[] scaledImageBytes = loadAndScaleImage(new ByteArrayInputStream(productDTO.getImageData()));

        // Create a new Product instance
        Product product = new Product(
                productDTO.getName(),
                productDTO.getUpcCode(),
                scaledImageBytes,
                productDTO.getLocation()
        );
        return productRepository.save(product);
    }

    /**
     * Update an existing product.
     */
    @Transactional
    public Product updateProduct(Long id, ProductDTO productDetails, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_PRODUCTS);

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Product not found with ID: " + id));

        product.setName(productDetails.getName());
        product.setUpcCode(productDetails.getUpcCode());
        product.setLocation(productDetails.getLocation());

        if(null != productDetails.getImageData()){
            // Scale the image using the loadAndScaleImage method
            byte[] scaledImageBytes = loadAndScaleImage(new ByteArrayInputStream(productDetails.getImageData()));

            product.setImageData(scaledImageBytes);
        }

        return productRepository.save(product);
    }

    /**
     * Delete a product.
     */
    @Transactional
    public boolean deleteProduct(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_PRODUCTS);

        if(orderProductService.existsByProductId(id)) {
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,
                    String.format("Cannot delete product (Product Id : %d) linked to active orders.", id));
        }

        if (!productRepository.existsById(id)) return false;

        productRepository.deleteById(id);
        return true;
    }

    /**
     * Get product image data.
     */
    public Optional<byte[]> getProductImage(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_PRODUCTS);

        Optional<Product> product = productRepository.findById(id);
        return product.map(Product::getImageData);
    }

    /**
     * Load an image from imageStream, scale it to fit within 300x300 while maintaining an aspect ratio, and return as a JPEG
     * byte array. If loading fails, create a placeholder image.
     *
     * @param imageStream InputStream for the image
     * @return JPEG byte array of the scaled image or placeholder
     */
    public byte[] loadAndScaleImage(InputStream imageStream) {
        try {
            if (imageStream == null) {
                System.out.println("Image not found, creating placeholder");
                return createPlaceholderImage();
            }

            BufferedImage original = ImageIO.read(imageStream);
            if (original == null) {
                System.out.println("Failed to read image, creating placeholder");
                return createPlaceholderImage();
            }

            // Scale image to fit within 300x300.
            boolean wide = original.getWidth() > original.getHeight();
            int w = wide ? 300 : -1;    // -1 keeps aspect ratio
            int h = wide ? -1 : 300;
            Image scaled = original.getScaledInstance(w, h, Image.SCALE_SMOOTH);
            BufferedImage buffered = new BufferedImage(scaled.getWidth(null), scaled.getHeight(null), BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = buffered.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2d.drawImage(scaled, 0, 0, null);
            g2d.dispose();

            ByteArrayOutputStream jpeg = new ByteArrayOutputStream();
            ImageIO.write(buffered, "jpg", jpeg);
            return jpeg.toByteArray();
        } catch (Exception e) {
            System.out.println("Error loading image, creating placeholder: " + e.getMessage());
            return createPlaceholderImage();
        }
    }

    /**
     * Create a simple 300x300 placeholder image with Zebra text.
     * @return JPEG byte array of the placeholder image
     */
    public byte[] createPlaceholderImage() {
        try {
            BufferedImage placeholder = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = placeholder.createGraphics();
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, 300, 300);
            g2d.setColor(Color.BLACK);
            g2d.drawString("No Image", 120, 150);
            g2d.dispose();

            ByteArrayOutputStream jpeg = new ByteArrayOutputStream();
            ImageIO.write(placeholder, "jpg", jpeg);
            return jpeg.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Failed to create placeholder image", e);
        }
    }
}

