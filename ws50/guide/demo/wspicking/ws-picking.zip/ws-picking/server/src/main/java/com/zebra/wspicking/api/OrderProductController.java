// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.zebra.wspicking.data.dto.OrderProductDTO;
import com.zebra.wspicking.service.OrderProductService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.openapitools.jackson.nullable.JsonNullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * Spring Boot REST controller for managing products within orders.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/order-products")
@Validated
public class OrderProductController {

    @Autowired
    private OrderProductService orderProductService;

    /**
     * Get all products for a specific order.
     */
    @GetMapping("/order/{orderId}")
    public ResponseEntity<?> getProductsByOrderId(@PathVariable Long orderId, HttpSession session) {
        return ResponseEntity.ok(orderProductService.getOrderProductsByOrderId(orderId, session));
    }

    /**
     * Get a specific order product by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getOrderProductById(@PathVariable Long id, HttpSession session) {
        Optional<OrderProductDTO> orderProduct = orderProductService.getOrderProductById(id, session);
        return orderProduct.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Get all orders containing a specific product.
     */
    @GetMapping("/product/{productId}")
    public ResponseEntity<?> getOrderProductsByProductId(@PathVariable Long productId, HttpSession session) {
        return ResponseEntity.ok(orderProductService.getOrderProductsByProductId(productId, session));
    }

    /**
     * Add a product to an order.
     */
    @PostMapping
    public ResponseEntity<?> addProductToOrder(@Valid @RequestBody AddProductRequest request, HttpSession session) {
        OrderProductDTO orderProduct = orderProductService.addProductToOrder(
                request.orderId,
                request.productId,
                request.quantity,
                request.pickingNote,
                session
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(orderProduct);
    }

    /**
     * Update an order product (quantity, picked quantity, or note).
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateOrderProduct(
            @PathVariable Long id,
            @Valid @RequestBody UpdateOrderProductRequest request,
            HttpSession session) {
        OrderProductDTO updated = orderProductService.updateOrderProduct(
                id,
                request.quantity,
                request.pickedQuantity,
                request.pickingNote,
                session
        );
        return ResponseEntity.ok(updated);
    }

    /**
     * Update the picked details (picked quantity and/or note) for an order product.
     */
    @PatchMapping("/{id}/picked-details")
    public ResponseEntity<?> updatePickedDetails(
            @PathVariable Long id,
            @Valid @RequestBody UpdatePickedDetailsRequest request,
            HttpSession session) {
        OrderProductDTO updated = orderProductService.updatePickedDetails(
                id,
                request.pickedQuantity,
                request.pickingNote,
                session
        );
        return ResponseEntity.ok(updated);
    }

    /**
     * Remove a product from an order.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> removeProductFromOrder(@PathVariable Long id, HttpSession session) {
        if (orderProductService.removeProductFromOrder(id, session)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Remove all products from an order.
     */
    @DeleteMapping("/order/{orderId}")
    public ResponseEntity<?> removeAllProductsFromOrder(@PathVariable Long orderId, HttpSession session) {
        orderProductService.removeAllProductsFromOrder(orderId, session);
        return ResponseEntity.noContent().build();
    }

    // Request DTOs
    @Getter
    @Setter
    public static class AddProductRequest {
        @NotNull(message = "Order ID must not be null")
        private Long orderId;
        @NotNull(message = "Product ID must not be null")
        private Long productId;
        @NotNull(message = "Quantity must not be null")
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;
        private String pickingNote;
    }

    @Getter
    @Setter
    public static class UpdateOrderProductRequest {
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;
        @Min(value = 0, message = "Picked quantity must be at least 0")
        private Integer pickedQuantity;
        private String pickingNote;
    }

    @Getter
    @Setter
    public static class UpdatePickedDetailsRequest {
        @Min(value = 0, message = "Picked quantity must be at least 0")
        private Integer pickedQuantity;
        private JsonNullable<String> pickingNote = JsonNullable.undefined();
    }
}

