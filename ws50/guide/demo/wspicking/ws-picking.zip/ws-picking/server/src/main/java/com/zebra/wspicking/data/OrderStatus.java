// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data;

/**
 * Enum representing the status of an order in the picking system.
 */
public enum OrderStatus {
    READY_TO_PICK,
    PICKING_IN_PROGRESS,
    PICKING_PAUSED,
    PICKED_WITH_EXCEPTIONS,
    COMPLETED
}
