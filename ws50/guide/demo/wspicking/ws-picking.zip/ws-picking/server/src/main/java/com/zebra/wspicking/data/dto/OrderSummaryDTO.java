// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.dto;

import com.zebra.wspicking.data.Order;
import com.zebra.wspicking.data.OrderStatus;
import jakarta.servlet.http.HttpSession;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Transfer Object for Order entity, summary only (no product list).
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderSummaryDTO {
    private Long id;
    private String customerName;
    private OrderStatus status;
    private UserDTO picker;
    private List<UserDTO> targetedPickers;
    private Boolean highPriority;
    private String note;
    private Long productCount;
    private String orderUrl;
    private String updateOrderStatusUrl;
    private String updateOrderPickerUrl;
    private String updateOrderStatusAndPickerUrl;

    // Constructor from Order entity
    public OrderSummaryDTO(Order order, HttpSession session) {
        id = order.getId();
        customerName = order.getCustomerName();
        status = order.getStatus();
        picker = order.getPicker() != null ? new UserDTO(order.getPicker(), session) : null;
        targetedPickers = order.getTargetedPickers() != null
                ? order.getTargetedPickers().stream().map(u -> new UserDTO(u, session)).toList()
                : new ArrayList<>();
        highPriority = order.isHighPriority();
        note = order.getNote();
        productCount = (long) order.getOrderProducts().size();
        orderUrl = String.format("/api/orders/%d", id);
        updateOrderStatusUrl = String.format("/api/orders/%d/status", id);
        updateOrderPickerUrl = String.format("/api/orders/%d/assign-picker", id);
        updateOrderStatusAndPickerUrl = String.format("/api/orders/%d/status-and-picker", id);
    }
}
