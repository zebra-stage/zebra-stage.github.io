// Copyright (c) 2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
// common.js - Shared UI utilities

// Escape HTML special characters to prevent XSS when inserting dynamic text into innerHTML.
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Show a transient error message banner.
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'auth-error-message';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #fee;
        color: #c33;
        padding: 15px 30px;
        border-radius: 8px;
        border: 1px solid #fcc;
        z-index: 10000;
        font-size: 1.1em;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(errorDiv);
    setTimeout(() => errorDiv.remove(), 5000);
}

