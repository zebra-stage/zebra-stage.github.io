// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.security;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/**
 * Filter to enforce authentication on protected resources. Public resources are accessible without authentication.
 * Unauthenticated access to protected resources results in a redirect to the login page.
 */
@SuppressWarnings("unused")
@Component
public class AuthenticationFilter implements Filter {

    @Autowired
    private SessionManager sessionManager;

    // Endpoints that don't require authentication.
    private static final List<String> PUBLIC_PATHS = Arrays.asList(
            "/",
            "/api/qrcode/generate",
            "/index.html",
            "/login.html",
            "/remote-login.html",
            "/remote-login-success.html"
    );

    // Endpoint paths that should always be accessible.
    private static final List<String> PUBLIC_PREFIXES = Arrays.asList(
            "/api/auth/",
            "/css/",
            "/js/"
    );

    /**
     * Processes incoming requests to enforce authentication on protected resources.
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Prevent caching to avoid showing stale protected content after logout via back button.
        httpResponse.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        httpResponse.setHeader("Pragma", "no-cache");
        httpResponse.setHeader("Expires", "0");

        String path = httpRequest.getRequestURI();
        String queryString = httpRequest.getQueryString();
        String fullPath = queryString != null ? path + "?" + queryString : path;

        // Allow public paths.
        if (isPublicPath(path)) {
            chain.doFilter(request, response);
            return;
        }

        // Check if user is authenticated for protected resources.
        // Note that getSession(false) returns null if no session exists - which is what we want. We don't want to
        // create a session just to check authentication.
        HttpSession session = httpRequest.getSession(false);
        if (session == null || !sessionManager.isAuthenticated(session)) {
            // For API calls, return 401.
            if (path.startsWith("/api/")) {
                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                httpResponse.setContentType("application/json");
                httpResponse.getWriter().write("{\"error\": \"Authentication required\"}");
                return;
            }

            // For HTML pages, redirect to the login page.
            httpResponse.sendRedirect("/login.html?redirect=" + URLEncoder.encode(fullPath, StandardCharsets.UTF_8));
            return;
        }

        // TODO: Additional authorization checks can be added here based on specific page requirements.

        // User is authenticated, proceed.
        chain.doFilter(request, response);
    }

    /**
     * Checks if the requested path is public (does not require authentication).
     * @param path the requested URI path
     * @return true if the path is public, otherwise false
     */
    private boolean isPublicPath(String path) {
        // Check exact matches.
        if (PUBLIC_PATHS.contains(path)) return true;

        // Check prefix matches.
        for (String prefix : PUBLIC_PREFIXES) {
            if (path.startsWith(prefix)) return true;
        }

        return false;
    }

}
