// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Role;
import com.zebra.wspicking.data.dto.UserDTO;
import com.zebra.wspicking.security.SessionManager;
import com.zebra.wspicking.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

/**
 * Spring Boot REST controller for managing users.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/users")
@Validated
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Returns whether the current session user may create users.
     */
    @GetMapping("/canAdd")
    public ResponseEntity<?> canAdd(HttpSession session) {
        boolean canEdit = sessionManager.hasPermission(session, Permission.EDIT_USERS);
        return ResponseEntity.ok(Map.of("canAdd", canEdit));
    }

    /**
     * Get all users.
     */
    @GetMapping
    public ResponseEntity<?> getAllUsers(HttpSession session) {
        return ResponseEntity.ok(userService.getAllUsers(session));
    }

    /**
     * Get user by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id, HttpSession session) {
        Optional<UserDTO> user = userService.getUserById(id, session);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Get user by username.
     */
    @GetMapping("/username/{username}")
    public ResponseEntity<?> getUserByUsername(@PathVariable String username, HttpSession session) {
        Optional<UserDTO> user = userService.getUserByUsername(username, session);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Search users by full name.
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchUsers(
            @RequestParam
            @NotBlank(message = "Query parameter must not be empty")
            @Size(max = 100, message = "Query parameter must not exceed 100 characters")
            String query,
            HttpSession session) {
        return ResponseEntity.ok(userService.searchUsersByFullName(query, session));
    }

    /**
     * Get users by role.
     */
    @GetMapping("/role/{role}")
    public ResponseEntity<?> getUsersByRole(@PathVariable Role role, HttpSession session) {
        return ResponseEntity.ok(userService.getUsersByRole(role, session));
    }

    /**
     * Get enabled users.
     */
    @GetMapping("/enabled")
    public ResponseEntity<?> getEnabledUsers(HttpSession session) {
        return ResponseEntity.ok(userService.getEnabledUsers(session));
    }

    /**
     * Get active users with a specific permission.
     */
    @GetMapping("/permission/{permission}")
    public ResponseEntity<?> getActiveUsersWithPermission(@PathVariable Permission permission, HttpSession session) {
        return ResponseEntity.ok(userService.getActiveUsersWithPermission(permission, session));
    }

    /**
     * Get all roles with their associated permissions.
     * Returns a map of role name -> list of permission names.
     */
    @GetMapping("/roles")
    public ResponseEntity<?> getRolesWithPermissions(HttpSession session) {
        return ResponseEntity.ok(userService.getRolesWithPermissions(session));
    }

    /**
     * Create a new user.
     */
    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody UserService.UserCreationRequest request, HttpSession session) {
        UserDTO savedUser = userService.createUser(request, session);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
    }

    /**
     * Update an existing user.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserService.UserUpdateRequest request,
            HttpSession session) {
        UserDTO updatedUser = userService.updateUser(id, request, session);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Update user password.
     */
    @PatchMapping("/{id}/password")
    public ResponseEntity<?> updatePassword(
            @PathVariable Long id,
            @Valid @RequestBody PasswordUpdateRequest passwordRequest,
            HttpSession session) {
        UserDTO updatedUser = userService.updatePassword(id, passwordRequest.password, session);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Enable or disable a user.
     */
    @PatchMapping("/{id}/enabled")
    public ResponseEntity<?> setUserEnabled(
            @PathVariable Long id,
            @Valid @RequestBody EnabledUpdateRequest enabledRequest,
            HttpSession session) {
        UserDTO updatedUser = userService.setUserEnabled(id, enabledRequest.enabled, session);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Delete a user.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id, HttpSession session) {
        if (userService.deleteUser(id, session)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Request DTOs
    @Getter
    @Setter
    public static class PasswordUpdateRequest {
        @NotBlank(message = "Password must not be blank")
        @Size(min = 5, max = 100, message = "Password must be between 5 and 100 characters")
        private String password;
    }

    @Getter
    @Setter
    public static class EnabledUpdateRequest {
        @NotNull(message = "Enabled must not be null")
        private Boolean enabled;
    }
}

