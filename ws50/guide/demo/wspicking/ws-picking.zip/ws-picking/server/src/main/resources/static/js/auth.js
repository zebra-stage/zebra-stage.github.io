// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
// auth.js - Shared authentication utilities

// Force page reload if restored from back/forward cache after logout.
window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
        // Page was loaded from browser back/forward cache.
        // Force a refresh to revalidate authentication.
        window.location.reload();
    }
});


// Check if user is authenticated and retrieve session data.
async function getSessionDetails() {
    try {
        const response = await fetch('/api/auth/session');
        if (response.ok) {
            const sessionData = await response.json();
            if (sessionData.authenticated) return sessionData;
        }
    } catch (error) {
        console.error('Auth check failed:', error);
    }
    return null;
}

// Logout function
async function logout() {
    try {
        await fetch('/api/auth/logout', { method: 'POST' });
    } catch (error) {
        console.error('Logout failed:', error);
    }
    // Use replace() instead of href to prevent back button from returning to protected page
    window.location.replace('/');
}

// Display user info in header.
function displayUserInfo(sessionData) {
    const userInfoElement = document.getElementById('userInfo');
    if (userInfoElement && sessionData) {
        // Clear existing content.
        userInfoElement.innerHTML = '';

        // Create and append username span with sanitized text.
        const nameSpan = document.createElement('span');
        nameSpan.className = 'user-name';
        nameSpan.textContent = sessionData.fullName; // textContent automatically escapes HTML
        userInfoElement.appendChild(nameSpan);

        // Create and append logout button.
        const logoutBtn = document.createElement('button');
        logoutBtn.className = 'logout-btn';
        logoutBtn.textContent = 'Logout';
        logoutBtn.style.marginLeft = '15px';
        logoutBtn.onclick = logout;
        userInfoElement.appendChild(logoutBtn);
    }
}
