// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.db;

import com.zebra.wspicking.data.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Product entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findAllByOrderByIdDesc();
    // Find products by name containing a string (case-insensitive)
    List<Product> findByNameContainingIgnoreCase(String name);

    // Find product by UPC code (unique)
    Optional<Product> findByUpcCode(String upcCode);

    // Find products by location
    List<Product> findByLocation(String location);
}
