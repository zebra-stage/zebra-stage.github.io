// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.dto;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Product;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.groups.Default;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Data Transfer Object for Product Entity
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProductDTO {

    private Long id;

    @NotBlank(message = "Name is required and cannot be blank")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Location is required and cannot be blank")
    private String location;

    @NotBlank(message = "UPC Code is required and cannot be blank")
    private String upcCode;

    @ToString.Exclude
    @NotNull(message = "Image data cannot be null for a new product", groups = Create.class)
    @NotEmpty(message = "Image data cannot be empty for a new product", groups = Create.class)
    private byte[] imageData;
    @ToString.Exclude
    private String imageUrl;

    /** Whether the current session user may edit this product. Set by the server; never read from client input. */
    private boolean editable;

    public ProductDTO(Product product, HttpSession session) {
        id = product.getId();
        name = product.getName();
        location = product.getLocation();
        upcCode = product.getUpcCode();
        imageUrl = String.format("api/products/%d/image", product.getId());
        editable = SessionManager.checkPermission(session, Permission.EDIT_PRODUCTS);
    }

    /**
     * Interfaces for Grouping Create or Update Product Validations
     */
    public interface Create extends Default {}
    public interface Update extends Default {}
}
