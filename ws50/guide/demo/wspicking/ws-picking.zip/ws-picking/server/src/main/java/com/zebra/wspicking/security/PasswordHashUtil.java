// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * Utility class for password hashing operations. Uses BCrypt, which automatically handles salt generation and is
 * designed to be slow to resist brute-force attacks.
 */
public class PasswordHashUtil {

    private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    /**
     * Hash a password. Generates and includes the salt in the hash.
     *
     * @param password the plain text password
     * @return the hash, including salt
     */
    public static String hashPassword(String password) {
        return encoder.encode(password);
    }

    /**
     * Verify a password against a stored hash.
     *
     * @param password the plain text password to verify
     * @param storedHash the stored hash
     * @return true if password matches, otherwise false
     */
    public static boolean verifyPassword(String password, String storedHash) {
        return encoder.matches(password, storedHash);
    }
}
