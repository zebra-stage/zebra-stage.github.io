// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.service;

import com.zebra.wspicking.data.*;
import com.zebra.wspicking.data.db.OrderProductRepository;
import com.zebra.wspicking.data.db.OrderRepository;
import com.zebra.wspicking.data.db.ProductRepository;
import com.zebra.wspicking.data.dto.OrderProductDTO;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import org.openapitools.jackson.nullable.JsonNullable;

/**
 * Service layer for OrderProduct business logic.
 * Handles operations for managing products within orders.
 */
@SuppressWarnings("unused")
@Service
public class OrderProductService {

    @Autowired
    private OrderProductRepository orderProductRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Get all order products for a specific order.
     */
    public List<OrderProductDTO> getOrderProductsByOrderId(Long orderId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderProductRepository.findByOrderId(orderId).stream().map(OrderProductDTO::new).toList();
    }

    /**
     * Get a specific order product by ID.
     */
    public Optional<OrderProductDTO> getOrderProductById(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderProductRepository.findById(id).map(OrderProductDTO::new);
    }

    /**
     * Add a product to an order.
     */
    @Transactional
    public OrderProductDTO addProductToOrder(Long orderId, Long productId, Integer quantity, String pickingNote, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + orderId));
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found with ID: " + productId));
        if (quantity == null || quantity <= 0) throw new IllegalArgumentException("Quantity must be greater than zero");
        OrderProduct orderProduct = new OrderProduct(order, product, quantity, 0, pickingNote);
        OrderProduct saved = orderProductRepository.save(orderProduct);
        return new OrderProductDTO(saved);
    }

    /**
     * Update an order product (quantity, picked quantity, or note).
     */
    @Transactional
    public OrderProductDTO updateOrderProduct(Long id, Integer quantity, Integer pickedQuantity, String pickingNote, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);
        OrderProduct orderProduct = orderProductRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order product not found with ID: " + id));

        // Validate picked quantity does not exceed total quantity before applying any changes.
        int newQuantity = (quantity != null) ? quantity : orderProduct.getQuantity();
        int newPickedQuantity = (pickedQuantity != null) ? pickedQuantity : orderProduct.getPickedQuantity();
        if (newPickedQuantity > newQuantity) throw new IllegalArgumentException("Picked quantity (" +
                newPickedQuantity + ") cannot exceed total quantity (" + newQuantity + ")");

        if (quantity != null) orderProduct.setQuantity(quantity);
        if (pickedQuantity != null) orderProduct.setPickedQuantity(pickedQuantity);
        if (pickingNote != null) orderProduct.setPickingNote(pickingNote);

        OrderProduct saved = orderProductRepository.save(orderProduct);
        return new OrderProductDTO(saved);
    }

    /**
     * Update the picked details (picked quantity and/or note) for an order product.
     * Either field may be omitted (null / undefined) to leave it unchanged.
     * An explicit JSON null for pickingNote clears the note.
     */
    public OrderProductDTO updatePickedDetails(Long id, Integer pickedQuantity, JsonNullable<String> pickingNote, HttpSession session) {
        sessionManager.requirePermission(session, Permission.PICK_ORDERS);
        OrderProduct orderProduct = orderProductRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order product not found with ID: " + id));

        if (pickedQuantity != null) {
            if (pickedQuantity < 0) throw new IllegalArgumentException("Picked quantity cannot be negative");
            if (pickedQuantity > orderProduct.getQuantity()) throw new IllegalArgumentException("Picked quantity (" +
                    pickedQuantity + ") cannot exceed total quantity (" + orderProduct.getQuantity() + ")");
            orderProduct.setPickedQuantity(pickedQuantity);
        }

        // JsonNullable.undefined() → skip; JsonNullable.of(null) → clear; JsonNullable.of(value) → update
        if (pickingNote.isPresent()) orderProduct.setPickingNote(pickingNote.get());

        OrderProduct saved = orderProductRepository.save(orderProduct);
        return new OrderProductDTO(saved);
    }

    /**
     * Remove a product from an order.
     */
    public boolean removeProductFromOrder(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);
        if (!orderProductRepository.existsById(id)) return false;
        orderProductRepository.deleteById(id);
        return true;
    }

    /**
     * Get all orders that contain a specific product.
     */
    public List<OrderProductDTO> getOrderProductsByProductId(Long productId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderProductRepository.findByProductId(productId).stream().map(OrderProductDTO::new).toList();
    }

    /**
     * Remove all products from an order.
     */
    public void removeAllProductsFromOrder(Long orderId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);
        orderProductRepository.deleteByOrderId(orderId);
    }

    /**
     * Check if any OrderProduct record is available in the DB with the supplied Product ID
     *
     * @param id ID of the product
     * @return boolean true id orders with products are existing in the DB else false
     */
    public boolean existsByProductId(Long id) {
        return orderProductRepository.existsByProductId(id);
    }
}

