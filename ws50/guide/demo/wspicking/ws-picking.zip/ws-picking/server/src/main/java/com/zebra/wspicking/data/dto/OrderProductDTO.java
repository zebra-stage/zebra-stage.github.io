// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.dto;

import com.zebra.wspicking.data.OrderProduct;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object for OrderProduct entity.
 */
@SuppressWarnings("unused")
@Getter
@Setter
@NoArgsConstructor
public class OrderProductDTO {
    private Long id;
    private Long orderId;

    @NotNull(message = "Product ID is required")
    private Long productId;

    private String productName;
    private String productUpcCode;
    private String productLocation;

    @NotNull(message = "Quantity is required")
    @Positive(message = "Quantity must be at least 1")
    private Integer quantity;

    @PositiveOrZero(message = "Picked quantity must not be negative")
    private Integer pickedQuantity;

    private String pickingNote;
    private String imageUrl;
    private String updatePickedDetailsUrl;

    // Constructor from OrderProduct entity
    public OrderProductDTO(OrderProduct orderProduct) {
        id = orderProduct.getId();
        orderId = orderProduct.getOrder() != null ? orderProduct.getOrder().getId() : null;
        productId = orderProduct.getProduct() != null ? orderProduct.getProduct().getId() : null;
        productName = orderProduct.getProduct() != null ? orderProduct.getProduct().getName() : null;
        productUpcCode = orderProduct.getProduct() != null ? orderProduct.getProduct().getUpcCode() : null;
        productLocation = orderProduct.getProduct() != null ? orderProduct.getProduct().getLocation() : null;
        quantity = orderProduct.getQuantity();
        pickedQuantity = orderProduct.getPickedQuantity();
        pickingNote = orderProduct.getPickingNote();
        imageUrl = String.format("/api/products/%d/image", productId);
        updatePickedDetailsUrl = String.format("/api/order-products/%d/picked-details", id);
    }
}

