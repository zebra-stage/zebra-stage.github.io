// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.service;

import com.zebra.wspicking.data.Order;
import com.zebra.wspicking.data.OrderProduct;
import com.zebra.wspicking.data.OrderStatus;
import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.User;
import com.zebra.wspicking.data.db.OrderRepository;
import com.zebra.wspicking.data.db.ProductRepository;
import com.zebra.wspicking.data.db.UserRepository;
import com.zebra.wspicking.data.dto.OrderDTO;
import com.zebra.wspicking.data.dto.OrderProductDTO;
import com.zebra.wspicking.data.dto.OrderSummaryDTO;
import org.openapitools.jackson.nullable.JsonNullable;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service layer for order business logic.
 * Handles permission checks and order operations.
 */
@SuppressWarnings("unused")
@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Get all orders, sorted by ID.
     */
    public List<OrderDTO> getAllOrders(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findAllByOrderByIdAsc().stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Get order by ID.
     */
    public Optional<OrderDTO> getOrderById(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findById(id)
                .map(order -> new OrderDTO(order, session));
    }

    /**
     * Get orders by status.
     */
    public List<OrderDTO> getOrdersByStatus(OrderStatus status, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findByStatus(status).stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Search orders by customer name.
     */
    public List<OrderDTO> searchOrdersByCustomerName(String customerName, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findByCustomerNameContainingIgnoreCase(customerName).stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Get orders assigned to a specific picker.
     */
    public List<OrderDTO> getOrdersByPicker(User picker, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findByPicker(picker).stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Get orders targeted to a specific picker.
     */
    public List<OrderDTO> getOrdersByTargetedPicker(User user, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findByTargetedPicker(user).stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Get high priority orders.
     */
    public List<OrderDTO> getHighPriorityOrders(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findByHighPriority(true).stream()
                .map(order -> new OrderDTO(order, session))
                .toList();
    }

    /**
     * Get order summaries for a specific picker to choose from, sorted appropriately.
     *
     * @param pickerId the picker
     * @param session  the HTTP session
     * @return list of order summaries
     */
    public List<OrderSummaryDTO> getOrderSummariesForPickerId(Long pickerId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        return orderRepository.findOrdersForPicker(pickerId).stream()
                .sorted((o1, o2) -> Integer.compare(pickPriority(o1, pickerId), pickPriority(o2, pickerId)))
                .map(order -> new OrderSummaryDTO(order, session))
                .toList();
    }

    /**
     * Calculate order priority for a given picker.
     *
     * @param order    the order
     * @param pickerId the picker
     * @return priority value, where a lower number = higher priority
     */
    private int pickPriority(Order order, Long pickerId) {
        boolean pickerMatches = order.getPicker() != null && order.getPicker().getId().equals(pickerId);
        boolean isInProgress = order.getStatus() == OrderStatus.PICKING_IN_PROGRESS;
        boolean isPaused = order.getStatus() == OrderStatus.PICKING_PAUSED;
        boolean isReadyToPick = order.getStatus() == OrderStatus.READY_TO_PICK;
        boolean isHighPriority = order.isHighPriority();
        boolean isTargeted = order.getTargetedPickers() != null &&
                order.getTargetedPickers().stream()
                        .anyMatch(u -> u.getId().equals(pickerId));

        // Priority groups (lower number = higher priority):
        if (pickerMatches) {
            // Group 0-1: Picker matches with status IN_PROGRESS or PAUSED
            if (isInProgress || isPaused) return isHighPriority ? 0 : 1;

            // Group 2-3: Picker matches with status READY_TO_PICK
            if (isReadyToPick) return isHighPriority ? 2 : 3;
        }

        // Group 4-5: User is in targeted pickers list
        if (isTargeted) return isHighPriority ? 4 : 5;

        // Group 6-7: Others
        return isHighPriority ? 6 : 7;
    }

    /**
     * Create a new order.
     */
    @Transactional
    public OrderDTO createOrder(OrderDTO request, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);

        // Resolve user IDs to User entities
        User picker = null;
        Long pickerUserId = request.getPickerUserId().isPresent() ? request.getPickerUserId().get() : null;
        if (pickerUserId != null) {
            picker = userRepository.findById(pickerUserId)
                    .orElseThrow(() -> new IllegalArgumentException("Picker user ID " + pickerUserId + " does not exist"));
        }
        List<Long> targetedPickerUserIds = request.getTargetedPickerUserIds().isPresent()
                ? request.getTargetedPickerUserIds().get() : null;
        List<User> targetedPickers = getUsers(targetedPickerUserIds);

        List<OrderProductDTO> orderProducts = request.getOrderProducts();

        // Validate order details.
        String note = request.getNote().isPresent() ? request.getNote().get() : null;
        validateOrderDetails(picker, targetedPickers, orderProducts, note);

        Order order = new Order(
                request.getCustomerName(),
                request.getStatus(),
                picker,
                targetedPickers,
                request.getHighPriority(),
                note
        );
        return saveOrderWithProducts(orderProducts, order, session);
    }

    /**
     * Helper method to get User entities from a list of user IDs.
     *
     * @param userIds List of user IDs
     * @return List of User entities
     * @throws IllegalArgumentException if any user ID is invalid
     */
    private List<User> getUsers(List<Long> userIds) {
        if (userIds == null) return new ArrayList<>();
        List<User> users = userRepository.findAllById(userIds);
        if (users.size() != userIds.size()) {
            // Find missing IDs
            Set<Long> foundIds = users.stream().map(User::getId).collect(Collectors.toSet());
            List<Long> invalidUserIds = userIds.stream().filter(id -> !foundIds.contains(id)).toList();
            throw new IllegalArgumentException("Invalid targeted picker user IDs: " + invalidUserIds);
        }
        return users;
    }

    /**
     * Validate order details before creation or update.
     *
     * @param picker picker
     * @param targetedPickers list of targeted pickers
     * @param orderProducts list of order products
     * @param note order note, or {@code null} if not being set
     */
    private void validateOrderDetails(User picker, List<User> targetedPickers, List<OrderProductDTO> orderProducts, String note) {
        if (picker != null && !picker.getRole().hasPermission(Permission.PICK_ORDERS)) {
            throw new IllegalArgumentException("Picker user ID " + picker.getId() + " does not have PICK_ORDERS permission");
        }

        if (targetedPickers != null) for (User targetedPicker : targetedPickers) {
            if (!targetedPicker.getRole().hasPermission(Permission.PICK_ORDERS)) {
                throw new IllegalArgumentException("Targeted picker user ID " + targetedPicker.getId() + " does not have PICK_ORDERS permission");
            }
        }

        Set<Long> productIds = new HashSet<>();
        for (OrderProductDTO product : orderProducts) {
            if (!productIds.add(product.getProductId())) {
                throw new IllegalArgumentException("Duplicate product ID in order products: " + product.getProductId());
            }
            if (product.getPickedQuantity() != null && product.getPickedQuantity() > product.getQuantity()) {
                throw new IllegalArgumentException("Picked quantity must be between 0 and total quantity for product ID: " + product.getProductId());
            }
        }

        if (note != null && note.length() > 1000) throw new IllegalArgumentException(
                "Note must not exceed 1000 characters");
    }

    /**
     * Update an existing order using {@link OrderDTO}.
     * <p>
     * For every {@link JsonNullable} field in the request:
     * <ul>
     *   <li><b>Absent</b> ({@code JsonNullable.undefined()}) → field is left unchanged.</li>
     *   <li><b>Explicitly {@code null}</b> ({@code JsonNullable.of(null)}) → field is cleared.</li>
     *   <li><b>Present value</b> ({@code JsonNullable.of(value)}) → field is updated.</li>
     * </ul>
     * Plain (non-{@code JsonNullable}) fields: non-null value updates the field.
     */
    @Transactional
    public OrderDTO updateOrder(Long id, OrderDTO request, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);

        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + id));

        // Resolve user IDs to User entities.
        User picker = null;
        boolean updatePicker = false;
        if (request.getPickerUserId().isPresent()) {
            updatePicker = true;
            Long pickerUserId = request.getPickerUserId().get();
            if (pickerUserId != null) {
                picker = userRepository.findById(pickerUserId)
                        .orElseThrow(() -> new IllegalArgumentException("Picker user ID " + pickerUserId + " does not exist"));
            }
            // picker == null here means "clear picker"
        }
        List<User> targetedPickers = null;
        boolean updateTargetedPickers = false;
        if (request.getTargetedPickerUserIds().isPresent()) {
            updateTargetedPickers = true;
            List<Long> ids = request.getTargetedPickerUserIds().get();
            if (ids != null) {
                targetedPickers = getUsers(ids);
            }
            // targetedPickers == null here means "clear targeted pickers"
        }

        // Validate order details.
        String note = request.getNote().isPresent() ? request.getNote().get() : null;
        validateOrderDetails(updatePicker ? picker : null, updateTargetedPickers ? targetedPickers : null,
                request.getOrderProducts() != null ? request.getOrderProducts() : List.of(), note);

        // Update fields if provided.
        if (request.getCustomerName() != null) order.setCustomerName(request.getCustomerName());
        if (request.getStatus() != null) order.setStatus(request.getStatus());
        if (updatePicker) order.setPicker(picker);
        if (updateTargetedPickers) order.setTargetedPickers(targetedPickers != null ? targetedPickers : new ArrayList<>());
        if (request.getHighPriority() != null) order.setHighPriority(request.getHighPriority());
        if (request.getNote().isPresent()) order.setNote(note);

        // Apply order products update.
        if (request.getOrderProducts() != null) {
            if (request.getOrderProducts().isEmpty()) {
                throw new IllegalArgumentException("Order must have at least one product");
            }
            return saveOrderWithProducts(request.getOrderProducts(), order, session);
        }

        return new OrderDTO(orderRepository.save(order), session);
    }

    /**
     * saveOrderWithProducts save given order and its attached order products
     * @param orderProducts List of OrderProductDTO to be added/updated in order
     * @param order   Order Entity
     * @param session current session
     * @return OrderDTO - DTO translation of order Entity
     */
    private OrderDTO saveOrderWithProducts(List<OrderProductDTO> orderProducts, Order order, HttpSession session) {
        if (order.getId() != null) { /* Update Order Request */
            // Remove products no longer in the request
            Set<Long> updatedIds = orderProducts.stream()
                    .map(OrderProductDTO::getId)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
            order.getOrderProducts().stream()
                    .filter(op -> !updatedIds.contains(op.getId()))
                    .toList()
                    .forEach(order::removeProduct);

            // Map existing items
            Map<Long, OrderProduct> existingMap = order.getOrderProducts().stream()
                    .collect(Collectors.toMap(OrderProduct::getId, op -> op));

            // Update or Add
            for (OrderProductDTO dto : orderProducts) {
                OrderProduct entity = existingMap.getOrDefault(dto.getId(), new OrderProduct());
                mapDtoToEntity(dto, entity);
                if (dto.getId() == null) {
                    order.addProduct(entity);
                }
            }
        } else { /* Create Order Request */
            orderProducts.forEach(dto -> order.addProduct(mapDtoToEntity(dto, new OrderProduct())));
        }

        return new OrderDTO(orderRepository.save(order), session);
    }

    /**
     * Map the OrderProductDTO to OrderProduct entity
     * @param dto OrderProductDTO with details added or updated
     * @param entity updated entity to be saved with Order
     * @return OrderProduct
     */
    private OrderProduct mapDtoToEntity(OrderProductDTO dto, OrderProduct entity) {
        int pickedQuantity = dto.getPickedQuantity() != null ? dto.getPickedQuantity() : 0;
        if (pickedQuantity > dto.getQuantity()) {
            throw new IllegalArgumentException("Picked quantity cannot be greater than total quantity");
        }
        entity.setProduct(productRepository.getReferenceById(dto.getProductId()));
        entity.setPickedQuantity(pickedQuantity);
        entity.setQuantity(dto.getQuantity());
        entity.setPickingNote(dto.getPickingNote());
        return entity;
    }

    /**
     * Update order status.
     */
    @Transactional
    public OrderDTO updateOrderStatus(Long id, OrderStatus status, HttpSession session) {
        Order savedOrder = updateOrder(id, status, null, session);
        orderRepository.save(savedOrder);
        return new OrderDTO(savedOrder, session);
    }

    /**
     * Delete an order.
     */
    @Transactional
    public boolean deleteOrder(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_ORDERS);

        if (!orderRepository.existsById(id)) return false;

        orderRepository.deleteById(id);
        return true;
    }

    /**
     * Convenience method: Get orders by picker user ID.
     */
    public List<OrderDTO> getOrdersByPickerId(Long pickerUserId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        Optional<User> user = userRepository.findById(pickerUserId);
        return user.map(u -> orderRepository.findByPicker(u).stream()
                        .map(order -> new OrderDTO(order, session)).toList())
                .orElse(List.of());
    }

    /**
     * Convenience method: Get orders by targeted picker user ID.
     */
    public List<OrderDTO> getOrdersByTargetedPickerId(Long userId, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_ORDERS);
        Optional<User> user = userRepository.findById(userId);
        return user.map(u -> orderRepository.findByTargetedPicker(u).stream()
                        .map(order -> new OrderDTO(order, session)).toList())
                .orElse(List.of());
    }

    /**
     * Convenience method: Assign a picker by user ID.
     * Pass null as pickerUserId to unassign the picker.
     */
    @Transactional
    public OrderDTO assignPickerById(Long orderId, Long pickerUserId, HttpSession session) {
        Order order = updateOrder(orderId, null, pickerUserId, session);
        Order savedOrder = orderRepository.save(order);
        return new OrderDTO(savedOrder, session);
    }

    /**
     * Convenience method: Update status and Assign a picker by user ID.
     */
    @Transactional
    public OrderDTO assignOrderAndUpdateStatus(Long orderId, Long pickerUserId, OrderStatus status, HttpSession session) {
        Order order = updateOrder(orderId, status, pickerUserId, session);
        Order savedOrder = orderRepository.save(order);
        return new OrderDTO(savedOrder, session);
    }

    /**
     * Update the status and/or picker fields of an order.
     *
     * @param orderId      Order Id of the order
     * @param status       status to be updated
     * @param pickerUserId picker to be assigned
     * @param session      current session
     * @return Order
     */
    private Order updateOrder(Long orderId, OrderStatus status, Long pickerUserId, HttpSession session) {
        // Check permissions. With EDIT_ORDERS, all is well.
        if (!sessionManager.hasPermission(session, Permission.EDIT_ORDERS)) {
            // User lacks EDIT_ORDERS. They must at least have PICK_ORDERS to proceed.
            if (!sessionManager.hasPermission(session, Permission.PICK_ORDERS)) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Missing required permissions.");
            }
            // Even with PICK_ORDERS, they can only assign to themselves or update status.
            if (pickerUserId != null && !pickerUserId.equals(sessionManager.getCurrentUser(session).getId())) {
                throw new ResponseStatusException(HttpStatus.FORBIDDEN, "User cannot assign orders to other users.");
            }
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + orderId));

        if (pickerUserId != null) { /* When Picker Assignment is request, either along with status or individually */
            User picker = userRepository.findById(pickerUserId)
                    .orElseThrow(() -> new IllegalArgumentException("Picker user ID " + pickerUserId + " does not exist"));
            if (!picker.getRole().hasPermission(Permission.PICK_ORDERS)) {
                throw new IllegalArgumentException("Picker user ID " + picker.getId() + " does not have PICK_ORDERS permission");
            }
            order.setPicker(picker);
        } else if (null == status) { /* To de-Assign only picker, PickerId will be null and the Status is null as well */
            order.setPicker(null);
        }
        //In case of Status Update is requested, Status will be not null
        Optional.ofNullable(status).ifPresent(order::setStatus);
        return order;
    }

}

