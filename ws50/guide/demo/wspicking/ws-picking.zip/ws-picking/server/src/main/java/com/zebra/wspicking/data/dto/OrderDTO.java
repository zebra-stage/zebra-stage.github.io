// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.dto;

import com.zebra.wspicking.data.Order;
import com.zebra.wspicking.data.OrderStatus;
import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.openapitools.jackson.nullable.JsonNullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Data Transfer Object for Order entity.
 * Uses UserDTO instead of User to exclude sensitive information like password hashes.
 * <p>
 * For update requests, fields backed by {@link JsonNullable} follow this convention:
 * <ul>
 *   <li>Field <b>absent</b> from the JSON body → {@code JsonNullable.undefined()} → left unchanged.</li>
 *   <li>Field explicitly set to <b>{@code null}</b> → {@code JsonNullable.of(null)} → cleared.</li>
 *   <li>Field set to a <b>value</b> → {@code JsonNullable.of(value)} → updated to that value.</li>
 * </ul>
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderDTO {
    private Long id;

    /** Required on create; on update a non-null value replaces the existing name. */
    @NotBlank(message = "Customer name must not be blank", groups = Create.class)
    private String customerName;

    /** Required on create; on update a non-null value replaces the existing status. */
    @NotNull(message = "Order status must be associated with a Status", groups = Create.class)
    private OrderStatus status;

    // --- Response-only fields (never sent back to the service layer) ---
    private UserDTO picker;
    private List<UserDTO> targetedPickers;

    // --- JsonNullable fields: absent = no change, null = clear, value = update ---

    /**
     * ID of the picker to assign.
     * Absent → picker unchanged. {@code null} → picker cleared. Value → picker updated.
     */
    private JsonNullable<Long> pickerUserId = JsonNullable.undefined();

    /**
     * List of targeted picker user IDs.
     * Absent → list unchanged. {@code null} → list cleared. Value → list replaced.
     */
    private JsonNullable<List<Long>> targetedPickerUserIds = JsonNullable.undefined();

    /**
     * High-priority flag.
     * On create: required. On update: {@code null} → unchanged. Value → updated.
     */
    @NotNull(message = "Priority must be specified", groups = Create.class)
    private Boolean highPriority;

    /**
     * Order note (max 1000 chars).
     * Absent → unchanged. {@code null} → cleared. Value → updated.
     */
    private JsonNullable<String> note = JsonNullable.undefined();

    /**
     * Order products.
     * On create: required and must be non-empty.
     * On update: {@code null} → unchanged. Value → replaced.
     */
    @NotEmpty(message = "Order must have at least one product", groups = Create.class)
    @Valid
    private List<@NotNull OrderProductDTO> orderProducts;

    /** Whether the current session user may edit this order. Set by the server; never read from client input. */
    private boolean editable;

    // Constructor from Order entity (used for responses)
    public OrderDTO(Order order, HttpSession session) {
        id = order.getId();
        customerName = order.getCustomerName();
        status = order.getStatus();
        picker = order.getPicker() != null ? new UserDTO(order.getPicker(), session) : null;
        targetedPickers = order.getTargetedPickers() != null
                ? order.getTargetedPickers().stream().map(u -> new UserDTO(u, session)).toList()
                : new ArrayList<>();
        highPriority = order.isHighPriority();
        note = order.getNote() != null
                ? JsonNullable.of(order.getNote())
                : JsonNullable.of(null);
        orderProducts = order.getOrderProducts().stream().map(OrderProductDTO::new).toList();
        editable = SessionManager.checkPermission(session, Permission.EDIT_ORDERS)
                && order.getStatus() != OrderStatus.COMPLETED;
    }

    /** Validation group for order creation — enforces required-field constraints. */
    public interface Create {}
}
