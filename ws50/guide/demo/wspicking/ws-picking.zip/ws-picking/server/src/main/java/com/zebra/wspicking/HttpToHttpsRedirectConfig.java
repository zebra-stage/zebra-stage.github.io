// Copyright (c) 2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configures an additional plain-HTTP (port 80) Tomcat connector that redirects
 * requests to the equivalent HTTPS URL. The primary HTTPS connector is already
 * set up via {@code server.ssl.*} / {@code server.port} in
 * {@code application.properties}; this class only adds the second connector.
 */
@Configuration
public class HttpToHttpsRedirectConfig {

    /** The HTTPS port — must match {@code server.port}. */
    @Value("${server.port:443}")
    private int httpsPort;

    /** The plain-HTTP port that should redirect to HTTPS. */
    @Value("${server.http.port:80}")
    private int httpPort;

    /**
     * Replaces the default {@link ServletWebServerFactory} with a customized Tomcat factory
     * that:
     * <ol>
     *   <li>Adds a {@code CONFIDENTIAL} security constraint so Tomcat redirects every
     *       plain-HTTP request to the HTTPS URL.</li>
     *   <li>Registers an additional plain-HTTP connector on {@code server.http.port}.</li>
     * </ol>
     */
    @Bean
    public ServletWebServerFactory servletContainer() {
        TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {
            @Override
            protected void postProcessContext(Context context) {
                // Mark every URL as requiring a secure (CONFIDENTIAL) transport.
                // Tomcat then issues a redirect to the connector's redirectPort.
                SecurityConstraint constraint = new SecurityConstraint();
                constraint.setUserConstraint("CONFIDENTIAL");
                SecurityCollection collection = new SecurityCollection();
                collection.addPattern("/*");
                constraint.addCollection(collection);
                context.addConstraint(constraint);
            }
        };
        tomcat.addAdditionalTomcatConnectors(createHttpConnector());
        return tomcat;
    }

    /** Builds the plain-HTTP connector that points Tomcat's redirect at the HTTPS port. */
    private Connector createHttpConnector() {
        Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
        connector.setScheme("http");
        connector.setSecure(false);
        connector.setPort(httpPort);
        connector.setRedirectPort(httpsPort);
        return connector;
    }
}
