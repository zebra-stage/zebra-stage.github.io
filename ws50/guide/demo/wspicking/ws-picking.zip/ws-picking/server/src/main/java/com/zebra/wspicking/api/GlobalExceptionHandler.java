// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * Spring Boot exception handler for all controllers.
 */
@SuppressWarnings("unused")
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handle constraint violation exceptions (e.g., @NotBlank, @Size validation failures).
     * Returns 400 Bad Request instead of 500 Internal Server Error.
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<?> handleConstraintViolationException(ConstraintViolationException ex) {
        String message = ex.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(", "));

        if (message.isEmpty()) message = "Validation failed";

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("error", message));
    }

    /**
     * Handle method argument not valid exceptions (e.g., @Valid request body validation failures).
     * @param ex the exception
     * @return 400 Bad Request with error details
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        Map<String, String> allErrors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .collect(Collectors.toMap(
                        FieldError::getField,
                        error -> error.getDefaultMessage() != null ? error.getDefaultMessage() : "Invalid value",
                        (existing, replacement) -> existing + "; " + replacement
                ));

        String firstError = allErrors.isEmpty() ? "Validation failed" : allErrors.values().iterator().next();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("error", firstError, "details", allErrors));
    }

    /**
     * Handle illegal argument exceptions (e.g., invalid order/product IDs).
     * And Handles ResponseStatusException thrown (e.g., duplicate upc code for products)
     * Returns 400 Bad Request or ResponseStatusException's Status Code instead of 500 Internal Server Error.
     */
    @ExceptionHandler(exception = {IllegalArgumentException.class, ResponseStatusException.class})
    public ResponseEntity<?> handleRuntimeException(RuntimeException ex) {

        HttpStatusCode statusCode = (ex instanceof ResponseStatusException rsEx)
                ? rsEx.getStatusCode()
                : HttpStatus.BAD_REQUEST;

        return ResponseEntity.status(statusCode)
                .body(Map.of("error", ex.getMessage()));
    }

}
