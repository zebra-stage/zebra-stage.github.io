// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data;

import com.zebra.wspicking.data.db.OrderProductRepository;
import com.zebra.wspicking.data.db.OrderRepository;
import com.zebra.wspicking.data.db.ProductRepository;
import com.zebra.wspicking.data.db.UserRepository;
import com.zebra.wspicking.security.PasswordHashUtil;
import com.zebra.wspicking.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Spring Boot startup runner that initializes the database with sample products, users, and orders if empty.
 */
@SuppressWarnings("unused")
@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderProductRepository orderProductRepository;

    @Autowired
    ProductService productService;

    @Override
    public void run(String... args) {
        // No action needed if the database already exists, which we can check based on whether users exist.
        if (userRepository.count() != 0) {
            System.out.println("Database already initialized. Sample data not added.");
            return;
        }

        // Add sample products.
        System.out.println("Initializing database with sample products...");
        productRepository.save(new Product("Zebra WS501 Wearable Computer", "567890123456",
                productService.loadAndScaleImage(getClass().getResourceAsStream("/images/ws501.jpg")), "A-02-2"));
        productRepository.save(new Product("Zebra WS301 Wearable Computer", "678901234567",
                productService.loadAndScaleImage(getClass().getResourceAsStream("/images/ws301.jpg")), "A-02-3"));
        productRepository.save(new Product("Zebra WS101 Bluetooth Badge", "789012345678",
                productService.loadAndScaleImage(getClass().getResourceAsStream("/images/ws101.jpg")), "B-01-1"));
        productRepository.save(new Product("Zebra TC53e Mobile Computer", "123456789012",
            productService.loadAndScaleImage(getClass().getResourceAsStream("/images/tc53e.jpg")), "A-01-1"));
        productRepository.save(new Product("Zebra DS2208 Barcode Scanner", "234567890123",
            productService.loadAndScaleImage(getClass().getResourceAsStream("/images/ds2208.jpg")), "A-01-2"));
        productRepository.save(new Product("Zebra ZD421 Label Printer", "345678901234",
            productService.loadAndScaleImage(getClass().getResourceAsStream("/images/zd421.jpg")), "A-01-3"));
        productRepository.save(new Product("Zebra MC9450 Mobile Computer", "456789012345",
            productService.loadAndScaleImage(getClass().getResourceAsStream("/images/mc9450.jpg")), "A-02-1"));
        System.out.println("Database initialized with " + productRepository.count() + " products.");

        // Add sample users.
        System.out.println("Initializing database with sample users...");
        final String defaultPassword = "zebra";
        userRepository.save(new User("admin", "System Administrator", PasswordHashUtil.hashPassword(defaultPassword),
                Role.SYSTEM_ADMIN, true));
        userRepository.save(new User("product_admin", "Product Manager", PasswordHashUtil.hashPassword(defaultPassword),
                Role.PRODUCT_ADMIN, true));
        userRepository.save(new User("order_admin", "Order Manager", PasswordHashUtil.hashPassword(defaultPassword),
                Role.ORDER_ADMIN, true));
        userRepository.save(new User("john", "John Smith", PasswordHashUtil.hashPassword(defaultPassword),
                Role.PICKER, true));
        userRepository.save(new User("jane", "Jane Doe", PasswordHashUtil.hashPassword(defaultPassword),
                Role.PICKER, true));
        userRepository.save(new User("guest", "Guest User", PasswordHashUtil.hashPassword(defaultPassword),
                Role.GUEST, true));
        System.out.println("Database initialized with " + userRepository.count() + " users.");
        System.out.println("All sample users have password: " + defaultPassword);
        System.out.println("** For production use, change these users and passwords! **");

        // Add sample orders.
        System.out.println("Initializing database with sample orders...");
        User john = userRepository.findByUsername("john").orElse(null);
        User jane = userRepository.findByUsername("jane").orElse(null);
        // Order 1: High priority order ready to pick, targeted to John
        orderRepository.save(new Order("Alice Johnson", OrderStatus.READY_TO_PICK, null,
                john != null ? List.of(john) : List.of(), true,
                "Urgent delivery - customer requested same-day pickup"));
        // Order 2: Regular order ready to pick, targeted to both John and Jane
        orderRepository.save(new Order("Bob Smith", OrderStatus.READY_TO_PICK, null,
                john != null && jane != null ? List.of(john, jane) : List.of(), false,
                "Standard order - customer will pick up tomorrow"));
        // Order 3: Order in progress, assigned to John
        orderRepository.save(new Order("Carol Davis", OrderStatus.PICKING_IN_PROGRESS, john,
                List.of(), false,
                "Customer called to add additional items - check with manager"));
        // Order 4: High priority order in progress, assigned to Jane
        orderRepository.save(new Order("David Wilson", OrderStatus.PICKING_IN_PROGRESS, jane,
                jane != null ? List.of(jane) : List.of(), true,
                "VIP customer - ensure quality packaging"));
        // Order 5: Completed order assigned to John
        orderRepository.save(new Order("Emma Brown", OrderStatus.COMPLETED, john, List.of(),
                false, null));
        // Order 6: Paused order assigned to Jane
        orderRepository.save(new Order("Frank Miller", OrderStatus.PICKING_PAUSED, jane,
                List.of(), false, null));
        // Order 7: Regular order ready to pick, no specific targeting
        orderRepository.save(new Order("Grace Lee", OrderStatus.READY_TO_PICK, null,
                List.of(), false, "Waiting for item restock - pick at 1:00pm Tuesday"));
        System.out.println("Database initialized with " + orderRepository.count() + " orders.");

        // Add sample order products.
        System.out.println("Initializing database with sample order products...");
        java.util.List<Order> orders = orderRepository.findAllByOrderByIdAsc();
        java.util.List<Product> products = productRepository.findAll();
        orderProductRepository.save(new OrderProduct(orders.get(0), products.get(0), 2, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(0), products.get(1), 1, 0,
                "Verify clip mount included"));
        orderProductRepository.save(new OrderProduct(orders.get(0), products.get(2), 3, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(1), products.get(3), 1, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(1), products.get(4), 2, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(2), products.get(0), 3, 2,
                "One item damaged, check replacement"));
        orderProductRepository.save(new OrderProduct(orders.get(2), products.get(5), 1, 1, null));
        orderProductRepository.save(new OrderProduct(orders.get(2), products.get(6), 2, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(3), products.get(1), 1, 1, null));
        orderProductRepository.save(new OrderProduct(orders.get(3), products.get(2), 2, 1, null));
        orderProductRepository.save(new OrderProduct(orders.get(4), products.get(3), 2, 2, null));
        orderProductRepository.save(new OrderProduct(orders.get(4), products.get(4), 1, 1, null));
        orderProductRepository.save(new OrderProduct(orders.get(4), products.get(5), 1, 1, null));
        orderProductRepository.save(new OrderProduct(orders.get(5), products.get(6), 4, 2,
                "Paused - awaiting stock confirmation"));
        orderProductRepository.save(new OrderProduct(orders.get(6), products.get(0), 1, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(6), products.get(2), 1, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(6), products.get(4), 3, 0, null));
        orderProductRepository.save(new OrderProduct(orders.get(6), products.get(6), 1, 0, null));
        System.out.println("Database initialized with " + orderProductRepository.count() + " order products.");
    }
}
