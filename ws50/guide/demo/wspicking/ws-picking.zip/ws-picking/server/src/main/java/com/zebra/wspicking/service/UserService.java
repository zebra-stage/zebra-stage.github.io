// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.service;

import com.zebra.wspicking.data.*;
import com.zebra.wspicking.data.db.UserRepository;
import com.zebra.wspicking.data.dto.UserDTO;
import com.zebra.wspicking.security.PasswordHashUtil;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service layer for user business logic.
 * Handles permission checks and user operations.
 */
@SuppressWarnings("unused")
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Get all users.
     */
    public List<UserDTO> getAllUsers(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findAll().stream()
                .map(user -> new UserDTO(user, session))
                .toList();
    }

    /**
     * Get user by ID.
     */
    public Optional<UserDTO> getUserById(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findById(id)
                .map(user -> new UserDTO(user, session));
    }

    /**
     * Get user by username.
     */
    public Optional<UserDTO> getUserByUsername(String username, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findByUsername(username)
                .map(user -> new UserDTO(user, session));
    }

    /**
     * Search users by full name.
     */
    public List<UserDTO> searchUsersByFullName(String fullName, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findByFullNameContainingIgnoreCase(fullName).stream()
                .map(user -> new UserDTO(user, session))
                .toList();
    }

    /**
     * Get users by role.
     */
    public List<UserDTO> getUsersByRole(Role role, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findByRole(role).stream()
                .map(user -> new UserDTO(user, session))
                .toList();
    }

    /**
     * Get enabled users.
     */
    public List<UserDTO> getEnabledUsers(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findByEnabled(true).stream()
                .map(user -> new UserDTO(user, session))
                .toList();
    }

    /**
     * Get active users with a specific permission.
     */
    public List<UserDTO> getActiveUsersWithPermission(Permission permission, HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return userRepository.findActiveUsersWithPermission(permission).stream()
                .map(user -> new UserDTO(user, session))
                .toList();
    }

    /**
     * Get all roles with their associated permissions.
     * Returns a map of role name -> list of permission names.
     */
    public Map<String, List<String>> getRolesWithPermissions(HttpSession session) {
        sessionManager.requirePermission(session, Permission.VIEW_USERS);
        return Arrays.stream(Role.values())
                .collect(Collectors.toMap(
                        Enum::name,
                        role -> role.permissions.stream()
                                .sorted(Comparator.comparingInt(Enum::ordinal))
                                .map(Enum::name)
                                .collect(Collectors.toList()),
                        (a, b) -> a,
                        LinkedHashMap::new
                ));
    }

    /**
     * Create a new user.
     */
    @Transactional
    public UserDTO createUser(UserCreationRequest request, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_USERS);

        // Validate trimmed lengths
        String trimmedUsername = request.getUsername().trim();
        if (trimmedUsername.length() < 3 || trimmedUsername.length() > 50) throw new IllegalArgumentException(
                "Username must be between 3 and 50 characters (after trimming)");

        String trimmedFullName = request.getFullName().trim();
        if (trimmedFullName.length() < 2 || trimmedFullName.length() > 100) throw new IllegalArgumentException(
                "Full name must be between 2 and 100 characters (after trimming)");

        // Hash the password
        String passwordHash = PasswordHashUtil.hashPassword(request.getPassword());

        User user = new User(
                trimmedUsername,
                trimmedFullName,
                passwordHash,
                request.getRole(),
                request.getEnabled() != null ? request.getEnabled() : true
        );

        try {
            User savedUser = userRepository.save(user);
            return new UserDTO(savedUser, session);
        } catch (DataIntegrityViolationException e) {
            // Database unique constraint violation - username already exists
            if (e.getMessage() != null && e.getMessage().contains("username")) {
                throw new IllegalArgumentException("Username '" + trimmedUsername + "' already exists");
            }
            throw e; // Re-throw if it's a different constraint violation
        }
    }

    /**
     * Update an existing user.
     */
    @Transactional
    public UserDTO updateUser(Long id, UserUpdateRequest request, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_USERS);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));

        // Update username if provided and different
        String newUsername = request.getUsername();
        if (newUsername != null) {
            newUsername = newUsername.trim();
            if (newUsername.length() < 3 || newUsername.length() > 50) throw new IllegalArgumentException(
                    "Username must be between 3 and 50 characters (after trimming)");
            if (!newUsername.equals(user.getUsername())) {
                user.setUsername(newUsername);
            }
        }

        // Update other fields if provided
        if (request.getFullName() != null) {
            String trimmedFullName = request.getFullName().trim();
            if (trimmedFullName.length() < 2 || trimmedFullName.length() > 100) throw new IllegalArgumentException(
                    "Full name must be between 2 and 100 characters (after trimming)");
            user.setFullName(trimmedFullName);
        }
        if (request.getRole() != null) {
            // Check if changing role away from SYSTEM_ADMIN for the last admin
            if (user.getRole() == Role.SYSTEM_ADMIN && request.getRole() != Role.SYSTEM_ADMIN) {
                // Use pessimistic locking to prevent race condition
                long adminCount = userRepository.countByRoleWithLock(Role.SYSTEM_ADMIN);
                if (adminCount <= 1) {
                    throw new IllegalArgumentException("Cannot remove SYSTEM_ADMIN role from the last admin user");
                }
            }
            user.setRole(request.getRole());
        }
        if (request.getEnabled() != null) user.setEnabled(request.getEnabled());

        try {
            User savedUser = userRepository.save(user);
            return new UserDTO(savedUser, session);
        } catch (DataIntegrityViolationException e) {
            // Database unique constraint violation - username already exists
            if (e.getMessage() != null && e.getMessage().contains("username")) {
                throw new IllegalArgumentException("Username '" + newUsername + "' already exists");
            }
            throw e; // Re-throw if it's a different constraint violation
        }
    }

    /**
     * Update user password.
     */
    @Transactional
    public UserDTO updatePassword(Long id, String newPassword, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_USERS);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));

        if (newPassword == null) throw new IllegalArgumentException("Password must not be null");
        newPassword = newPassword.trim();
        if (newPassword.length() < 5 || newPassword.length() > 100) throw new IllegalArgumentException(
                "Password must be between 5 and 100 characters");

        user.setPasswordHash(PasswordHashUtil.hashPassword(newPassword));
        User savedUser = userRepository.save(user);
        return new UserDTO(savedUser, session);
    }

    /**
     * Enable or disable a user.
     */
    @Transactional
    public UserDTO setUserEnabled(Long id, Boolean enabled, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_USERS);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));

        user.setEnabled(enabled);
        User savedUser = userRepository.save(user);
        return new UserDTO(savedUser, session);
    }

    /**
     * Delete a user.
     */
    @Transactional
    public boolean deleteUser(Long id, HttpSession session) {
        sessionManager.requirePermission(session, Permission.EDIT_USERS);

        if (!userRepository.existsById(id)) return false;

        // Validate we are not deleting the last admin user.
        User userToDelete = userRepository.findById(id).orElseThrow();
        if (userToDelete.getRole() == Role.SYSTEM_ADMIN) {
            // Use pessimistic locking to prevent race condition
            long adminCount = userRepository.countByRoleWithLock(Role.SYSTEM_ADMIN);
            if (adminCount <= 1) {
                throw new IllegalArgumentException("Cannot delete the last user with SYSTEM_ADMIN role");
            }
        }

        userRepository.deleteById(id);
        return true;
    }

    /**
     * DTO for creating a new user.
     */
    @Getter
    @Setter
    public static class UserCreationRequest {
        @NotBlank(message = "Username must not be blank")
        @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
        private String username;
        @NotBlank(message = "Full name must not be blank")
        @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters")
        private String fullName;
        @NotBlank(message = "Password must not be blank")
        @Size(min = 5, max = 100, message = "Password must be between 5 and 100 characters")
        private String password;
        @NotNull(message = "Role must not be null")
        private Role role;
        private Boolean enabled;
    }

    /**
     * DTO for updating an existing user.
     */
    @Getter
    @Setter
    public static class UserUpdateRequest {
        @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
        private String username;
        @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters")
        private String fullName;
        private Role role;
        private Boolean enabled;
    }
}

