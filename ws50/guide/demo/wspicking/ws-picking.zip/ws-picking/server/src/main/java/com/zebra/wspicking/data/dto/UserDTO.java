// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.dto;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Role;
import com.zebra.wspicking.data.User;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object for User entity.
 * Excludes sensitive information like password hash.
 */
@Getter
@Setter
@NoArgsConstructor
public class UserDTO {
    private Long id;
    private String username;
    private String fullName;
    private Role role;
    private Boolean enabled;

    /** Whether the current session user may edit/delete this user. Set by the server; never read from client input. */
    private boolean editable;

    /**
     * Constructs a UserDTO from a User entity, computing the {@code editable} flag directly
     * from the current session.
     */
    public UserDTO(User user, HttpSession session) {
        this.id = user.getId();
        this.username = user.getUsername();
        this.fullName = user.getFullName();
        this.role = user.getRole();
        this.enabled = user.getEnabled();
        this.editable = SessionManager.checkPermission(session, Permission.EDIT_USERS);
    }
}
