// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data;

import java.util.Set;

/**
 * User roles within the warehouse picking system, each associated with a set of permissions.
 */
public enum Role {
    // We're using the value ordinals as role ids in the database, so do not change the order of these enum values!
    GUEST(Set.of(Permission.VIEW_PRODUCTS)),
    PICKER(Set.of(Permission.VIEW_PRODUCTS, Permission.VIEW_ORDERS, Permission.PICK_ORDERS)),
    ORDER_ADMIN(Set.of(Permission.VIEW_PRODUCTS, Permission.VIEW_ORDERS, Permission.PICK_ORDERS, Permission.EDIT_ORDERS)),
    PRODUCT_ADMIN(Set.of(Permission.VIEW_PRODUCTS, Permission.EDIT_PRODUCTS, Permission.VIEW_ORDERS, Permission.PICK_ORDERS, Permission.EDIT_ORDERS)),
    SYSTEM_ADMIN(Set.of(Permission.values()));

    public final Set<Permission> permissions;

    Role(Set<Permission> permissions) {
        this.permissions = permissions;
    }

    /**
     * Check if the role has a specific permission.
     * @param permission the permission to check
     * @return true if the role has the permission, otherwise false
     */
    public boolean hasPermission(Permission permission) {
        return permissions.contains(permission);
    }

    /**
     * Get an array of roles that have the specified permission.
     * @param permission the permission to check
     * @return an array of roles with the specified permission
     */
    public static Role[] rolesWithPermission(Permission permission) {
        return java.util.Arrays.stream(Role.values())
            .filter(role -> role.hasPermission(permission))
            .toArray(Role[]::new);
    }
}
