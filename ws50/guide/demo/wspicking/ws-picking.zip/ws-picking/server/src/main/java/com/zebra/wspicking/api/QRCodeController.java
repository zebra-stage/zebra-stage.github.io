// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.UUID;

/**
 * Spring Boot REST controller for generating QR codes for remote login.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/qrcode")
public class QRCodeController {
    private static final int QR_CODE_WIDTH = 300;
    private static final int QR_CODE_HEIGHT = 300;

    @Value("${server.address:}")
    private String serverAddress;

    /**
     * Get the server's actual network IP address for external device access.
     * Prefers configured server.address, falls back to auto-detection.
     */
    private String getServerAddress() {
        // Use configured address if available
        if (serverAddress != null && !serverAddress.trim().isEmpty()) return serverAddress.trim();

        // Auto-detect the server's network IP address.
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();

                // Skip loopback and inactive interfaces
                if (iface.isLoopback() || !iface.isUp()) continue;

                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();

                    // Return the first non-loopback IPv4 address
                    if (!address.isLoopbackAddress() && address.getAddress().length == 4) {
                        return address.getHostAddress();
                    }
                }
            }
        } catch (SocketException ignored) {
        }

        return null;
    }

    /**
     * Generate a QR code for remote login, including a new remote login ID which is present in the QR code and added to
     * the current session.
     *
     * @return PNG image of the generated QR code
     */
    @GetMapping(value = "/generate", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> generateQRCode(HttpServletRequest request, HttpSession session) {
        try {
            // Generate a unique remote login ID, to match the remote device to the login station.
            String loginId = UUID.randomUUID().toString();
            session.setAttribute("remoteLoginId", loginId);

            // Get the server's actual network address (not from the request, which is often localhost).
            String serverName = getServerAddress();
            if (serverName == null) return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

            String scheme = request.getScheme(); // Use the same protocol as the request (http/https)

            // Build the URL with proper port handling (don't show port 80 for http or 443 for https).
            StringBuilder baseUrl = new StringBuilder();
            baseUrl.append(scheme).append("://").append(serverName);
            int serverPort = request.getServerPort();   // note: enable header forwarding if adding a reverse proxy to the setup
            if ((scheme.equals("http") && serverPort != 80) || (scheme.equals("https") && serverPort != 443)) {
                baseUrl.append(":").append(serverPort);
            }

            // Create the QR code content as a JSON object.
            String qrCodeContent = String.format("""
                {
                    "application" : "WS Picking",
                    "baseUrl" : "%s",
                    "loginUrl" : "/api/auth/login",
                    "logoutUrl" : "/api/auth/logout",
                    "remoteLoginUrl" : "/api/auth/start-remote-login?loginId=%s"
                }
                """,
                baseUrl,
                loginId
            );

            // Generate QR code.
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(
                qrCodeContent,
                BarcodeFormat.QR_CODE,
                QR_CODE_WIDTH,
                QR_CODE_HEIGHT
            );

            // Convert to PNG image.
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);
            byte[] qrCodeImage = outputStream.toByteArray();

            // Set response headers.
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_PNG);
            headers.setContentLength(qrCodeImage.length);

            return new ResponseEntity<>(qrCodeImage, headers, HttpStatus.OK);

        } catch (WriterException | IOException ignored) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
