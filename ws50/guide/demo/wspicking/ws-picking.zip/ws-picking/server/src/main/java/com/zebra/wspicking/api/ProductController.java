// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Product;
import com.zebra.wspicking.data.dto.ProductDTO;
import com.zebra.wspicking.security.SessionManager;
import com.zebra.wspicking.service.ProductService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

/**
 * Spring Boot REST controller for managing product definitions.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/products")
@Validated
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Returns whether the current session user may create a new product.
     */
    @GetMapping("/canAdd")
    public ResponseEntity<?> canAdd(HttpSession session) {
        boolean canEdit = sessionManager.hasPermission(session, Permission.EDIT_PRODUCTS);
        return ResponseEntity.ok(Map.of("canAdd", canEdit));
    }

    /**
     * Get all products.
     */
    @GetMapping
    public ResponseEntity<?> getAllProducts(HttpSession session) {
        return ResponseEntity.ok(productService.getAllProducts(session));
    }

    /**
     * Get product by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable @NotNull(message = "Product Id is required") Long id, HttpSession session) {
        Optional<ProductDTO> product = productService.getProductById(id, session);
        return product.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @GetMapping("/upc/{upcCode}")
    public ResponseEntity<?> getProductByUpc(@PathVariable @NotNull(message = "UPC code is required") String upcCode, HttpSession session) {
        Optional<ProductDTO> product = productService.getProductByUpc(upcCode, session);
        return product.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Search products by name.
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchProducts(
            @RequestParam
            @Valid
            @NotBlank(message = "Query parameter must not be empty")
            @Size(max = 100, message = "Query parameter must not exceed 100 characters")
            String query, 
            HttpSession session) {
        return ResponseEntity.ok(productService.searchProducts(query, session));
    }

    /**
     * Create a new product.
      */
    @PostMapping
    public ResponseEntity<?> createProduct(@RequestBody @Validated(ProductDTO.Create.class) ProductDTO productDTO, HttpSession session) {
        Product savedProduct = productService.createProduct(productDTO, session);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct);
    }

    /**
     * Update an existing product.
     * @param id the ID of the product to update
     * @param productDetails the updated product details
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateProduct(@PathVariable Long id, @Valid  @Validated(ProductDTO.Update.class) @RequestBody ProductDTO productDetails,
                                           HttpSession session) {
        Product updatedProduct = productService.updateProduct(id, productDetails, session);
        return ResponseEntity.ok(updatedProduct);
    }

    /**
     * Delete a product.
     * @param id the ID of the product to delete
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable @NotNull(message = "Product Id is required") Long id, HttpSession session) {
        if (productService.deleteProduct(id, session)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get product image.
     * @param id the ID of the product
     * @return the image data in JPEG format
     */
    @GetMapping("/{id}/image")
    public ResponseEntity<?> getProductImage(@PathVariable @NotNull(message = "Product Id is required") Long id, HttpSession session) {
        Optional<byte[]> imageData = productService.getProductImage(id, session);
        return imageData.map(data -> ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_JPEG)
                        .body(data))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
