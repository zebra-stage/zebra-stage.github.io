// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data;

/**
 * Enum representing various permissions within the picking system.
 */
public enum Permission {
    VIEW_PRODUCTS,
    EDIT_PRODUCTS,
    VIEW_ORDERS,
    PICK_ORDERS,
    EDIT_ORDERS,
    VIEW_USERS,
    EDIT_USERS
}
