// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.zebra.wspicking.data.OrderStatus;
import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.dto.OrderDTO;
import com.zebra.wspicking.security.SessionManager;
import com.zebra.wspicking.service.OrderService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.groups.Default;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

/**
 * Spring Boot REST controller for managing orders.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/orders")
@Validated
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private SessionManager sessionManager;

    /**
     * Returns whether the current session user may create orders.
     */
    @GetMapping("/canAdd")
    public ResponseEntity<?> canAdd(HttpSession session) {
        return ResponseEntity.ok(Map.of("canAdd", sessionManager.hasPermission(session, Permission.EDIT_ORDERS)));
    }

    /**
     * Get all orders.
     */
    @GetMapping
    public ResponseEntity<?> getAllOrders(HttpSession session) {
        return ResponseEntity.ok(orderService.getAllOrders(session));
    }

    /**
     * Get order by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getOrderById(@PathVariable Long id, HttpSession session) {
        Optional<OrderDTO> order = orderService.getOrderById(id, session);
        return order.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Get orders by status.
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getOrdersByStatus(@PathVariable OrderStatus status, HttpSession session) {
        return ResponseEntity.ok(orderService.getOrdersByStatus(status, session));
    }

    /**
     * Search orders by customer name.
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchOrders(
            @RequestParam
            @NotBlank(message = "Query parameter must not be empty")
            @Size(max = 100, message = "Query parameter must not exceed 100 characters")
            String query,
            HttpSession session) {
        return ResponseEntity.ok(orderService.searchOrdersByCustomerName(query, session));
    }

    /**
     * Get orders assigned to a specific picker.
     */
    @GetMapping("/picker/{pickerId}")
    public ResponseEntity<?> getOrdersByPickerId(@PathVariable Long pickerId, HttpSession session) {
        return ResponseEntity.ok(orderService.getOrdersByPickerId(pickerId, session));
    }

    /**
     * Get orders targeted to a specific picker.
     */
    @GetMapping("/targeted/{userId}")
    public ResponseEntity<?> getOrdersByTargetedPickerId(@PathVariable Long userId, HttpSession session) {
        return ResponseEntity.ok(orderService.getOrdersByTargetedPickerId(userId, session));
    }

    /**
     * Get high priority orders.
     */
    @GetMapping("/high-priority")
    public ResponseEntity<?> getHighPriorityOrders(HttpSession session) {
        return ResponseEntity.ok(orderService.getHighPriorityOrders(session));
    }

    /**
     * Get order summaries available to a specific picker.
     */
    @GetMapping("/pickable-for-user/{userId}")
    public ResponseEntity<?> getPickableOrdersForUser(@PathVariable @NotNull(message = "PickerId cannot be null") Long userId, HttpSession session) {
        return ResponseEntity.ok(orderService.getOrderSummariesForPickerId(userId, session));
    }

    /**
     * Create a new order.
     */
    @PostMapping
    public ResponseEntity<?> createOrder(@Validated(OrderDTO.Create.class) @RequestBody OrderDTO request, HttpSession session) {
        OrderDTO savedOrder = orderService.createOrder(request, session);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedOrder);
    }

    /**
     * Update an existing order.
     * <p>
     * Uses {@code JsonNullable} semantics for nullable fields:
     * absent = no change, explicit {@code null} = clear, value = update.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateOrder(@PathVariable Long id, @Valid @RequestBody OrderDTO request, HttpSession session) {
        OrderDTO updatedOrder = orderService.updateOrder(id, request, session);
        return ResponseEntity.ok(updatedOrder);
    }

    /**
     * Update order status.
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateOrderStatus(
            @PathVariable Long id,
            @Validated(UpdateOrderRequest.UpdateStatus.class) @RequestBody UpdateOrderRequest statusRequest,
            HttpSession session) {
        OrderDTO updatedOrder = orderService.updateOrderStatus(id, statusRequest.status, session);
        return ResponseEntity.ok(updatedOrder);
    }

    /**
     * Assign a picker to an order.
     */
    @PatchMapping("/{id}/assign-picker")
    public ResponseEntity<?> assignPicker(
            @PathVariable Long id,
            @Validated @RequestBody UpdateOrderRequest pickerRequest,
            HttpSession session) {
        OrderDTO updatedOrder = orderService.assignPickerById(id, pickerRequest.pickerUserId, session);
        return ResponseEntity.ok(updatedOrder);
    }

    /**
     * Update Status and Assign a picker to an order.
     */
    @PatchMapping("/{id}/status-and-picker")
    public ResponseEntity<?> assignOrderAndUpdateStatus(
            @PathVariable Long id,
            @Validated(UpdateOrderRequest.UpdateStatusAndAssignPicker.class) @RequestBody UpdateOrderRequest pickerRequest,
            HttpSession session) {
        OrderDTO updatedOrder = orderService.assignOrderAndUpdateStatus(id, pickerRequest.pickerUserId, pickerRequest.status, session);
        return ResponseEntity.ok(updatedOrder);
    }

    /**
     * Delete an order.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrder(@PathVariable Long id, HttpSession session) {
        if (orderService.deleteOrder(id, session)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @Getter
    @Setter
    public static class UpdateOrderRequest {
        @NotNull(message = "Status must not be null", groups = {UpdateStatus.class, UpdateStatusAndAssignPicker.class})
        private OrderStatus status;
        @NotNull(message = "Picker Id must not be null", groups = {UpdateStatusAndAssignPicker.class})
        private Long pickerUserId;

        /**
         * Interfaces for Grouping Status or Picker for Order Update Validations
         */
        public interface UpdateStatus extends Default {}
        public interface UpdateStatusAndAssignPicker extends Default {}
    }
}
