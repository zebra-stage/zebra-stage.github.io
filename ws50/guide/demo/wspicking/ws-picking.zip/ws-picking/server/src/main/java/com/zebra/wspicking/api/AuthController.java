// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.api;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Role;
import com.zebra.wspicking.data.User;
import com.zebra.wspicking.data.db.UserRepository;
import com.zebra.wspicking.security.PasswordHashUtil;
import com.zebra.wspicking.security.SessionManager;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Spring Boot REST controller for authentication and session management.
 */
@SuppressWarnings("unused")
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private static final boolean DEBUG = false;
    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    private static final long REMOTE_LOGIN_TIMEOUT_SECONDS = 2 * 60; // 2 minutes

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SessionManager sessionManager;

    // SSE emitter: Login console waiting for the QR code to be scanned.
    private final Map<String, SseEmitter> remoteLoginWaitForScanEmitters = new ConcurrentHashMap<>();
    // SSE emitter: Login console watching for device cancellation.
    private final Map<String, SseEmitter> remoteLoginWaitForCredentialsEmitters = new ConcurrentHashMap<>();
    // SSE emitter: Remote device watching for login completion.
    private final Map<String, SseEmitter> remoteLoginStatusEmitters = new ConcurrentHashMap<>();
    // Store client sessions for remote login, so that the console knows what remote session the login is targeting.
    private final Map<String, HttpSession> remoteLoginRemoteDeviceSessions = new ConcurrentHashMap<>();
    // Store scheduled timeout tasks for remote logins
    private final Map<String, ScheduledFuture<?>> remoteLoginTimeoutTasks = new ConcurrentHashMap<>();
    // Executor service for timeout tasks
    private final ScheduledExecutorService timeoutScheduler = Executors.newScheduledThreadPool(2);

    /**
     * Login endpoint. Handles both regular and remote logins.
     *
     * @param loginRequest posted data with username, password, and remote flag
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@Valid @RequestBody LoginRequest loginRequest, HttpSession session) {
        if (DEBUG) logger.info("Login attempt for user: " + loginRequest.getUsername() + ", isRemote: " + loginRequest.getRemote());
        Optional<User> userOptional = userRepository.findByUsername(loginRequest.getUsername());
        if (userOptional.isEmpty()) {
            if (DEBUG) logger.info("Login failed: User not found - " + loginRequest.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Invalid credentials"));
        }

        User user = userOptional.get();

        // Check if user is enabled
        if (!user.getEnabled()) {
            if (DEBUG) logger.info("Login failed: Account disabled - " + loginRequest.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Account is disabled"));
        }

        // Verify password using BCrypt
        if (!PasswordHashUtil.verifyPassword(loginRequest.getPassword(), user.getPasswordHash())) {
            if (DEBUG) logger.info("Login failed: Invalid password - " + loginRequest.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Invalid credentials"));
        }

        // If this is a remote login, get the remote login ID from the current session and look up the corresponding
        // client session.
        if (loginRequest.getRemote() != null && loginRequest.getRemote()) {
            String remoteLoginId = (String) session.getAttribute("remoteLoginId");
            if (DEBUG) logger.info("Remote login ID from session: " + remoteLoginId);

            if (remoteLoginId == null) {
                if (DEBUG) logger.info("Remote login failed: No remoteLoginId in session");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "No remote login session found"));
            }

            HttpSession clientSession = remoteLoginRemoteDeviceSessions.get(remoteLoginId);
            if (clientSession == null) {
                if (DEBUG) logger.info("Remote login failed: Client session not found for ID: " + remoteLoginId);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Remote login session not found or expired"));
            }

            // Store user in the remote client's session.
            sessionManager.loginUser(clientSession, user);
            if (DEBUG) logger.info("User logged in successfully: " + user.getUsername() + ", role: " + user.getRole().name());

            // Notify the remote device via SSE that login is complete
            SseEmitter statusEmitter = remoteLoginStatusEmitters.get(remoteLoginId);
            if (statusEmitter != null) {
                try {
                    JSONObject doneData = new JSONObject();
                    doneData.put("status", "done");
                    doneData.put("id", user.getId());
                    doneData.put("username", user.getUsername());
                    doneData.put("fullName", user.getFullName());
                    doneData.put("pickableSummariesUrl", "/api/orders/pickable-for-user/" + user.getId());
                    doneData.put("productLookupUpcUrl", "/api/products/upc/");
                    statusEmitter.send(SseEmitter.event()
                        .name("done")
                        .data(doneData.toString()));
                    statusEmitter.complete();
                    if (DEBUG) logger.info("Remote device notified of login completion for ID: {}", remoteLoginId);
                } catch (IOException e) {
                    if (DEBUG) logger.info("Failed to notify remote device of login completion: {}", e.getMessage());
                }
                remoteLoginStatusEmitters.remove(remoteLoginId);
            }

            // Clean up the remote login session
            remoteLoginRemoteDeviceSessions.remove(remoteLoginId);
            session.removeAttribute("remoteLoginId");

            // Cancel the timeout task since login completed successfully
            ScheduledFuture<?> timeoutTask = remoteLoginTimeoutTasks.remove(remoteLoginId);
            if (timeoutTask != null && !timeoutTask.isDone()) {
                timeoutTask.cancel(false);
            }

        } else {
            // Store user in the target session (regular login on the console).
            sessionManager.loginUser(session, user);
            if (DEBUG) logger.info("User logged in successfully: " + user.getUsername() + ", role: " + user.getRole().name());
        }

        // Return user info.
        Map<String, Object> response = new HashMap<>();
        response.put("id", user.getId());
        response.put("username", user.getUsername());
        response.put("fullName", user.getFullName());
        response.put("pickableSummariesUrl", "/api/orders/pickable-for-user/" + user.getId());
        response.put("productLookupUpcUrl", "/api/products/upc/");

        return ResponseEntity.ok(response);
    }

    /**
     * Logout endpoint.
     */
    @PostMapping("/logout")
    public ResponseEntity<Map<String, String>> logout(HttpSession session) {
        if (DEBUG) logger.info("Logout request received for session: {}", session.getId());
        sessionManager.logoutUser(session);
        if (DEBUG) logger.info("User logged out successfully");
        return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
    }

    /**
     * Session check endpoint. Provides information about the current session and authenticated user.
     */
    @GetMapping("/session")
    public ResponseEntity<Map<String, Object>> getSession(HttpSession session) {
        if (DEBUG) logger.info("Session check request received");
        User user = sessionManager.getCurrentUser(session);

        if (user == null) {
            if (DEBUG) logger.info("Session check: User not authenticated");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("authenticated", false));
        }

        if (DEBUG) logger.info("Session check: User authenticated - {}", user.getUsername());
        Role role = user.getRole();
        Map<String, Object> response = new HashMap<>();
        response.put("authenticated", true);
        response.put("username", user.getUsername());
        response.put("fullName", user.getFullName());
        response.put("canViewOrders", role.hasPermission(Permission.VIEW_ORDERS));
        response.put("canViewProducts", role.hasPermission(Permission.VIEW_PRODUCTS));
        response.put("canViewUsers", role.hasPermission(Permission.VIEW_USERS));

        return ResponseEntity.ok(response);
    }

    /**
     * Helper method to handle remote login timeout. Cancels the login attempt and notifies both console and remote
     * device.
     */
    private void handleRemoteLoginTimeout(String loginId) {
        if (DEBUG) logger.info("Remote login timeout triggered for loginId: " + loginId);

        // Remove the timeout task from the map
        remoteLoginTimeoutTasks.remove(loginId);

        // Notify console watchers that the session timed out
        SseEmitter consoleWatcher = remoteLoginWaitForCredentialsEmitters.get(loginId);
        if (consoleWatcher != null) {
            try {
                consoleWatcher.send(SseEmitter.event()
                    .name("cancelled")
                    .data("Remote login credential collection timed out"));
                consoleWatcher.complete();
                if (DEBUG) logger.info("Console watcher notified of timeout for loginId: " + loginId);
            } catch (IOException e) {
                if (DEBUG) logger.info("Failed to notify console watcher of timeout for loginId: " + loginId);
                // Ignore
            }
            remoteLoginWaitForCredentialsEmitters.remove(loginId);
        }

        // Notify remote device status watchers that the session timed out
        SseEmitter statusEmitter = remoteLoginStatusEmitters.get(loginId);
        if (statusEmitter != null) {
            try {
                statusEmitter.send(SseEmitter.event()
                    .name("cancelled")
                    .data("{\"status\":\"cancelled\",\"reason\":\"timeout\"}"));
                statusEmitter.complete();
                if (DEBUG) logger.info("Remote device status watcher notified of timeout for loginId: " + loginId);
            } catch (IOException e) {
                if (DEBUG) logger.info("Failed to notify remote device status watcher of timeout for loginId: " + loginId);
                // Ignore
            }
            remoteLoginStatusEmitters.remove(loginId);
        }

        // Clean up the client session
        HttpSession clientSession = remoteLoginRemoteDeviceSessions.remove(loginId);
        if (clientSession != null) {
            try {
                clientSession.removeAttribute("remoteLoginId");
                if (DEBUG) logger.info("Cleaned up timed out client session for loginId: " + loginId);
            } catch (Exception e) {
                if (DEBUG) logger.info("Error cleaning up client session for loginId: " + loginId);
                // Session might already be invalidated
            }
        }

        if (DEBUG) logger.info("Remote login timeout handling completed for loginId: " + loginId);
    }

    /**
     * SSE endpoint for remote login status notifications, used by the console while displaying the QR code. Connection
     * is kept open until device scans QR code or timeout/error occurs.
     */
    @GetMapping(value = "/remote-login-scan-status", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter waitForRemoteLoginScan(HttpSession session) {
        if (DEBUG) logger.info("Remote login scan status endpoint called");
        String loginId = (String) session.getAttribute("remoteLoginId");

        if (loginId == null) {
            if (DEBUG) logger.info("Remote login scan failed: No remoteLoginId in session");
            SseEmitter emitter = new SseEmitter();
            try {
                emitter.send(SseEmitter.event()
                    .name("error")
                    .data("No remote login session found"));
                emitter.complete();
            } catch (IOException e) {
                emitter.completeWithError(e);
            }
            return emitter;
        }

        // Create SSE emitter with 4 hour timeout (allows for long delays)
        SseEmitter emitter = new SseEmitter(4 * 60 * 60 * 1000L);

        // Store emitter for this session
        remoteLoginWaitForScanEmitters.put(loginId, emitter);

        // Clean up on completion or timeout
        emitter.onCompletion(() -> {
            if (DEBUG) logger.info("SSE emitter completed for remote login ID: " + loginId);
            remoteLoginWaitForScanEmitters.remove(loginId);
        });
        emitter.onTimeout(() -> {
            remoteLoginWaitForScanEmitters.remove(loginId);
            try {
                emitter.send(SseEmitter.event()
                    .name("timeout")
                    .data("Remote login session timed out"));
                emitter.complete();
            } catch (IOException e) {
                // Ignore if already closed
            }
        });
        emitter.onError((e) -> {
            if (DEBUG) logger.info("SSE emitter error for remote login ID: " + loginId + ", error: " + e.getMessage());
            remoteLoginWaitForScanEmitters.remove(loginId);
        });

        // Send initial connection confirmation
        try {
            emitter.send(SseEmitter.event()
                .name("connected")
                .data("Waiting for device to scan QR code"));
        } catch (IOException e) {
            if (DEBUG) logger.info("Failed to send initial SSE message for remote login ID: {}", loginId);
            emitter.completeWithError(e);
        }

        return emitter;
    }

    /**
     * SSE endpoint for console to watch for device-side cancellation while waiting for credentials to by entered.
     * Connection is kept open and notifies if remote device cancels the login.
     */
    @GetMapping(value = "/watch-remote-login-cancellation", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter watchRemoteLoginCancellation(HttpSession session) {
        if (DEBUG) logger.info("Watch remote login cancellation endpoint called");
        String loginId = (String) session.getAttribute("remoteLoginId");

        if (loginId == null) {
            if (DEBUG) logger.info("Watch cancellation failed: No remoteLoginId in session");
            SseEmitter emitter = new SseEmitter();
            try {
                emitter.send(SseEmitter.event()
                    .name("error")
                    .data("No remote login session found"));
                emitter.complete();
            } catch (IOException e) {
                emitter.completeWithError(e);
            }
            return emitter;
        }

        // Create SSE emitter with 4 hour timeout
        SseEmitter emitter = new SseEmitter(4 * 60 * 60 * 1000L);

        // Store emitter for this login session
        remoteLoginWaitForCredentialsEmitters.put(loginId, emitter);

        // Clean up on completion or timeout
        emitter.onCompletion(() -> {
            if (DEBUG) logger.info("Console watcher SSE emitter completed for remote login ID: " + loginId);
            remoteLoginWaitForCredentialsEmitters.remove(loginId);
        });
        emitter.onTimeout(() -> {
            if (DEBUG) logger.info("Console watcher SSE emitter timed out for remote login ID: " + loginId);
            remoteLoginWaitForCredentialsEmitters.remove(loginId);
            try {
                emitter.send(SseEmitter.event()
                    .name("timeout")
                    .data("Watch session timed out"));
                emitter.complete();
            } catch (IOException e) {
                // Ignore if already closed
            }
        });
        emitter.onError((e) -> {
            if (DEBUG) logger.info("Console watcher SSE emitter error for remote login ID: " + loginId + ", error: " + e.getMessage());
            remoteLoginWaitForCredentialsEmitters.remove(loginId);
        });

        // Send initial connection confirmation
        try {
            emitter.send(SseEmitter.event()
                .name("connected")
                .data("Watching for device cancellation"));
        } catch (IOException e) {
            if (DEBUG) logger.info("Failed to send initial console watcher SSE message for remote login ID: " + loginId);
            emitter.completeWithError(e);
        }

        return emitter;
    }

    /**
     * Endpoint called when device scans the QR code, to start the remote login. Notifies the waiting console to proceed
     * to the login page.
     *
     * @param loginId the remote login session ID which was encoded in the QR code
     */
    @GetMapping("/start-remote-login")
    public ResponseEntity<String> startRemoteLogin(HttpSession session, @RequestParam String loginId) {
        if (DEBUG) logger.info("Start remote login request received for loginId: {}", loginId);
        SseEmitter emitter = remoteLoginWaitForScanEmitters.get(loginId);

        if (emitter == null) {
            // No emitter found - the console is not waiting for this login ID. Maybe the given login ID was from a
            // stale/expired QR code, or some other remote device scanned it first.
            if (DEBUG) logger.info("Start remote login failed: SSE emitter not found for loginId: {}", loginId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Remote login session not found");
        }

        try {
            // Notify the waiting browser to proceed to the login page.
            emitter.send(SseEmitter.event()
                .name("proceed")
                .data("Device ready for login"));
            emitter.complete();
            if (DEBUG) logger.info("SSE proceed event sent for loginId: {}", loginId);
        } catch (IOException e) {
            if (DEBUG) logger.info("Failed to send SSE proceed event for loginId: {}, error: {}", loginId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Failed to notify remote login session");
        }

        remoteLoginWaitForScanEmitters.remove(loginId);

        session.setAttribute("remoteLoginId", loginId);
        remoteLoginRemoteDeviceSessions.put(loginId, session);

        // Schedule timeout task to cancel the remote login after REMOTE_LOGIN_TIMEOUT_SECONDS
        ScheduledFuture<?> timeoutTask = timeoutScheduler.schedule(
            () -> handleRemoteLoginTimeout(loginId),
            REMOTE_LOGIN_TIMEOUT_SECONDS,
            TimeUnit.SECONDS
        );
        remoteLoginTimeoutTasks.put(loginId, timeoutTask);

        return ResponseEntity.ok("""
            {
                "remoteLoginStatusUrl" : "/api/auth/remote-login-status",
                "remoteLoginCancelUrl" : "/api/auth/cancel-remote-login-by-remote-device"
            }
            """);
    }

    /**
     * SSE endpoint for remote device to watch for login completion status. The connection is kept open until login
     * completes or is cancelled.
     */
    @GetMapping(value = "/remote-login-status", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter remoteLoginStatus(HttpSession session) {
        if (DEBUG) logger.info("Remote login status SSE endpoint called");
        String loginId = (String) session.getAttribute("remoteLoginId");
        if (loginId == null) {
            if (DEBUG) logger.info("Remote login status failed: No remoteLoginId in session");
            SseEmitter emitter = new SseEmitter();
            try {
                emitter.send(SseEmitter.event()
                    .name("error")
                    .data("{\"status\":\"error\",\"message\":\"No remote login session found\"}"));
                emitter.complete();
            } catch (IOException e) {
                emitter.completeWithError(e);
            }
            return emitter;
        }

        // Check if user is already logged in (might have happened very quickly).
        User user = sessionManager.getCurrentUser(session);
        if (user != null) {
            if (DEBUG) logger.info("User already logged in, sending immediate done event for loginId: " + loginId);
            SseEmitter emitter = new SseEmitter();
            try {
                JSONObject doneData = new JSONObject();
                doneData.put("status", "done");
                doneData.put("id", user.getId());
                doneData.put("username", user.getUsername());
                doneData.put("fullName", user.getFullName());
                doneData.put("pickableSummariesUrl", "/api/orders/pickable-for-user/" + user.getId());
                doneData.put("productLookupUpcUrl", "/api/products/upc/");
                emitter.send(SseEmitter.event()
                    .name("done")
                    .data(doneData.toString()));
                emitter.complete();
            } catch (IOException e) {
                emitter.completeWithError(e);
            }
            return emitter;
        }

        // Create SSE emitter with 4 hour timeout
        SseEmitter emitter = new SseEmitter(4 * 60 * 60 * 1000L);

        // Store emitter for this login session
        remoteLoginStatusEmitters.put(loginId, emitter);

        // Clean up on completion or timeout
        emitter.onCompletion(() -> {
            if (DEBUG) logger.info("Remote device status SSE emitter completed for remote login ID: " + loginId);
            remoteLoginStatusEmitters.remove(loginId);
        });
        emitter.onTimeout(() -> {
            if (DEBUG) logger.info("Remote device status SSE emitter timed out for remote login ID: " + loginId);
            remoteLoginStatusEmitters.remove(loginId);
            try {
                emitter.send(SseEmitter.event()
                    .name("timeout")
                    .data("{\"status\":\"timeout\",\"message\":\"Status watch session timed out\"}"));
                emitter.complete();
            } catch (IOException e) {
                // Ignore if already closed
            }
        });
        emitter.onError((e) -> {
            if (DEBUG) logger.info("Remote device status SSE emitter error for remote login ID: " + loginId + ", error: " + e.getMessage());
            remoteLoginStatusEmitters.remove(loginId);
        });

        // Send initial connection confirmation
        try {
            emitter.send(SseEmitter.event()
                .name("connected")
                .data("{\"status\":\"in progress\",\"message\":\"Waiting for login completion\"}"));
        } catch (IOException e) {
            if (DEBUG) logger.info("Failed to send initial remote device status SSE message for remote login ID: " + loginId);
            emitter.completeWithError(e);
        }

        return emitter;
    }

    /**
     * Endpoint to cancel/abort remote login from the console (web UI).
     */
    @PostMapping("/cancel-remote-login")
    public ResponseEntity<Map<String, String>> cancelRemoteLogin(HttpSession session) {
        if (DEBUG) logger.info("Cancel remote login request received");
        String loginId = (String) session.getAttribute("remoteLoginId");

        if (loginId != null) {
            SseEmitter emitter = remoteLoginWaitForScanEmitters.get(loginId);
            if (emitter != null) {
                try {
                    emitter.send(SseEmitter.event()
                        .name("cancelled")
                        .data("Remote login cancelled"));
                    emitter.complete();
                    if (DEBUG) logger.info("SSE cancellation event sent for loginId: " + loginId);
                } catch (IOException ignored) {
                    if (DEBUG) logger.info("Failed to send SSE cancellation event for loginId: " + loginId);
                }
                remoteLoginWaitForScanEmitters.remove(loginId);
            }

            // Also clean up console watchers
            SseEmitter consoleWatcher = remoteLoginWaitForCredentialsEmitters.get(loginId);
            if (consoleWatcher != null) {
                try {
                    consoleWatcher.complete();
                    if (DEBUG) logger.info("Console watcher completed for loginId: " + loginId);
                } catch (Exception ignored) {
                    if (DEBUG) logger.info("Failed to complete console watcher for loginId: " + loginId);
                }
                remoteLoginWaitForCredentialsEmitters.remove(loginId);
            }

            // Notify remote device status watchers
            SseEmitter statusEmitter = remoteLoginStatusEmitters.get(loginId);
            if (statusEmitter != null) {
                try {
                    statusEmitter.send(SseEmitter.event()
                        .name("cancelled")
                        .data("{\"status\":\"cancelled\",\"reason\":\"console cancelled\"}"));
                    statusEmitter.complete();
                    if (DEBUG) logger.info("Remote device status watcher notified of cancellation for loginId: " + loginId);
                } catch (IOException e) {
                    if (DEBUG) logger.info("Failed to notify remote device status watcher for loginId: " + loginId);
                    // Ignore
                }
                remoteLoginStatusEmitters.remove(loginId);
            }

            // Cancel any pending timeout task
            ScheduledFuture<?> timeoutTask = remoteLoginTimeoutTasks.remove(loginId);
            if (timeoutTask != null && !timeoutTask.isDone()) {
                timeoutTask.cancel(false);
                if (DEBUG) logger.info("Cancelled timeout task for loginId: " + loginId);
            }

            session.removeAttribute("remoteLoginId");
        } else {
            if (DEBUG) logger.info("No active remote login session to cancel");
        }

        return ResponseEntity.ok(Map.of("message", "Remote login cancelled"));
    }

    /**
     * Endpoint to cancel/abort remote login from the remote device side.
     */
    @PostMapping("/cancel-remote-login-by-remote-device")
    public ResponseEntity<Map<String, String>> cancelRemoteLoginByRemoteDevice(HttpSession session) {
        if (DEBUG) logger.info("Cancel remote login by remote device request received");
        String loginId = (String) session.getAttribute("remoteLoginId");

        if (loginId != null) {
            // Notify any console watchers that the device cancelled
            SseEmitter consoleWatcher = remoteLoginWaitForCredentialsEmitters.get(loginId);
            if (consoleWatcher != null) {
                try {
                    consoleWatcher.send(SseEmitter.event()
                        .name("cancelled")
                        .data("Remote device cancelled the login"));
                    consoleWatcher.complete();
                    if (DEBUG) logger.info("Console watcher notified of device cancellation for loginId: " + loginId);
                } catch (IOException e) {
                    if (DEBUG) logger.info("Failed to notify console watcher for loginId: " + loginId);
                    // Ignore
                }
                remoteLoginWaitForCredentialsEmitters.remove(loginId);
            }

            // Notify status emitter that device cancelled
            SseEmitter statusEmitter = remoteLoginStatusEmitters.get(loginId);
            if (statusEmitter != null) {
                try {
                    statusEmitter.send(SseEmitter.event()
                        .name("cancelled")
                        .data("{\"status\":\"cancelled\",\"reason\":\"device cancelled\"}"));
                    statusEmitter.complete();
                    if (DEBUG) logger.info("Remote device status watcher notified of device cancellation for loginId: " + loginId);
                } catch (IOException e) {
                    if (DEBUG) logger.info("Failed to notify remote device status watcher for loginId: " + loginId);
                    // Ignore
                }
                remoteLoginStatusEmitters.remove(loginId);
            }

            // Cancel any pending timeout task
            ScheduledFuture<?> timeoutTask = remoteLoginTimeoutTasks.remove(loginId);
            if (timeoutTask != null && !timeoutTask.isDone()) {
                timeoutTask.cancel(false);
                if (DEBUG) logger.info("Cancelled timeout task for loginId: " + loginId);
            }

            remoteLoginRemoteDeviceSessions.remove(loginId);
            session.removeAttribute("remoteLoginId");
        } else {
            if (DEBUG) logger.info("No active remote login session to cancel from device");
        }

        sessionManager.logoutUser(session);
        return ResponseEntity.ok(Map.of("message", "Remote device remote login cancelled"));
    }

    /**
     * Endpoint to cancel/abort remote login when console navigates away from login page.
     */
    @PostMapping("/cancel-remote-login-by-console-navigation")
    public ResponseEntity<Map<String, String>> cancelRemoteLoginByConsoleNavigation(HttpSession session) {
        String loginId = (String) session.getAttribute("remoteLoginId");
        if (loginId != null) {
            // Cancel any pending timeout task
            ScheduledFuture<?> timeoutTask = remoteLoginTimeoutTasks.remove(loginId);
            if (timeoutTask != null && !timeoutTask.isDone()) {
                timeoutTask.cancel(false);
            }

            // Clean up remote device session
            remoteLoginRemoteDeviceSessions.remove(loginId);

            // Clean up console watcher
            SseEmitter consoleWatcher = remoteLoginWaitForCredentialsEmitters.remove(loginId);
            if (consoleWatcher != null) {
                try {
                    consoleWatcher.complete();
                } catch (Exception ignored) {}
            }

            // Clean up status emitter
            SseEmitter statusEmitter = remoteLoginStatusEmitters.remove(loginId);
            if (statusEmitter != null) {
                try {
                    statusEmitter.send(SseEmitter.event()
                        .name("cancelled")
                        .data("{\"status\":\"cancelled\",\"reason\":\"console navigated away\"}"));
                    statusEmitter.complete();
                } catch (Exception ignored) {}
            }

            session.removeAttribute("remoteLoginId");
        }

        return ResponseEntity.ok(Map.of("message", "Remote login cancelled by console navigation"));
    }


    /**
     * Data class for login request payload.
     */
    @Getter
    @Setter
    public static class LoginRequest {
        private String username;
        private String password;
        private Boolean remote;
    }
}

