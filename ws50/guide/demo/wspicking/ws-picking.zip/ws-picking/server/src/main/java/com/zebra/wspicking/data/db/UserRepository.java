// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.db;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.Role;
import com.zebra.wspicking.data.User;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for User entity.
 */
@SuppressWarnings("unused")
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Find user by username (for login)
    Optional<User> findByUsername(String username);

    // Find users by full name containing a string (case-insensitive)
    List<User> findByFullNameContainingIgnoreCase(String fullName);

    // Find users by role
    List<User> findByRole(Role role);

    // Find enabled users
    List<User> findByEnabled(Boolean enabled);

    // Find enabled users by role
    List<User> findByRoleAndEnabled(Role role, Boolean enabled);

    /**
     * Find active users with specified roles. This is a custom query for use by findActiveUsersWithPermission.
     *
     * @param roles array of role IDs
     * @return list of active users that match one of the specified roles
     */
    @Query("SELECT u FROM User u WHERE u.role in (:roles) AND u.enabled = true")
    List<User> findActiveUsersOfRoles(@Param("roles") Role[] roles);

    /**
     * Find active users with a specific permission.
     *
     * @param permission the permission to check
     * @return list of active users with the specified permission
     */
    default List<User> findActiveUsersWithPermission(Permission permission) {
        return findActiveUsersOfRoles(Role.rolesWithPermission(permission));
    }

    // Check if a username already exists
    boolean existsByUsername(String username);

    /**
     * Count users by role with pessimistic write lock.
     * This prevents race conditions when checking admin count before role changes.
     * The lock is held until the transaction commits.
     *
     * @param role the role to count
     * @return the count of users with the specified role
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT COUNT(u) FROM User u WHERE u.role = :role")
    long countByRoleWithLock(@Param("role") Role role);
}
