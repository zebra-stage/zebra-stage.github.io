// Copyright (c) 2025-2026 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.security;

import com.zebra.wspicking.data.Permission;
import com.zebra.wspicking.data.User;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

/**
 * Manages user sessions and authentication checks.
 */
@SuppressWarnings("unused")
@Component
public class SessionManager {

    private static final String USER_SESSION_KEY = "AUTHENTICATED_USER";

    /** Static reference set at startup so non-Spring objects (e.g. DTOs) can call {@link #checkPermission}. */
    private static SessionManager INSTANCE;

    @PostConstruct
    private void initStatic() {
        INSTANCE = this;
    }

    /**
     * Static convenience for non-Spring-managed objects such as DTOs to check if the current user has a specific
     * permission.
     */
    public static boolean checkPermission(HttpSession session, Permission permission) {
        return INSTANCE != null && INSTANCE.hasPermission(session, permission);
    }

    /**
     * Store authenticated user in session.
     */
    public void loginUser(HttpSession session, User user) {
        session.setAttribute(USER_SESSION_KEY, user);
    }

    /**
     * Remove user from session.
     */
    public void logoutUser(HttpSession session) {
        session.removeAttribute(USER_SESSION_KEY);
        session.invalidate();
    }

    /**
     * Get currently authenticated user from session, or null if not authenticated.
     */
    public User getCurrentUser(HttpSession session) {
        if (session == null) return null;
        return (User) session.getAttribute(USER_SESSION_KEY);
    }

    /**
     * Check if user is authenticated.
     */
    public boolean isAuthenticated(HttpSession session) {
        if (session == null) return false;
        return getCurrentUser(session) != null;
    }

    /**
     * Check if current user has a specific permission (permission name version).
     */
    public boolean hasPermission(HttpSession session, String permissionName) {
        try {
            return hasPermission(session, Permission.valueOf(permissionName));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * Check if the current user has a specific permission (enum version).
     */
    public boolean hasPermission(HttpSession session, Permission permission) {
        User user = getCurrentUser(session);
        if (user == null) return false;
        return user.getRole().hasPermission(permission);
    }

    /**
     * Require that the current user has a specific permission.
     * Throws ResponseStatusException with 403 Forbidden if permission is denied.
     */
    public void requirePermission(HttpSession session, Permission permission) {
        if (!hasPermission(session, permission)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "Permission denied.");
    }

}
