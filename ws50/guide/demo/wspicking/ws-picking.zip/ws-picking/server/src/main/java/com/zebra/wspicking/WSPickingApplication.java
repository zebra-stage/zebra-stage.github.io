// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

/**
 * Main Spring Boot application class for the WS Picking application.
 */
@SuppressWarnings("unused")
@SpringBootApplication
public class WSPickingApplication {

	/**
	 * Main method to start the Spring Boot application.
	 *
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		args = processArguments(args);
		SpringApplication.run(WSPickingApplication.class, args);
	}

	/**
	 * Processes the custom --db argument to allow simple database filename specification.
	 * Converts --db=mydata.db to --spring.datasource.url=jdbc:sqlite:mydata.db
	 *
	 * @param args Original command line arguments
	 * @return Modified arguments with --db converted to full datasource URL
	 */
	private static String[] processArguments(String[] args) {
		List<String> modifiedArgs = new ArrayList<>();
		for (String arg : args) {
			if (arg.startsWith("--db=")) {
				// Extract the database filename.
				String dbFilename = arg.substring(5);           // remove "--db="
				if (dbFilename.indexOf('.') == -1) dbFilename += ".db";   // add default extension if missing
				System.out.println("Using database file: " + dbFilename);
				// Convert to full JDBC URL.
				modifiedArgs.add("--spring.datasource.url=jdbc:sqlite:" + dbFilename);
			} else {
				modifiedArgs.add(arg);
			}
		}
		return modifiedArgs.toArray(new String[0]);
	}

}
