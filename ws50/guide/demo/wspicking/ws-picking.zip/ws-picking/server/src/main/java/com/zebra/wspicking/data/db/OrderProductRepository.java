// Copyright (c) 2025 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
package com.zebra.wspicking.data.db;

import com.zebra.wspicking.data.Order;
import com.zebra.wspicking.data.OrderProduct;
import com.zebra.wspicking.data.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for OrderProduct entity.
 */
@SuppressWarnings("unused")
@Repository
public interface OrderProductRepository extends JpaRepository<OrderProduct, Long> {

    // Find all order products for a specific order
    List<OrderProduct> findByOrder(Order order);

    // Find all order products for a specific order ID
    List<OrderProduct> findByOrderId(Long orderId);

    // Find all order products containing a specific product
    List<OrderProduct> findByProduct(Product product);

    // Find all order products containing a specific product ID
    List<OrderProduct> findByProductId(Long productId);

    // Delete all order products for a specific order
    void deleteByOrder(Order order);

    // Delete all order products for a specific order ID
    void deleteByOrderId(Long orderId);

    // Returns true if the product with supplied ID is associated with any Order Product
    boolean existsByProductId(Long productId);
}
