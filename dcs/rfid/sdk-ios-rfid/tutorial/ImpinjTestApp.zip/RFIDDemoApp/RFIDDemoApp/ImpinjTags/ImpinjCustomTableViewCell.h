//
//  ImpinjCustomTableViewCell.h
//  RFIDDemoApp
//
//  Created by Rajapaksha, Chamika on 2025-08-04.
//  Copyright © 2025 Zebra Technologies Corp. and/or its affiliates. All rights reserved. All rights reserved.
//

#ifndef ImpinjCustomTableViewCell_h
#define ImpinjCustomTableViewCell_h


#endif /* ImpinjCustomTableViewCell_h */

#import <UIKit/UIKit.h>
@interface ImpinjCustomTableViewCell : UITableViewCell
{

    IBOutlet UILabel *lblImpinjTagID;
    IBOutlet UILabel *lblImpinjTagReadCount;
    IBOutlet UILabel *lblImpinjReadCount;
    IBOutlet UILabel *lblImpinjReadRate;

}

//@property (nonatomic, assign) BOOL isChecked;  // A boolean to track the selected state
//





@end
