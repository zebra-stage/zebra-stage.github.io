//
//  ImpinjCustomTableViewCell.m
//  RFIDDemoApp
//
//  Created by Rajapaksha, Chamika on 2025-08-04.
//  Copyright © 2025 Zebra Technologies Corp. and/or its affiliates. All rights reserved. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ImpinjCustomTableViewCell.h"




@implementation ImpinjCustomTableViewCell



- (void)dealloc {

    [super dealloc];
}

//- (void)toggleCheckmark {
//    self.isChecked = !self.isChecked;
//    if (self.isChecked) {
//        // Change the image color to indicate selection, e.g., to green
//        self->tagSelectImg.tintColor = [UIColor greenColor];
//    } else {
//        // Change the image color back to default, e.g., to gray
//        self->tagSelectImg.tintColor = [UIColor grayColor];
//    }
//}
@end


