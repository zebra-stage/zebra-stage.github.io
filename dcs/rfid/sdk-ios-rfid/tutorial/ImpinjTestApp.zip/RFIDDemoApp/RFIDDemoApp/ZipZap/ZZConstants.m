//
//  ZZConstants.m
//  ZipZap
//
//  Created by Glen Low on 2/09/14.
//  Copyright (c) 2014, Pixelglow Software. All rights reserved.
//

#import "ZZConstants.h"

NSString* const ZZOpenOptionsCreateIfMissingKey = @"ZZOpenOptionsCreateIfMissingKey";
