//
//  EndPointSettingsViewController.h
//  RFIDDemoApp
//
//  Created by Madesan Venkatraman on 30/04/25.
//  Copyright © 2025 Zebra Technologies Corp. and/or its affiliates. All rights reserved. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EndPointSettingsViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
