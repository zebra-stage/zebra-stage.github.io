//
//  WIFIStatusViewController.h
//  RFIDDemoApp
//
//  Created by Madesan Venkatraman on 31/05/24.
//  Copyright © 2024 Zebra Technologies Corp. and/or its affiliates. All rights reserved. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WIFIStatusViewController : UIViewController
{
    
}
//@property (retain, nonatomic) IBOutlet UISwitch *switchEnableWifi;
@property (retain, nonatomic) IBOutlet UITableView * wifidetails_table;
@end

NS_ASSUME_NONNULL_END
