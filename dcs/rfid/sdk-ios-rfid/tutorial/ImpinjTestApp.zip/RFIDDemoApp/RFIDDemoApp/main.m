//
//  main.m
//  RFIDDemoApp
//
//  Created by Alexei Igumnov on 08/09/14.
//  Copyright (c) 2014 Zebra Technologies Corp. and/or its affiliates. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RFIDDemoAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([zt_RfidDemoAppDelegate class]));
    }
}
