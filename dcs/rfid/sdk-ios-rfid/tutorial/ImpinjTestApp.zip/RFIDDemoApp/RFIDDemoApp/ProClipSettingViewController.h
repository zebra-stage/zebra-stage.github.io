//
//  ProClipSettingViewController.h
//  RFIDDemoApp
//
//  Created by Dhanushka Adrian on 2022-10-20.
//  Copyright © 2022 Zebra Technologies Corp. and/or its affiliates. All rights reserved. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProClipSettingViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIButton *btnCheckBox;

@property (retain, nonatomic) IBOutlet UILabel *lbStatus;
@end

NS_ASSUME_NONNULL_END
