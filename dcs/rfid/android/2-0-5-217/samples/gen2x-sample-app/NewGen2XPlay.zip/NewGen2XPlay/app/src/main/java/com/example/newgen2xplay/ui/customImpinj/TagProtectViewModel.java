package com.example.newgen2xplay.ui.customImpinj;

import androidx.lifecycle.ViewModel;

public class TagProtectViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}