---
title: Using Zebra DNA Cloud
layout: guide.html
product: PRE-RELEASE DOCUMENTATION
menu:
  items:
    - title: About
      url: /zebradna/1-0/about
    - title: Setup
      url: /zebradna/1-0/setup
    - title: Usage
      url: /zebradna/1-0/usage
    - title: Licensing
      url: /zebradna/1-0/licensing
    - title: Known Issues
      url: /zebradna/1-0/faq
    - icon: fa fa-search
      url: /zebradna/1-0/search
---

> <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> Actions in this section can be performed only after zDNA Cloud has been set up by an organization. If necessary, please **follow instructions in the [zDNA Cloud Setup Guide](../setup/#iconfigurenetwork) before returning to this section**.

## Overview

**After one or more devices are enrolled and licensed in the zDNA Cloud system**, administrators can begin creating and deploying device settings and performing other administrative tasks. These tasks are performed by administrators as defined below: 

* **Tenant Owner**: 
 * **Created with each new <u>instance</u>** of Zebra DNA Cloud
 * **No more than one is allowed** per organization
 * Requires [registration at Zebra.com](../setup/#iiregisterwithzebracom)
 * Uses Zebra SSO credentials
 * **Able to create Administrative Users** and perform all other admin duties
* **Administrative Users**: 
 * Created and **maintained by Tenant Owner**
 * Can perform all routine administrative duties
 * Can access all features ***except*** user administration
 * **Does <u>NOT</u> use Zebra SSO credentials**

### Admin Requirements

* At least one set of **Adminstrator credentials**: 
 * **zDNA Cloud Tenant Owner (SSO) credentials** (obtained during [zDNA Cloud Setup](../setup))<br> 
**~OR~**<br> 
 * **Admin User (non-SSO) credentials** (created by Tenant Owner) 
* **One or more Zebra devices running Android 11** (or later) updated as follows:
 * **SDM660-platform**: `11-23-13.00-RG-U00-STD-HEL-04` (May 2022 LG build or later) 
 * **QC6490-platform**: `11-10-17.00-RG-U00-STD-ATH-04` (or later)
 * **WS50 wearable**: `11-17-03.00-RN-U00-STD-WTX-04` (or later)
* **Devices must be enrolled and licensed** for access to all system features ([see Setup -> Enrollment](../setup/#iiienrolldevices)) 

-----

## Manage Devices

Devices can be managed in the zDNA Cloud system only **after they have been enrolled and licensed in the system**. To enroll devices in zDNA Cloud for the first time, [see Enroll Devices](../setup/#iiienrolldevices) in the Setup Section. 

-----

### Device Actions

#### On Individual Devices
**From the My Devices screen, the following actions can be executed remotely** on enrolled device(s): 
<img alt="image" style="height:350px" src="Device actions.png"/>
_Click image to enlarge; ESC to exit._
<br>

> <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> The actions listed below are **executed only on devices that are powered up and online** when the action is issued.<br>**To create durable actions** that execute the next time the device is available, **see [Manage Devices and Groups](#managesettingsandgroups)** section.  

* **Reset Device Passcode &#42; -** removes any existing swipe pattern, PIN or password 
* **Reboot Device -** causes all apps to quit and restarts the device 
* **Wipe Device -** resets the device to its factory-fresh state, **permanently erasing all user apps and data**
* **Delete Device ✝︎ -** removes zDNA client app from device, de-enrolls device from zDNA Cloud system; other apps and settings on device remain unchanged
* **Update zDNA Client -** checks the client app on the device and pushes an update, if necessary 
* **Reapply -** Reapplies a settings Profile, usually after addressing "Issues" or a change of device availability 

<i><font size="1" color="grey">&#42; This feature has no effect on the device if the user changed the passcode before zDNA Cloud enrollment. An Enterprise Reset and re-enrollment of the device is required to regain control.<br>✝︎ Deleted devices could remain visible in deployment detail documents if the device was selected for deployment before being deleted.</font></i>

#### On Multiple Devices
**Selecting one or more devices activates the "Bulk Actions" button**: 
<img alt="image" style="height:350px" src="manage_devices_02.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----

**Click on a Device name** to display its details.<br>
<i class="fa fa-check-circle" style="color:#27AE60;"></i> **The device name and its Group association** can be edited here and Groups can be created: 
<img alt="image" style="height:350px" src="manage_devices_03.png"/>
_Click image to enlarge; ESC to exit._
<br>

> <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> **Note: Adding a device to a Group automatically deploys settings associated with that Group to the device**.  

**The Device Settings tab** lists the settings Profile history for the device: 
<img alt="image" style="height:350px" src="device_details_settings.png"/>
_Click image to enlarge; ESC to exit._
<br>

**The Zebra Services tab** lists the zDNA-relevant services running on the device:  
<img alt="image" style="height:350px" src="device_details_services.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----

## Manage Settings and Groups

To perform actions on a group of devices all at once, it can be helpful to create one or more device Groups and associate one or more settings with that Group. For example, a Group called "Warehouse" might be created for devices configured to connect with specific access points in the company's warehouse and to receive the company's apps for inventory control and order picking activities. 

#### Settings Profiles

As in [Zebra StageNow](/stagenow), Zebra DNA Cloud employs the concept of Profiles, which are collections of device settings and/or apps that configure devices to behave in a certain way or to enable workers to perform particular sets of tasks. Zebra DNA Cloud also implements device Groups, **allowing administrators to deploy a Profile associated with that Group simply by adding devices to the Group**.   

> <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> When a Group is associated with a settings Profile, all devices added to that Group automatically receive the settings in that Profile. See additional Profile and Group behaviors below. 

#### Profile and Group Behavior

A Group can have only one profile, but a profile can be applied to more than one group.  

* **Profiles remain in effect until deleted**; they effect devices immediately as they come online. 
* **Groups can be created and devices added during enrollment** or at any time thereafter. 
* **Devices added to a Group automatically receive the settings in the Profile associated with that Group**. 
* **A device can belong to only one Group** at a time.
* **Removing a device from a Group cancels deployment of any pending settings Profiles**.  
* **Deleting a Group or removing a device from a Group <i>DOES NOT</i> remove settings Profile(s) previously applied**. 
* **Deleting a Profile cancels deployment of any jobs "in progress" for that Profile**, but does NOT remove past deployments.

-----

### Create a Settings Profile

To begin, go to the Device Settings section and **select the settings type under the "New Settings" button**:<br>
&#160;&#160;&#160; • **Wizard -** Presents configuration parameters with the most common options pre-selected ([shown with Step 1 below](#usesettingswizard))<br>
&#160;&#160;&#160; • **Advanced -** Presents all available configuration parameters with default options selected (shown with [Advanced Settings](#useadvancedsettings) section below)<br>
<img alt="image" style="height:350px" src="settings_1.png"/>
_Click image to enlarge; ESC to exit._
<br>

### Use Settings Wizard
This section presents the most common configuration parameters with common options pre-selected. 

2. **Configure Language/Locale and Date/Time settings** as desired and **click "Next"** button:
<img alt="image" style="height:350px" src="settings_2.png"/>
_Click image to enlarge; ESC to exit._
<br>

3. **Configure Networks** as desired and **click "Next"** button:
<img alt="image" style="height:350px" src="settings_3.png"/>
_Click image to enlarge; ESC to exit._
<br>

4. **Configure Security settings** as desired and **click "Next"** button:
<img alt="image" style="height:350px" src="settings_4.png"/>
_Click image to enlarge; ESC to exit._
<br>

5. **Configure Display settings** as desired and **click "Next"** button:
<img alt="image" style="height:350px" src="settings_5.png"/>
_Click image to enlarge; ESC to exit._
<br>

6. **Configure other hardware settings** as desired and **click "Next"** button:
<img alt="image" style="height:350px" src="settings_6.png"/>
_Click image to enlarge; ESC to exit._
<br>

7. **Enter a Name for this settings Profile** or accept the auto-generated one.<br> 
**Add a short description** to help identify the Profile later.<br>
**Click "Next"** button when finished:
<img alt="image" style="height:350px" src="settings_7.png"/>
_Click image to enlarge; ESC to exit._
<br>

8. **Review all settings** and edit as needed.<br> 
**Click "Apply Now"** button to proceed:
<img alt="image" style="height:350px" src="settings_8.png"/>
_Click image to enlarge; ESC to exit._
<br>

9. **Select target device(s) and/or Groups** to receive the profile.<br>
  **Click "Apply"** to deploy immediately: 
<img alt="image" style="height:350px" src="settings_9.png"/>
_Click image to enlarge; ESC to exit._
<br>

10. **Monitor progress of settings deployments** in the Device Settings landing page:
<img alt="image" style="height:350px" src="settings_summary_plus.png"/>
_Click image to enlarge; ESC to exit._
<br>

#### Status Definitions
* **Success (green) -** Deployment to device(s) completed on device(s) as expected
* **Failed (red) -** Deployment did not succeed, possibly because:
 * The Profile never reached the device
 * One or more settings are not supported by the device(s)
* **In Progress (blue) -** Deployment is pending on at least one device; no errors have occurred 
* **Issues (yellow) -** Partial success; one or more problems are preventing full deployment
* **Draft (black) -** Profile is unfinished or awaiting deployment 
* **Unknown -** Status could not be determined, possibly because all devices have been removed from Profile

> **More about [Profile and Group Behavior](#profileandgroupbehavior)**

<!-- #### Notes
* <i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> Selecting a Group in Step 9 above **would apply all settings created in the Profile to**:
 * **All devices currently in that Group**
 * **Devices added to the Group at any time in the future** 
 -->

-----

### Use Advanced Settings
This section presents *all* available configuration parameters with default options pre-selected.  

1. Click on the title(s) to **select the MX settings group(s)** to be configured.
<img alt="image" style="height:350px" src="advSettings_1.png"/>
_Click image to enlarge; ESC to exit._
<br>

2. **Hover mouse pointer over "info" icon** to reveal parameters in each Settings group.
<img alt="image" style="height:350px" src="advSettings_2.png"/>
_Click image to enlarge; ESC to exit._
<br>

3. **Click "+"** to expand the group and expose its parameters.<br>
<i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> It might be necessary to **scroll down to see all parameters** and options.<br>
**Configure parameter options as desired**.<br> 
**Click "Next"** button when finished:
<img alt="image" style="height:350px" src="advSettings_1a.png"/>
_Click image to enlarge; ESC to exit._
<br>

4. **Enter a Name for this settings Profile** or accept the auto-generated one.<br> 
**Add a short description** to help identify the Profile later.<br>
**Click "Next"** button when finished: 
<img alt="image" style="height:350px" src="advSettings_3.png"/>
_Click image to enlarge; ESC to exit._
<br>

5. **Review all settings** and edit as needed.<br> 
**Click "Apply Now"** or "Save" button to proceed: 
<img alt="image" style="height:350px" src="advSettings_4.png"/>
_Click image to enlarge; ESC to exit._
<br>

6. **Select target device(s) and/or Groups** to receive the profile.<br>
  **Click "Apply"** to deploy immediately: 
<img alt="image" style="height:350px" src="settings_9.png"/>
_Click image to enlarge; ESC to exit._
<br>

7. **Monitor progress of settings deployment** in the Device Settings landing page:
<img alt="image" style="height:350px" src="settings_summary_plus.png"/>
_Click image to enlarge; ESC to exit._
<br>

#### Status Definitions
* **Success (green) -** Deployment to device(s) completed on device(s) as expected
* **Failed (red) -** Deployment did not succeed, possibly because:
 * The Profile never reached the device
 * One or more settings are not supported by the device(s)
* **In Progress (blue) -** Deployment is pending on at least one device; no errors have occurred 
* **Issues (yellow) -** Partial success; one or more problems are preventing full deployment
* **Draft (black) -** Profile is unfinished or awaiting deployment 
* **Unknown -** Status could not be determined, possibly because all devices have been removed from Profile

> **More about [Profile and Group Behavior](#profileandgroupbehavior)**

-----

### Change Device Group

From the "My Devices" screen, **click on the pencil icon** in a device's row to manage the Group it belongs to:<br>
<img alt="image" style="height:350px" src="change_device_group.png"/>
_Click image to enlarge; ESC to exit._
<br>

> <i class="fa fa-exclamation-circle" aria-hidden="true" style="color:#FF0000;"></i> This action might effect [device licensing](../licensing). **NOTE**: A device can belong to **NO MORE** than one Group at a time. 

-----

## Manage Apps

This section covers installation and uninstallation of apps on devices and deployment of related files, if any. 

### Install app(s) and/or files

**&#49;**. In the My Apps section, **click on the "Configure and Deploy App(s)" button**:
<img alt="image" style="height:350px" src="manage_app_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#50;**. **Enter the package name and source URL** for the app being installed.<br>
<i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> **To deploy only files** (and no app), uncheck the "App Installation" box and proceed to Step 3.
<img alt="image" style="height:350px" src="manage_app_02.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#51;**. If adding files, **click the "Add app-related files" button** to add files for deployment.<br>
**Click "Add" when finished** adding each file name and desired destination on the device.<br>
**Repeat until all related files are added**:
<img alt="image" style="height:350px" src="manage_app_05.png
"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#52;**. **Click "Next"** to proceed:
<img alt="image" style="height:350px" src="manage_app_03.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#53;**. **Select the target device(s)** to receive the app and/or file(s).<br>
When finished selecting target(s), **click "Apply Now" to push changes**:
<img alt="image" style="height:350px" src="manage_app_04.png"/>
_Click image to enlarge; ESC to exit._
<br>

**&#54;. Confirm app deployment to device(s) by individual inspection or user confirmation**.  

<!-- 6/10/22- per eng, status of this activity is now shown in beta release

**&#54;. Monitor progress of settings deployment** in the Device Settings landing page:
<img alt="image" style="height:350px" src="settings_summary.png"/>
_Click image to enlarge; ESC to exit._
<br>
 -->

-----

## Manage Users

The Tenant Owner creates Administrative Users in the zDNA Cloud system using Zebra.com credemntials. Admin users can perform all tasks within the system ***except*** user administration. 

<i class="fa fa-exclamation-triangle" aria-hidden="true" style="color:#FFA500;"></i> This section requires login as the Tenant Owner using Zebra.com credentials. For credentials, please [register with Zebra.com](../setup/#iiregisterwithzebracom). 

-----

### Create Admin Users

&#49;. Point browser to Zebra DNA Cloud server and **log in as "Tenant Owner"** using Zebra.com credentials: 
<img alt="image" style="height:350px" src="zDNA_login.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
&#50;. Click user icon for menu and **select "Manage All Users"** from the menu: 
<img alt="image" style="height:350px" src="user_admin_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
&#51;. In All Users screen, **click "New User" button**: 
<img alt="image" style="height:350px" src="user_admin_01a.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#52;. Enter user info and click "Add" button**:
<img alt="image" style="height:350px" src="user_admin_02.png"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#53;. New user appears in All Users list**:  
<img alt="image" style="height:350px" src="user_admin_03.png"/>
_Click image to enlarge; ESC to exit._
<br>

&#54;. Instruct the new user to visit zDNA Cloud server and login as an Administrative User. 

&#55;. At login, **select "Forgot Password"** to generate an email with further instructions.

&#56;. Repeat this process for all Administrative Users. 

-----

## Android Updates
**The Android Updates function keeps enrolled devices up to date with the latest Android OS updates and security patches**. Devices managed with this feature are subject to the behaviors listed below.

* **General Behavior**
 * **Android Updates are applicable only on enrolled devices**.
 * For unenrolled devices, the only available Action is to Enroll.
* **Bulk Actions**
 * **"Update" Action can be performed** in bulk on devices of the **same model number ONLY**. 
 * **"Enroll" Action can be performed on dissimilar** device models.
 * **Enroll and Update Actions can be combined in a bulk operation**, unenrolled devices are enrolled only; already enrolled devices are updated.

-----

### Perform an Android Update

**&#49;. Click on Android Updates** to display the Device View:  
<img alt="image" style="height:350px" src="android_update_01.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

#### Devices Update Status 
* **Up to date -** Device has all the latest OS updates and security patches. No action is required. 
* **New Available -** Device does NOT have the latest OS updates and/or security patches. Click "Update to Latest" to upgrade.
* **Not Enrolled -** LifeGuard Over the Air (OTA) servvice is NOT running on the device. Click "Enroll" to install.  

-----
**&#50;. Click on the checkbox** for one or more devices on which to perform an Action.<br>
<i class="fa fa-exclamation-triangle" style="color:#FFA500;"></i> Updates can be performed on **multiple devices ONLY of the same model number**: 
<img alt="image" style="height:350px" src="android_update_02.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#51;. Enter a Job Name (or use the auto-generated default), Source and Description** for later identification of the Job:  
<img alt="image" style="height:350px" src="android_update_04.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#52;. Review the contents of the Update** to confirm that it's correct:  
<img alt="image" style="height:350px" src="android_update_05.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#53;. Select a Schedule for performing the Update**. For example, schedule during "off hours" to minimize worker dispuption.<br>
Select "As soon as possible" to begin the Update immediately upon starting the job.<br>
<i class="fa fa-exclamation-triangle" style="color:#FFA500;"></i> If setting an installation window, **the "Start at" date must be EARLIER than the selected End Date**.
<img alt="image" style="height:350px" src="android_update_06a.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#54;. Select the Conditions under which the Update is to be performed** and whether to allow the device user to postpone.<br>
<i class="fa fa-exclamation-triangle" style="color:#FFA500;"></i> An Update begins only **when ALL conditions are met**.  
<img alt="image" style="height:350px" src="android_update_07.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#55;. Review settings are configured as desired**. If necessary, click "Edit" to modify.<br>
**When finished, click the "Start Job" button**:   
<img alt="image" style="height:350px" src="android_update_08.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

-----
**&#56;. The Deployment tab displays the status of all Android Update jobs**:  
<img alt="image" style="height:350px" src="android_update_09.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

#### Update Job Status
* **Success (green)-** Deployment to device(s) completed as expected
* **In Progress (blue) -** Deployment is pending on at least one device; no errors are reported 
* **Issues (yellow) -** One or more problems prevented the Update from completing successfully
* **Issue (CR) -** Appears briefly when a cancel request is received for an Update
* **Cancelled (red) -** Update deployment has been cancelled
* **Created (black) -** Appears briefly when an Update job has been started
 
-----
**&#57;. Click "Open" in the Action column (above) to display the status of device(s) targeted by an individual Update job**:  
<img alt="image" style="height:350px" src="android_update_09a.PNG"/>
_Click image to enlarge; ESC to exit._
<br>

#### Actions
* **Open -** Displays details of the Update in that row
* **Cancel -** Cancels an In-Progress Update (disabled after Update is completed)
* **Delete -** Removes the Update from the deployment Profies list (available only when status is "Success," "Issue" or "Cancelled")
* **Remove -** removes the device in that row from the Update job
* **Reapply -** Attempts to reapply the Update on the device in that row

-----

## Also See

* **[Setup Guide](../setup)** | Set up an organization and its devices to use zDNA Cloud
* **[Licensing Guide](../licensing)** | Manage, allocate and reclaim licenses for apps and devices  
* **[FAQ](../faq)** | Frequently asked questions about zDNA Cloud (under construction)


-----

<!-- 

**&#55;.**
<img alt="image" style="height:250px" src="initial_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

**&#56;.**
<img alt="image" style="height:250px" src="initial_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

**&#57;.**
<img alt="image" style="height:250px" src="initial_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

**&#58;.**
<img alt="image" style="height:250px" src="initial_01.png"/>
_Click image to enlarge; ESC to exit._
<br>

 -->