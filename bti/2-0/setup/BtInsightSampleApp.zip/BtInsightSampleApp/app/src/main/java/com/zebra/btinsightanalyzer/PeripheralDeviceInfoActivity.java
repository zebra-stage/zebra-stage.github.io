package com.zebra.btinsightanalyzer;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.zebra.bluetooth.btinsightlib.BtInsightConstants;

import java.util.HashSet;
import java.util.Set;


public class PeripheralDeviceInfoActivity extends AppCompatActivity {
    private static final String TAG = "PeripheralDeviceInfoActivity";
    private boolean isDisconnectReasonDisplay;
    private boolean shouldShowBondStateChange;
    private boolean shouldShowConnectionStateChange;
    private PeripheralDevice peripheralDevice;
    private final Object viewLock = new Object();

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (LoggerDeviceListActivity.PERIPHERAL_UPDATE_ACTION.equals(intent.getAction())) {
                synchronized (viewLock) {
                    PeripheralDevice updatedPeripheralDevice = intent.getParcelableExtra(LoggerDeviceListActivity.EXTRA_PERIPHERAL);
                    if (updatedPeripheralDevice != null && updatedPeripheralDevice.getDeviceAddress().equals(peripheralDevice.getDeviceAddress())) {
                        peripheralDevice = updatedPeripheralDevice;
                        Log.d(TAG, "onReceived : " + LoggerDeviceListActivity.PERIPHERAL_UPDATE_ACTION + " " + peripheralDevice);
                        createItemDetailView();
                    }
                }
            }
        }
    };

    @SuppressLint("SetTextI18n")
    private synchronized void createItemDetailView() {
        Log.d(TAG, "createItemDetailView: " + peripheralDevice);

        TextView bondStateView = findViewById(R.id.bondstate);
        String bondText = "UNKNOWN";
        int bondState = peripheralDevice.getBondState();
        if (bondState == BtInsightConstants.BondState.STATE_BONDED) {
            bondText = "BONDED";
        }
        else if (bondState == BtInsightConstants.BondState.STATE_UNBONDED) {
            bondText = "UNBONDED";
        }
        bondStateView.setText(getText(R.string.bond_state) + bondText);
        bondStateView.setVisibility(shouldShowBondStateChange?View.VISIBLE:View.GONE);


        TextView lastBondTimeView = findViewById(R.id.lastbondtime);
        String lastBondTimeText = peripheralDevice.getBondStateEvent().getLastBondedAt();
        if (lastBondTimeText.isEmpty()) {
            lastBondTimeText = "UNKNOWN";
        }
        lastBondTimeView.setText(getText(R.string.last_bonded_time) + lastBondTimeText);
        lastBondTimeView.setVisibility(shouldShowBondStateChange?View.VISIBLE:View.GONE);

        TextView lastUnbondTimeView = findViewById(R.id.lastunbondetime);
        String lastUnbondTimeText = peripheralDevice.getBondStateEvent().getLastUnbondedAt();
        if (lastUnbondTimeText.isEmpty()) {
            lastUnbondTimeText = "UNKNOWN";
        }
        lastUnbondTimeView.setText(getText(R.string.last_unbonded_time) + lastUnbondTimeText);
        lastUnbondTimeView.setVisibility(shouldShowBondStateChange?View.VISIBLE:View.GONE);


        TextView connectStateView = findViewById(R.id.connectionstate);
        String connectText = "UNKNOWN";
        int connState = peripheralDevice.getConnectionEvent().getConnectionState();
        if (connState == BtInsightConstants.ConnectionState.STATE_CONNECTED) {
            connectText = "CONNECTED";
        }
        else if (connState == BtInsightConstants.ConnectionState.STATE_DISCONNECTED) {
            connectText = "DISCONNECTED";
        }
        connectStateView.setText(getText(R.string.connection_state) + connectText);
        connectStateView.setVisibility(shouldShowConnectionStateChange?View.VISIBLE:View.GONE);

        TextView lastConnectTime = findViewById(R.id.lastconnection);
        String lastConnectTimeText = peripheralDevice.getConnectionEvent().getLastConnectedAt();
        if (lastConnectTimeText.isEmpty()) {
            lastConnectTimeText = "UNKNOWN";
        }
        lastConnectTime.setText(getText(R.string.last_connected_time) + lastConnectTimeText);
        lastConnectTime.setVisibility(shouldShowConnectionStateChange?View.VISIBLE:View.GONE);

        TextView lastDisconnectTime = findViewById(R.id.lastdisconnection);
        String lastDisconnectTimeText = peripheralDevice.getConnectionEvent().getLastDisconnectedAt();
        if (lastDisconnectTimeText.isEmpty()) {
            lastDisconnectTimeText = "UNKNOWN";
        }
        lastDisconnectTime.setText(getText(R.string.last_disconnected_time) + lastDisconnectTimeText);
        lastDisconnectTime.setVisibility(shouldShowConnectionStateChange?View.VISIBLE:View.GONE);

        TextView lastDisconnectReasonView = findViewById(R.id.lastdisconnectreason);
        String lastDisconnectReasonText = "UNKNOWN";
        int reason = peripheralDevice.getConnectionEvent().getLastDisconnectReason();
        if (reason == BtInsightConstants.DisconnectionReason.REASON_USER_TERMINATED) {
            lastDisconnectReasonText = "NORMAL DISCONNECT";
        }
        else if (reason == BtInsightConstants.DisconnectionReason.REASON_LINKLOSS) {
            lastDisconnectReasonText = "LINKLOSS DISCONNECT";
        }
        else if (reason == BtInsightConstants.DisconnectionReason.REASON_LOW_BATT) {
            lastDisconnectReasonText = "LOW BATTERY";
        }
        lastDisconnectReasonView.setText(getText(R.string.last_disconnect_reason) + lastDisconnectReasonText);
        lastDisconnectReasonView.setVisibility(shouldShowConnectionStateChange && isDisconnectReasonDisplay? View.VISIBLE:View.GONE);

        TextView serialNumberView = findViewById(R.id.serialnumber);
        String serialNumberText = peripheralDevice.getSerialNumber();
        serialNumberView.setText(getText(R.string.serial_number) + serialNumberText);
        serialNumberView.setVisibility(!serialNumberText.isEmpty()? View.VISIBLE:View.GONE);

        TextView peripheralTypeView = findViewById(R.id.peripheraltype);
        String peripheralTypeText = getPeripheralTypeString(peripheralDevice.getPeripheralType());
        peripheralTypeView.setText(getText(R.string.peripheral_type) + peripheralTypeText);
    }

    private String getPeripheralTypeString(int type) {
        switch (type) {
            case BtInsightConstants.PeripheralType.SCANNER_HID:
                return "Scanner(HID)";
            case BtInsightConstants.PeripheralType.SCANNER_SSI:
                return "Scanner(SSI)";
            case BtInsightConstants.PeripheralType.SCANNER_SPP:
                return "Scanner(SPP)";
            case BtInsightConstants.PeripheralType.HEADSET:
                return "Headset/Speaker";
            case BtInsightConstants.PeripheralType.PHONE:
                return "Phone";
            case BtInsightConstants.PeripheralType.KEYBOARD:
                return "Keyboard";
            case BtInsightConstants.PeripheralType.COMPUTER:
                return "Computer/Laptop";
            case BtInsightConstants.PeripheralType.PRINTER:
                return "Printer";
            default:
                return "UNKNOWN";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.periperal_device_detail);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        isDisconnectReasonDisplay = sharedPreferences.getBoolean("disconnect_reason", false);
        Set<String> selectedEvents = sharedPreferences.getStringSet("event_list", new HashSet<>());
        if (selectedEvents.contains("bond")) {
            shouldShowBondStateChange = true;
        }
        if (selectedEvents.contains("connection")) {
            shouldShowConnectionStateChange = true;
        }

        registerReceiver(broadcastReceiver, new IntentFilter(LoggerDeviceListActivity.PERIPHERAL_UPDATE_ACTION));

        peripheralDevice = getIntent().getParcelableExtra(LoggerDeviceListActivity.EXTRA_PERIPHERAL);
        createItemDetailView();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");
        unregisterReceiver(broadcastReceiver);
        peripheralDevice = null;
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "onBackPressed");
        this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Log.d(TAG, "onOptionsItemSelected: home");
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
