package com.zebra.btinsightanalyzer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.zebra.bluetooth.btinsightlib.BtBondStateEvent;
import com.zebra.bluetooth.btinsightlib.BtConnectionEvent;
import com.zebra.bluetooth.btinsightlib.BtEventFilter;
import com.zebra.bluetooth.btinsightlib.BtGenericEventAttribute;
import com.zebra.bluetooth.btinsightlib.BtEventAttribute;
import com.zebra.bluetooth.btinsightlib.BtInsightConstants;
import com.zebra.bluetooth.btinsightlib.IBtInsightManager;
import com.zebra.bluetooth.btinsightlib.IBtInsightService;
import com.zebra.bluetooth.btinsightlib.IBtInsightCallback;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class LoggerDeviceListActivity extends AppCompatActivity {
    private final static String TAG = "LoggerDeviceListActivity ";
    private IBtInsightService mBtInsightServiceIf;
    private IBtInsightManager mBtInsightManagerIf;
    private ArrayAdapter<String> mDeviceList;
    private HashMap<String, PeripheralDevice> mPeripheralDevList;
    private final ParcelUuid CLIENT_UUID = new ParcelUuid(UUID.randomUUID());
    private int clientIdentity = -1;
    Set<String> selectedEvents;
    private final Object mDeviceListLock = new Object();
    public static final String PERIPHERAL_UPDATE_ACTION = "com.zebra.btinsightanalyzer.updateperipheralinfo";
    public static final String EXTRA_PERIPHERAL = "PERIPHERAL_DEV_INFO";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logger_device_list);
        initBtInsightManager();

        mDeviceList = new ArrayAdapter<>(this, R.layout.peripheralinfo);
        mPeripheralDevList = new HashMap<>();
        ListView peripheralListView = findViewById(R.id.devicelist);
        peripheralListView.setAdapter(mDeviceList);
        peripheralListView.setClickable(true);
        peripheralListView.setOnItemClickListener(mDeviceClickListener);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        selectedEvents = sharedPreferences.getStringSet("event_list", new HashSet<>());
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");
        deInitBtInsightManager();
        super.onDestroy();
    }

    private synchronized void updateUI(PeripheralDevice peripheralDevice) {
        runOnUiThread(() -> {
            String defaultItemText = peripheralDevice.getDeviceAddress().trim() +
                    "\n" +
                    peripheralDevice.getDeviceAddress();
            String item;
            if (peripheralDevice.getDeviceName() == null || peripheralDevice.getDeviceName().isEmpty()) {
                Log.w(TAG, "name is empty- device: " + peripheralDevice.getDeviceAddress());
                item = defaultItemText;
            }
            else {
                item = peripheralDevice.getDeviceName().trim() +
                        "\n" +
                        peripheralDevice.getDeviceAddress();
            }

            synchronized (mDeviceListLock) {
                Log.d(TAG, "Before- device list count: " + mDeviceList.getCount());
                // to make sure if any device name were not resolved before, update device name later time, by deleting default entry.
                mDeviceList.remove(defaultItemText);
                mDeviceList.remove(item);
                mDeviceList.add(item);
                sendBroadcast(new Intent(LoggerDeviceListActivity.PERIPHERAL_UPDATE_ACTION).putExtra(LoggerDeviceListActivity.EXTRA_PERIPHERAL, peripheralDevice));
                Log.d(TAG, "After- device list count: " + mDeviceList.getCount());
            }
        });
    }

    // The on-click listener for all devices in the ListViews
    private final AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            // Get the device MAC address, which is the last 17 chars in the View
            String info = ((TextView) v).getText().toString();
            String address = info.substring(info.length() - 17);
            Log.d(TAG, "OnItemClickListener - selected device MAC " + address);
            PeripheralDevice peripheralDevice = mPeripheralDevList.get(address);
            if (peripheralDevice != null) {
                Intent intent = new Intent(getApplicationContext(), PeripheralDeviceInfoActivity.class);
                intent.putExtra(EXTRA_PERIPHERAL, peripheralDevice);
                startActivity(intent);
            }
        }
    };

    private void updateVersionInfo(String version) {
        runOnUiThread(()-> {
            Log.i(TAG, "version: " + version);
            TextView view = findViewById(R.id.version);
            view.setText("Version: " + version);
        });
    }

    private final ServiceConnection mBtInsightServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            Log.d(TAG, "Connected to IBtInsightService");
            mBtInsightServiceIf = IBtInsightService.Stub.asInterface(service);
            try {
                if (mBtInsightServiceIf != null) {
                    Log.d(TAG, "from preference: selectedEvents: "+ selectedEvents);
                    if (selectedEvents.isEmpty()) {
                        finish();
                        runOnUiThread(() -> Toast.makeText(getBaseContext(), "Please select feature & events in settings", Toast.LENGTH_SHORT).show());
                    }
                    else {
                        String version = mBtInsightServiceIf.getBtAnalyzerVersion();
                        updateVersionInfo(version);

                        int result = mBtInsightServiceIf.registerClient(CLIENT_UUID, callbackListener);
                        if (result == BtInsightConstants.StatusCode.STATUS_NOT_READY) {
                            finish();
                            runOnUiThread(() -> Toast.makeText(getBaseContext(), "Analyzer services are not ready. Please try after few minutes", Toast.LENGTH_SHORT).show());
                        }
                        else if (result == BtInsightConstants.StatusCode.STATUS_UNAUTHORIZED) {
                            finish();
                            runOnUiThread(() -> Toast.makeText(getBaseContext(), "Unauthorized App Error!!!", Toast.LENGTH_SHORT).show());
                        }
                        else if (result != BtInsightConstants.StatusCode.STATUS_SUCCESS){
                            finish();
                            runOnUiThread(() -> Toast.makeText(getBaseContext(), "Unexpected Error!!!", Toast.LENGTH_SHORT).show());
                        }
                    }
                }
            } catch (RemoteException exception) {
                Log.d(TAG, "Exception during registration " + exception.getMessage());
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.d(TAG, "Disconnected to IBtInsightManager");
            mBtInsightServiceIf = null;
        }
    };

    private final IBtInsightCallback.Stub callbackListener = new IBtInsightCallback.Stub() {
        @Override
        public void onClientRegistered(int status, int clientId) {
            Log.d (TAG, "onClientRegistered: " + " status: " + status + " clientId: " + clientId);
            if (status == BtInsightConstants.StatusCode.STATUS_SUCCESS) {
                clientIdentity = clientId;
                try {
                    mBtInsightManagerIf = mBtInsightServiceIf.getBtManager(clientId);
                    if (mBtInsightManagerIf != null) {
                        BtEventFilter filter  = new BtEventFilter();
                        if (selectedEvents.contains("connection"))
                            filter.addEvent(BtInsightConstants.EventType.EVENT_CONNECTION_TYPE);
                        if (selectedEvents.contains("bond"))
                            filter.addEvent(BtInsightConstants.EventType.EVENT_BOND_TYPE);
                        mBtInsightManagerIf.registerPeripheralStatusEvent(clientId, filter);
                        runOnUiThread(() -> Toast.makeText(getBaseContext(), "Analyzer started and running", Toast.LENGTH_SHORT).show());
                    }
                    else {
                        finish();
                        runOnUiThread(() -> Toast.makeText(getBaseContext(), "Unexpected error!!!", Toast.LENGTH_SHORT).show());
                    }
                }
                catch (RemoteException e) {
                    Log.e(TAG, Log.getStackTraceString(e));
                }
            }
            else {
                finish();
                runOnUiThread(() -> Toast.makeText(getBaseContext(), "App registration failed", Toast.LENGTH_SHORT).show());
            }
        }

        @Override
        public void onClientUnregistered() {
            finish();
            runOnUiThread(() -> Toast.makeText(getBaseContext(), "Analyzer has stopped", Toast.LENGTH_SHORT).show());
        }

        @Override
        public void onReportError(int errorCategory, int error) {
            String message = "";
            Log.d(TAG, "onReportError: errorCategory: " + errorCategory + " error: " + error);

            if (errorCategory == BtInsightConstants.ErrorCategory.BLUETOOTH_APP) {
                switch (error) {
                    case BtInsightConstants.BluetoothAppError.BT_STATE_RESET: {
                        message = "Bluetooth State is reset";
                    }
                    break;
                    case BtInsightConstants.BluetoothAppError.CRASH_HIT: {
                        message = "Bluetooth App crashed";
                    }
                    break;
                }
            }

            if (!message.isEmpty()) {
                String finalMessage = message;
                runOnUiThread(() -> Toast.makeText(getBaseContext(), finalMessage, Toast.LENGTH_SHORT).show());
            }
        }


        @Override
        public void onPeripheralStatusChanged(int eventType, BtEventAttribute data) {
            switch (eventType) {
                case BtInsightConstants.EventType.EVENT_CONNECTION_TYPE:{
                    BtConnectionEvent connectionEvent = ((BtGenericEventAttribute<BtConnectionEvent>)data).toEvent();
                    Log.d(TAG, "CONNECTION_EVENT: " + connectionEvent);
                    PeripheralDevice peripheralDevice = mPeripheralDevList.get(connectionEvent.getDeviceMac());
                    if (peripheralDevice == null) {
                        peripheralDevice = new PeripheralDevice(connectionEvent.getDeviceMac(), connectionEvent.getDeviceName());
                    }
                    peripheralDevice.setDeviceName(connectionEvent.getDeviceName());
                    peripheralDevice.setConnectionEvent(connectionEvent);
                    mPeripheralDevList.put(connectionEvent.getDeviceMac(), peripheralDevice);
                    updateUI(peripheralDevice);
                }
                break;
                case BtInsightConstants.EventType.EVENT_BOND_TYPE:
                {
                    BtBondStateEvent bondStateEvent = ((BtGenericEventAttribute<BtBondStateEvent>)data).toEvent();
                    Log.d(TAG, "BOND_EVENT: "+ bondStateEvent);
                    PeripheralDevice peripheralDevice = mPeripheralDevList.get(bondStateEvent.getDeviceMac());
                    if (peripheralDevice == null) {
                        peripheralDevice = new PeripheralDevice(bondStateEvent.getDeviceMac(), bondStateEvent.getDeviceName());
                    }
                    peripheralDevice.setDeviceName(bondStateEvent.getDeviceName());
                    peripheralDevice.setBondStateEvent(bondStateEvent);
                    mPeripheralDevList.put(bondStateEvent.getDeviceMac(), peripheralDevice);
                    updateUI(peripheralDevice);
                }
                break;
                default:
                    Log.d(TAG, "unhandled eventType:" + eventType);
            }

        }
    };

    private static final String ZBT_INSIGHT_PACKAGE = "com.zebra.bluetooth";
    private static final String ZBT_INSIGHT_ACTION = "com.zebra.bluetooth.BT_INSIGHT_ANALYZER";


    private void initBtInsightManager() {
        Intent intent = new Intent(ZBT_INSIGHT_ACTION);
        intent.setPackage(ZBT_INSIGHT_PACKAGE);
        //intent.setComponent(new ComponentName(ZBT_PACKAGE, ZBT_CLASS));
        if (getApplicationContext().bindService(intent, mBtInsightServiceConnection, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT)) {
            Log.d(TAG, "Bind Success to IBtInsightService");
        } else {
            Log.d(TAG, "Bind Failed to IBtInsightService");
        }
    }

    private void deInitBtInsightManager() {
        if (mBtInsightServiceIf != null) {
            try {
                Log.d(TAG, "unregister client: " + clientIdentity);
                if (mBtInsightManagerIf != null) {
                    mBtInsightManagerIf.unregisterPeripheralStatusEvent(clientIdentity);
                }
                mBtInsightServiceIf.unregisterClient(clientIdentity);
                getApplicationContext().unbindService(mBtInsightServiceConnection);
            }catch (RemoteException e) {
                Log.d(TAG, "Exception during unregistration " + e.getMessage());
            }
        }
        mBtInsightManagerIf = null;
        mBtInsightServiceIf = null;
    }
}