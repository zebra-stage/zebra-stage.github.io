package com.zebra.btinsightanalyzer;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.MultiSelectListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreference;
import androidx.preference.SwitchPreferenceCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Settings");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        private static final String TAG = "SettingsFragment";

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            MultiSelectListPreference featurePreference = getPreferenceManager().findPreference("feature_list");
            SharedPreferences sharedPreferences = featurePreference.getSharedPreferences();
            Set<String> selectedFeatures = sharedPreferences.getStringSet("feature_list", new HashSet<>());
            modifyEventOptionsBasedOnFeatureSelection(selectedFeatures);
        }

        @SuppressLint("MutatingSharedPrefs")
        private void modifyEventOptionsBasedOnFeatureSelection(Set<String> selectedOptions) {
            MultiSelectListPreference eventPreference = getPreferenceManager().findPreference("event_list");
            SharedPreferences sharedPreferences = eventPreference.getSharedPreferences();
            Set<String> selectedEvents = sharedPreferences.getStringSet("event_list", new HashSet<>());
            Log.d(TAG, "selected events:" + selectedEvents);


            List<String> entries = new ArrayList<>(Arrays.asList("Bond Type", "Connection Type", "Profile Type"));
            List<String> entryValues = new ArrayList<>(Arrays.asList("bond", "connection", "profile"));

            if (!selectedOptions.contains("generic access")) {
                entries.remove("Bond Type");
                entries.remove("Connection Type");
                entryValues.remove("bond");
                entryValues.remove("connection");
            }
            if (!selectedOptions.contains("profile")) {
                entries.remove("Profile Type");
                entryValues.remove("profile");
            }

            selectedEvents.removeIf(event -> !entryValues.contains(event));
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove("event_list");
            editor.putStringSet("event_list", selectedEvents);
            editor.commit();

            eventPreference.setEntries(entries.toArray(new CharSequence[0]));
            eventPreference.setEntryValues(entryValues.toArray(new CharSequence[0]));
            eventPreference.setValues(selectedEvents);
        }

        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            MultiSelectListPreference featurePreference = getPreferenceManager().findPreference("feature_list");
            featurePreference.setOnPreferenceChangeListener((preference, newValue) -> {
                Set<String> selectedOptions = (Set<String>) newValue;
                Log.d(TAG, selectedOptions.toString());
                modifyEventOptionsBasedOnFeatureSelection(selectedOptions);
                return true;
            });

            SwitchPreferenceCompat disconnectReasonPreference = getPreferenceManager().findPreference("disconnect_reason");
            disconnectReasonPreference.setOnPreferenceChangeListener((preference, newValue) -> {
                Log.d(TAG, "switch state:" + newValue);
                SharedPreferences sharedPreferences = disconnectReasonPreference.getSharedPreferences();
                boolean state = sharedPreferences.getBoolean("disconnect_reason", false);
                Log.d(TAG, "persisting switch state:" + state);
                return true;
            });

//            featurePreference.setOnPreferenceClickListener(preference -> {
//                Log.d(TAG, "onPreferenceClick: " + preference);
//                if (preference instanceof MultiSelectListPreference) {
//                    MultiSelectListPreference multiSelectListPreference = (MultiSelectListPreference) preference;
//                    Set<String> clickedValues = multiSelectListPreference.getValues();
//                    if (clickedValues.contains("all")) {
//                        Set<String> allValues = new HashSet<>();
//                        Log.d(TAG, "all is clicked");
//                        for (CharSequence seq: multiSelectListPreference.getEntryValues()) {
//                            allValues.add(seq.toString());
//                        }
//                        multiSelectListPreference.setValues(allValues);
//                    }
//                }
//                return false;
//            });
            return super.onCreateView(inflater, container, savedInstanceState);
        }
    }
}