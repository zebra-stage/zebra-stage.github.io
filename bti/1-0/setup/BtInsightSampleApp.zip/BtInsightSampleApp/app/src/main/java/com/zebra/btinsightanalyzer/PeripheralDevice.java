package com.zebra.btinsightanalyzer;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

import com.zebra.bluetooth.btinsightlib.BtBondStateEvent;
import com.zebra.bluetooth.btinsightlib.BtConnectionEvent;
import com.zebra.bluetooth.btinsightlib.BtInsightConstants;

public class PeripheralDevice implements Parcelable{
    private static final String TAG = "PeripheralDevice ";
    private BtConnectionEvent connectionEvent;
    private BtBondStateEvent bondStateEvent;
    private final String deviceAddress;
    private  String deviceName;
    private int bondState = BtInsightConstants.BondState.STATE_UNKNOWN;
    private String serialNumber = BtInsightConstants.DEFAULT_EMPTY;
    private int peripheralType = BtInsightConstants.PeripheralType.UNKNOWN;

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceAddress() {
        return deviceAddress;
    }

    public String getDeviceName() {
        return deviceName;
    }

    protected PeripheralDevice(Parcel in) {
        deviceAddress = in.readString();
        deviceName = in.readString();
        connectionEvent = in.readParcelable(BtConnectionEvent.class.getClassLoader());
        bondStateEvent = in.readParcelable(BtBondStateEvent.class.getClassLoader());
        bondState = in.readInt();
        serialNumber = in.readString();
        peripheralType = in.readInt();
    }

    @Override
    public String toString() {
        return "PeripheralDevice{" +
                "connectionEvent=" + connectionEvent +
                ", bondStateEvent=" + bondStateEvent +
                ", deviceAddress='" + deviceAddress + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", bondState=" + bondState +
                ", serialNumber='" + serialNumber + '\'' +
                ", peripheralType='" + peripheralType + '\'' +
                '}';
    }

    public PeripheralDevice(String address, String name) {
        deviceAddress = address;
        deviceName = name;
        connectionEvent = new BtConnectionEvent();
        bondStateEvent = new BtBondStateEvent();
    }

    public static final Creator<PeripheralDevice> CREATOR = new Creator<PeripheralDevice>() {
        @Override
        public PeripheralDevice createFromParcel(Parcel in) {
            return new PeripheralDevice(in);
        }

        @Override
        public PeripheralDevice[] newArray(int size) {
            return new PeripheralDevice[size];
        }
    };

    public int getPeripheralType() {
        return peripheralType;
    }

    public void setConnectionEvent(BtConnectionEvent event) {
        @SuppressLint("Recycle") Parcel p = Parcel.obtain();
        p.writeParcelable(event, 0);
        p.setDataPosition(0);
        this.connectionEvent = p.readParcelable(BtConnectionEvent.class.getClassLoader());
        this.bondState = event.getBondedState();
        this.serialNumber = event.getSerialNumber();
        this.peripheralType = event.getPeripheralType();
    }

    public BtConnectionEvent getConnectionEvent() {
        return this.connectionEvent;
    }

    public int getBondState() {
        return bondState;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setBondStateEvent(BtBondStateEvent event) {
        @SuppressLint("Recycle") Parcel p = Parcel.obtain();
        p.writeParcelable(event, 0);
        p.setDataPosition(0);
        this.bondStateEvent = p.readParcelable(BtBondStateEvent.class.getClassLoader());
        this.bondState = event.getBondState();
        this.serialNumber = event.getSerialNumber();
        this.peripheralType = event.getPeripheralType();
    }

    public BtBondStateEvent getBondStateEvent() {
        return this.bondStateEvent;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(deviceAddress);
        dest.writeString(deviceName);
        dest.writeParcelable(connectionEvent, flags);
        dest.writeParcelable(bondStateEvent, flags);
        dest.writeInt(bondState);
        dest.writeString(serialNumber);
        dest.writeInt(peripheralType);
    }
}
